// tools/check-knip-dead-code.mjs — whole-tree unused-file/unused-export
// scan via Knip, informational only (same treatment as
// check-dead-exports.mjs, and for the same reason: real false-positive
// risk — see below).
//
// Why this exists ALONGSIDE check-dead-exports.mjs rather than replacing
// it: check-dead-exports.mjs is deliberately scoped to js/core/*.js only
// (the shared logic layer) to keep its own false-positive rate low. Knip
// covers the WHOLE tree (js/, dashboard/, matrix/, popup/, privacy/,
// picker/, tools/) with a real import-graph resolver, catching whole
// dead FILES too, not just dead exports within one directory — but at
// the cost of needing explicit `entry` points in knip.json for anything
// this codebase loads by a mechanism Knip's static resolver can't see
// (see knip.json's own comments): content scripts registered by
// string-templated path (`js/scripting/*.js`, `js/security/*.js`),
// <script src> tags in HTML (`js/ui/theme.js` — see
// STYLE_GUIDE_DARK.md's own prerequisite note on this exact loading
// mechanism), and CLI tools invoked via execFileSync rather than
// imported (`tools/*.mjs`).
//
// KNOWN ENVIRONMENT CONSTRAINT: Knip >=6 (specifically its oxc-parser
// dependency's "raw transfer" buffer pre-allocation) fails with
// "RangeError: Array buffer allocation failed" in sandboxes that reject
// a single ~4GB ArrayBuffer allocation, even with ample aggregate memory
// free — confirmed via a minimal `new ArrayBuffer(2**32)` repro in this
// project's own dev sandbox. This project's package.json therefore pins
// `knip@5.30.0` (predates the oxc raw-transfer parser) as a
// devDependency. If a future Knip upgrade is considered, re-run that
// repro first — this is an oxc-parser/sandbox interaction, not anything
// this codebase controls.
//
// Exit code is always 0 — this check is advisory. Every flagged item
// must be verified by hand before acting on it (a name that's a common
// word, a documented intentional re-export like js/data/config.js's
// `export const process = swLifecycle` backward-compat alias, or a
// genuinely-unused public API surface kept on purpose all read as "dead"
// to a static resolver and are not).
import { execFileSync } from 'child_process';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');

console.log('=== Knip: whole-tree unused-file / unused-export scan (informational) ===');
console.log('See knip.json for entry-point configuration and this file\'s own header for scope/caveats.\n');

try {
    const out = execFileSync(
        path.join(ROOT, 'node_modules', '.bin', 'knip'),
        [ '--no-exit-code' ],
        { cwd: ROOT, encoding: 'utf8' }
    );
    console.log(out);
    console.log('FLAG (informational — verify each by hand, see this file\'s header for known false-positive classes).');
} catch (err) {
    // --no-exit-code should make Knip itself always exit 0; a thrown
    // error here means Knip couldn't run at all (missing devDependency,
    // environment issue) — surface that plainly rather than silently
    // swallowing it, but still don't fail the overall suite.
    console.log(`Knip did not run: ${err.message}`);
    console.log('(Not a hard failure — this check is informational. Run `npm install` if node_modules/.bin/knip is missing.)');
}

process.exitCode = 0;
