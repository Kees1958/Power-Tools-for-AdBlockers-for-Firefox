// C20a — message-type routing cross-reference. Every exported MSG_*
// constant is either request/response (needs a route AND a handler) or
// broadcast-only (needs at least one .onmessage reader, not a route).
// See Xplainer_Programming_principles_audit.md's C20a for the full
// rationale — this is a straight port of that section's check to fit
// this project's own tools/ + npm test convention, not a new design.
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
function read(p) { return fs.readFileSync(path.join(ROOT, p), 'utf8'); }

// Maintain this set explicitly — broadcast-only types are expected to be
// absent from the route/dispatch tables; everything else is not. Verified
// against the actual broadcastMessage()/.onmessage call sites in this
// codebase, not assumed or copied from another project's version of this
// same check.
const BROADCAST_ONLY = new Set([
    'MSG_MATRIX_ENTRY', 'MSG_MATRIX_CLOSED',
    'MSG_PRIVACY_INSPECTOR_ENTRY', 'MSG_PRIVACY_INSPECTOR_CLOSED',
    // Cookie/consent-clicker: SW -> content-script broadcast (via
    // browser.tabs.sendMessage() with no frameId — see cookie-clicker-
    // routes.js's broadcastPickerStop()), NOT a BroadcastChannel message
    // like the four above. Its reader lives in js/scripting/cookie-
    // clicker-picker.js's onRuntimeMessage() (chrome.runtime.onMessage),
    // which is why it needs its own entry in broadcastReaderFiles below
    // rather than reusing matrix-panel.js/privacy-inspector.js's list.
    'MSG_COOKIE_CLICKER_PICKER_STOP',
]);

const typesSrc  = read('js/data/message-types.js');
const routesSrc = read('js/workflow/message-routes.js');
const bgSrc     = read('js/workflow/background.js');

const msgConstEntries = [ ...typesSrc.matchAll(/export const (MSG_\w+)\s*=\s*'([^']+)'/g) ]
    .map(m => ({ name: m[1], value: m[2] }));
const msgConsts = msgConstEntries.map(e => e.name);

const missingRoute = [];
const missingHandler = [];
for ( const name of msgConsts ) {
    if ( BROADCAST_ONLY.has(name) ) { continue; }
    if ( !routesSrc.includes(`[${name}]`) ) { missingRoute.push(name); }
    if ( !bgSrc.includes(`[${name}]`) ) { missingHandler.push(name); }
}

// Broadcast-only types: confirm at least one .onmessage reader exists
// somewhere that checks for this exact constant name, across every file
// with a BroadcastChannel 'uBOL' handler.
const broadcastReaderFiles = [
    'matrix/matrix-panel.js',
    'privacy/privacy-inspector.js',
];
const readerSrcCombined = broadcastReaderFiles.map(f => {
    try { return read(f); } catch { return ''; }
}).join('\n');

// Reader files that are injected as PLAIN content scripts (via
// chrome.scripting.executeScript's `files` array), not loaded as ES
// modules — such files structurally CANNOT `import` message-types.js's
// constants (no module scope to import into), so their reader code
// necessarily compares against the message's literal STRING VALUE
// instead of the constant's NAME. Kept as its own small map (rather than
// folding into broadcastReaderFiles/readerSrcCombined above) so the
// distinction — "matched by name" vs "matched by value, because this
// reader can't import" — stays visible here instead of silently
// papered over by string-matching both the same way.
const VALUE_MATCHED_READERS = new Map([
    [ 'MSG_COOKIE_CLICKER_PICKER_STOP', 'js/scripting/cookie-clicker-picker.js' ],
]);

const missingReader = [ ...BROADCAST_ONLY ].filter(name => {
    // Must actually be declared (skip if this project's broadcast-only
    // set drifted out of sync with message-types.js itself).
    if ( !msgConsts.includes(name) ) { return false; }
    const valueReaderFile = VALUE_MATCHED_READERS.get(name);
    if ( valueReaderFile !== undefined ) {
        const value = msgConstEntries.find(e => e.name === name)?.value;
        let src = '';
        try { src = read(valueReaderFile); } catch { /* handled by the .includes() below returning false */ }
        return !(value !== undefined && src.includes(`'${value}'`));
    }
    return !readerSrcCombined.includes(name);
});

console.log('=== C20a: message-type routing cross-reference ===');
console.log(`Checked ${msgConsts.length} declared MSG_* constants (${BROADCAST_ONLY.size} broadcast-only, ${msgConsts.length - BROADCAST_ONLY.size} request/response).`);

let ok = true;
if ( missingRoute.length > 0 ) {
    ok = false;
    console.log(`FAIL: missing route entry: ${missingRoute.join(', ')}`);
}
if ( missingHandler.length > 0 ) {
    ok = false;
    console.log(`FAIL: missing dispatch handler: ${missingHandler.join(', ')}`);
}
if ( missingReader.length > 0 ) {
    ok = false;
    console.log(`FAIL: broadcast-only type with no .onmessage reader found: ${missingReader.join(', ')}`);
}
// Also flag any constant in BROADCAST_ONLY that no longer exists in
// message-types.js — the maintained set itself can drift stale after a
// rename, same failure mode the doc's own checklist calls out.
const staleBroadcastEntries = [ ...BROADCAST_ONLY ].filter(name => !msgConsts.includes(name));
if ( staleBroadcastEntries.length > 0 ) {
    ok = false;
    console.log(`FAIL: BROADCAST_ONLY set references constants no longer in message-types.js: ${staleBroadcastEntries.join(', ')}`);
}

if ( ok ) { console.log('PASS: every MSG_* constant is fully wired.'); }
console.log('');
process.exitCode = ok ? 0 : 1;
