import { JSDOM } from 'jsdom';
import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

const ROOT = process.cwd();
const html = fs.readFileSync(path.join(ROOT, 'popup/popup.html'), 'utf8');

const dom = new JSDOM(html, { url: 'chrome-extension://test/popup/popup.html', runScripts: 'outside-only' });
const { window } = dom;
window.document.documentElement.classList.add('isHTTP');

const activeUntilMs = Date.now() + 17 * 60 * 1000;
const chromeMock = {
    runtime: {
        id: 'x', getURL: p => `chrome-extension://test/${p}`,
        sendMessage: (msg) => {
            if (msg.what === 'cookieClickerAutoDenyGet') {
                return Promise.resolve({ active: true, untilMs: activeUntilMs });
            }
            return Promise.resolve({ ok: true });
        },
        onMessage: { addListener(){} },
    },
    storage: { local: { get: () => Promise.resolve({}), set: () => Promise.resolve() }, session: { get: () => Promise.resolve({}), set: () => Promise.resolve() }, onChanged: { addListener(){} } },
    i18n: { getMessage: k => k },
};
window.chrome = chromeMock;
window.browser = chromeMock;

const keysToExpose = ['window','document','navigator','location','chrome','browser','HTMLElement','Node','CustomEvent','Event','MutationObserver','confirm','Blob','URL','FileReader','Window','Document','Element'];
for (const key of keysToExpose) {
    if (window[key] !== undefined) Object.defineProperty(global, key, { value: window[key], writable: true, configurable: true });
}
global.self = window;

// Imports the REAL popup/worry-free-ui.js directly — see
// e2e_countdown.mjs's own comment for why this works against the mocks
// above with no separate test fork needed.
const modUrl = pathToFileURL(path.join(ROOT, 'popup/worry-free-ui.js')).href + `?t=${Date.now()}`;
await import(modUrl);
await new Promise(r => setTimeout(r, 30));

const doc = window.document;
const label = doc.getElementById('worryFreeLabel');
const countdown = doc.getElementById('worryFreeCountdown');
console.log('label:', label.textContent);
console.log('countdown:', countdown.textContent, '(expect ~17:00)');
console.log('label title (transaction warning):', label.title);

// ── Real assertions — see e2e_countdown.mjs's own comment on why these
// were added when wiring into complete-check.mjs (step 25). ─────────
let failures = 0;
function assertEqual(actual, expected, label) {
    if ( actual !== expected ) {
        failures++;
        console.log(`\nFAIL: ${label} — expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
    }
}
assertEqual(label.textContent, 'Worry-free mode active — tap to stop', 'label text on reopen with an already-active session');
assertEqual(countdown.textContent, '17:00', 'countdown display on reopen');

console.log('');
if ( failures > 0 ) {
    console.log(`${failures} assertion(s) failed.`);
    process.exit(1);
}
console.log('PASS: all reopen assertions correct.');
process.exit(0);
