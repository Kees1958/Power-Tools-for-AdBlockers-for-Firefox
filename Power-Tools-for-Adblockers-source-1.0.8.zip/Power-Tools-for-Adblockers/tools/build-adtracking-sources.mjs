#!/usr/bin/env node
/*******************************************************************************
 * build-adtracking-sources.mjs
 *
 * RENAMED (this release) from build-merged-adtracking-list.mjs — the old
 * name described what this file used to do (merge everything into one
 * list), not what it's done since the SPLIT below. "merged" had been
 * vestigial for a while; per explicit request, dropped.
 *
 * SPLIT (per explicit request, to allow narrowing down filter-list issues
 * one source/category at a time) — this file used to merge Kees1958 +
 * Disconnect + Ghostery into ONE deduplicated list. It now writes
 * independent, separately-selectable source files instead, one per
 * source/category:
 *   - tools/data/kees1958-only-source.txt
 *     — Kees1958's own EU_US_MV3_most_common_ad+tracking_networks.txt
 *       (fetched live — stable raw URL).
 *   - tools/data/disconnect-other-source.txt (Disconnect's Advertising +
 *     Cryptomining + FingerprintingInvasive + FingerprintingGeneral
 *     categories, combined into one — see DISCONNECT_CATEGORY_GROUPS)
 *
 * Ghostery support (GHOSTERY_CATEGORY_GROUPS, extractGhosteryDomains(),
 * the --ghostery CLI flag) REMOVED entirely, per explicit request — see
 * CHANGELOG. ruleset_ghostery_ads/ruleset_ghostery_other and every
 * UI/manifest/worry-free reference to them are gone too, not just this
 * file's own build step. Note: tools/build-top1m-crossref.mjs still uses
 * Ghostery's trackerdb as one of its two safety-classification inputs —
 * that's a build-time-only, never-shipped safety filter feeding other
 * parts of this project (see the "SAFETY FILTER" paragraph below for why
 * that no longer includes the two sources this file writes) —
 * architecturally separate from shipping Ghostery-sourced block rules,
 * and was deliberately left as-is rather than weakened.
 *
 * Each output is independently selectable in the Filter (block) lists
 * panel (see tools/build-rulesets.mjs's FILTER_LISTS). A group entry can
 * combine more than one underlying vendor category into one output (e.g.
 * Disconnect's FingerprintingInvasive + FingerprintingGeneral => one
 * "Disconnect Fingerprinting" list) — deliberate, when the underlying
 * categories are genuinely one concept split by the vendor for their own
 * internal reasons, not a reason to hide that combination: each group's
 * own `categories` array documents exactly what went in.
 *
 * SAFETY FILTER — REMOVED entirely, per explicit request: both remaining
 * sources (Kees1958, Disconnect) are used as-is, no reviewList
 * cross-reference, no social-media exclusion, on the decided principle
 * that these are used exactly as their upstream maintainers wrote them.
 * The `top1m-tracker-crossref.json` mechanism this used to call into
 * still exists and is still used elsewhere in this project's build
 * pipeline (see the Ghostery paragraph above) — it just has no consumer
 * left in this specific file.
 *
 * This is a build-time tool only. Each output is read directly by its own
 * tools/build-rulesets.mjs FILTER_LISTS entry via a `customFetch` (local
 * file read, not a network fetch) — same `customFetch` escape hatch
 * buildAntiAdmiralSourceText() already established (C21: reused, not
 * reinvented).
 *
 * Usage:
 *   node build-adtracking-sources.mjs \
 *       --disconnect <path-to-services.json> \
 *       [--kees1958-url <override URL, defaults to the live source>] \
 *       [--only kees1958,disconnect <scope which source(s) rebuild>]
 ******************************************************************************/

import fs   from 'node:fs/promises';
import path from 'node:path';
import { parseArgs } from 'node:util';

/*==============================================================================
    CONFIG
==============================================================================*/
const CONFIG = {
    KEES1958_DEFAULT_URL:
        'https://raw.githubusercontent.com/Kees1958/W3C_annual_most_used_survey_blocklist/master/EU_US_MV3_most_common_ad%2Btracking_networks.txt',
    KEES1958_OUTPUT_PATH: path.resolve('data', 'kees1958-only-source.txt'),
    // Minimum plausible response size for the Kees1958 live fetch — same
    // "a bad response must never silently compile into the build" C13a
    // guard as every other live fetch in tools/build-rulesets.mjs.
    MIN_RESPONSE_BYTES: 500,
};

// Top-20 social-media-platform exclusion (SOCIAL_MEDIA_TOP20_DOMAINS,
// isSocialMediaTop20()) REMOVED entirely — it was only ever called from
// applySafetyFilter(), removed above for the same "both remaining
// sources are used as-is" reason. No other consumer in this file.
// One output per group. `categories` lists the exact vendor category
// name(s) folded in — a group with more than one category combines them
// (see this file's own header for why that's sometimes deliberate).
//
// Was two separate groups (Advertising alone as its own ruleset;
// Analytics+Cryptomining+Fingerprinting as a second) — merged into ONE,
// per explicit request: Analytics dropped entirely (not just from the
// title — the category is no longer fetched/included at all), Advertising
// folded in alongside Cryptomining/Fingerprinting instead of staying its
// own separate ruleset. The safety filter (reviewList crossref + top-20
// social-media exclusion) that used to apply to this "other" group is
// dropped for the merged list too — per explicit request to use
// Disconnect's ads/tracker data as-is, and since a single list can't have
// the filter applied to only part of itself, that "as-is" ruling extends
// to the whole merged output. See main() below — this group is now
// written with applySafetyFilter() skipped entirely, unlike every other
// group in this file.
// BRAVE VARIANT — Advertising category REMOVED entirely, per explicit
// request (was folded in alongside Cryptomining/Fingerprinting above;
// now dropped from both the fetch and the title, same as Analytics was
// before it). Only Cryptomining + Fingerprinting remain.
const DISCONNECT_CATEGORY_GROUPS = [
    { id: 'other', title: 'Disconnect (Cryptomining, Fingerprinting)',
      categories: [ 'Cryptomining', 'FingerprintingInvasive', 'FingerprintingGeneral' ] },
];

// GHOSTERY_CATEGORY_GROUPS REMOVED entirely, per explicit request — see
// this file's own top-of-file comment and CHANGELOG for the full removal.

/*==============================================================================
    STEP 0 — CLI args
==============================================================================*/
function parseCliArgs() {
    const { values } = parseArgs({
        options: {
            disconnect:   { type: 'string' },
            'kees1958-url': { type: 'string', default: CONFIG.KEES1958_DEFAULT_URL },
            // Scopes which source(s) main() actually rebuilds — per this
            // file's own stated purpose ("to allow narrowing down
            // filter-list issues one source/category at a time"). Comma-
            // separated, any of: kees1958, disconnect. Omitted (the
            // default) rebuilds both, matching every prior invocation's
            // behavior exactly — this is additive, not a behavior change
            // for existing callers.
            only: { type: 'string' },
        },
    });
    // --crossref REMOVED (this release) — was required for the reviewList
    // safety filter, which no longer has any consumer in this file (see
    // this file's own "(Was STEP 3...)" comment for why). Only
    // --disconnect stays required now.
    if ( !values.disconnect ) {
        throw new Error('Missing required --disconnect <path>');
    }
    const validSources = new Set([ 'kees1958', 'disconnect' ]);
    const only = values.only
        ? values.only.split(',').map(s => s.trim())
        : [ 'kees1958', 'disconnect' ];
    for ( const s of only ) {
        if ( !validSources.has(s) ) {
            throw new Error(`--only: unknown source "${s}" — must be one of ${[...validSources].join(', ')}`);
        }
    }
    values.only = only;
    return values;
}

/*==============================================================================
    STEP 1 — Kees1958's own list (live fetch, uBO/ABP filter syntax).
    Guard (C13a): validates response size and filter-list shape before
    ever parsing it — an empty/error response must never silently
    compile into the output.
==============================================================================*/
const UBO_HOSTNAME_RULE_RE = /^\|\|([a-z0-9.-]+)\^(?:\$.*)?$/i;

async function fetchKees1958Domains(url) {
    const resp = await fetch(url);
    if ( !resp.ok ) { throw new Error(`HTTP ${resp.status} fetching Kees1958 list: ${url}`); }
    const text = await resp.text();
    if ( text.length < CONFIG.MIN_RESPONSE_BYTES ) {
        throw new Error(`Suspiciously small Kees1958 response (${text.length} bytes) — aborting`);
    }
    if ( !text.includes('||') ) {
        throw new Error('Kees1958 response does not look like a filter list (no "||" rules found) — aborting');
    }

    const domains = new Set();
    for ( const line of text.split('\n') ) {
        const t = line.trim();
        if ( t === '' || t.startsWith('!') || t.startsWith('[') ) { continue; }
        const m = UBO_HOSTNAME_RULE_RE.exec(t);
        if ( m ) { domains.add(m[1].toLowerCase()); }
    }
    return domains;
}

/*==============================================================================
    STEP 2 — Disconnect (local file OR live fetch — accepts either a
    path or a URL, matching build-top1m-crossref.mjs's own convention).
==============================================================================*/
async function loadDisconnectData(servicesJsonPathOrUrl) {
    const isUrl = /^https?:\/\//.test(servicesJsonPathOrUrl);
    return isUrl
        ? await (await fetch(servicesJsonPathOrUrl)).json()
        : JSON.parse(await fs.readFile(servicesJsonPathOrUrl, 'utf8'));
}

function extractDisconnectDomains(raw, categories) {
    const domains = new Set();
    for ( const category of categories ) {
        const entries = raw.categories?.[category] ?? [];
        for ( const entry of entries ) {
            for ( const urlMap of Object.values(entry) ) {
                for ( const doms of Object.values(urlMap) ) {
                    if ( !Array.isArray(doms) ) { continue; }
                    for ( const d of doms ) { domains.add(d); }
                }
            }
        }
    }
    return domains;
}

// (Was STEP 3 — the reviewList safety filter (loadReviewListDomains(),
// applySafetyFilter()) — REMOVED entirely, per explicit request: both
// remaining sources (Kees1958, Disconnect) are used as-is, and nothing
// else in this file consumed it. The mechanism itself still exists and
// is still used elsewhere — tools/build-top1m-crossref.mjs still builds
// top1m-tracker-crossref.json using Ghostery's trackerdb as one of its
// two safety-classification inputs, feeding this project's OTHER
// filter-list checks — this removal is scoped to this one file, which
// had become the only place with a genuinely dead consumer of it.)

/*==============================================================================
    STEP 3 — emit one ABP-syntax source file for one already-filtered set.
==============================================================================*/
async function writeSourceFile(outputPath, title, sourceLabel, sourceCount, final, excluded, socialExcluded = [], filterApplied = true) {
    const sorted = [ ...final ].sort();
    const socialNote = socialExcluded.length > 0
        ? ` ${socialExcluded.length} further excluded as top-20 social media platform domains.`
        : '';
    // filterApplied distinguishes "checked against the safety filter,
    // found nothing to exclude" from "never checked at all" — these read
    // very differently and conflating them was a real, found-while-
    // implementing bug: "0 excluded via reviewList safety filter" for a
    // source the filter was never even run against implies a check that
    // didn't happen. Both current callers (Kees1958, Disconnect) now pass
    // filterApplied=false, per explicit request to use both as-is.
    const sourceLine = filterApplied
        ? `! Source: ${sourceLabel} (${sourceCount} domains); ${excluded.length} excluded via ` +
          `top1m-tracker-crossref.json's reviewList safety filter.${socialNote}`
        : `! Source: ${sourceLabel} (${sourceCount} domains); used as-is, no safety filter applied ` +
          `(per explicit request).`;
    const output = [
        '[AdBlockPlus 2.0]',
        '!',
        `! Title: ${title}`,
        '! Generated by tools/build-adtracking-sources.mjs — DO NOT EDIT BY HAND.',
        sourceLine,
        '!',
        ...sorted.map(d => `||${d}^$third-party`),
        '',
    ].join('\n');

    await fs.mkdir(path.dirname(outputPath), { recursive: true });
    await fs.writeFile(outputPath, output, 'utf8');
    console.log(`  Output written: ${outputPath} (${final.size} domains, ${filterApplied ? `${excluded.length}+${socialExcluded.length} excluded` : 'no filter applied'})`);
}

/*==============================================================================
    MAIN
==============================================================================*/
async function main() {
    const args = parseCliArgs();
    function wants(source) { return args.only.includes(source); }

    if ( wants('kees1958') ) {
    console.log('\nFetching Kees1958 ad+tracking list...');
    const kees1958Domains = await fetchKees1958Domains(args['kees1958-url']);
    console.log(`  ${kees1958Domains.size} unique domains`);
    {
        // Used AS-IS, per explicit request — no reviewList crossref.
        // Previously cross-referenced; see CHANGELOG for the removal.
        const final = kees1958Domains;
        const excluded = [];
        await writeSourceFile(
            CONFIG.KEES1958_OUTPUT_PATH,
            'Kees1958 most-used EU+US ads & tracking networks',
            'Kees1958', kees1958Domains.size, final, excluded, [], false
        );
    }
    } else {
        console.log('\nSkipping Kees1958 (not in --only scope) — kees1958-only-source.txt left unchanged.');
    }

    if ( wants('disconnect') ) {
    console.log('\nLoading Disconnect services.json...');
    const disconnectRaw = await loadDisconnectData(args.disconnect);
    for ( const group of DISCONNECT_CATEGORY_GROUPS ) {
        console.log(`\nDisconnect ${group.categories.join('+')}...`);
        const domains = extractDisconnectDomains(disconnectRaw, group.categories);
        console.log(`  ${domains.size} unique domains`);
        // Used AS-IS, per explicit request — no reviewList crossref, no
        // social-media exclusion. This group used to be two separate
        // groups (Advertising alone had no filter; Analytics/Cryptomining/
        // Fingerprinting did) — since they're now one merged list, the
        // "no filter" ruling for the Advertising half was extended to the
        // whole merged output, since a single list can't have the filter
        // applied to only part of itself. See CHANGELOG for the full
        // reasoning.
        const final = domains;
        const excluded = [];
        const socialExcluded = [];
        await writeSourceFile(
            path.resolve('data', `disconnect-${group.id}-source.txt`),
            group.title, `Disconnect ${group.categories.join('+')}`, domains.size, final, excluded, socialExcluded, false
        );
    }
    } else {
        console.log('\nSkipping Disconnect (not in --only scope) — disconnect-*-source.txt left unchanged.');
    }

    console.log('\nDone.');
}

main().catch(err => {
    console.error('Build failed:', err);
    process.exitCode = 1;
});
