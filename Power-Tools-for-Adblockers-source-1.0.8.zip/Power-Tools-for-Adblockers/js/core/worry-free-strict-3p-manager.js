/*******************************************************************************

    uBlock-Stripped-Dynamic — Worry-free strict 3P block manager

    Manages a small set of session-scoped chrome.declarativeNetRequest
    rules, present ONLY for the duration of an active Worry-free/"Never
    consent" session, for exactly the sites in compiled-filters.js's
    ADULT_SITE_MATCHES (24 domains: the curated high-risk site list —
    pornhub.com, xhamster.com, etc. — plus coveryourtracks.eff.org,
    added there for the same reason, see that file's own comment).

    Ported from Kees1958/3P-Matrix-lite's real "level 4" protection tier
    (github.com/Kees1958/3P-Matrix-lite, data/constants.js /
    core/rule-classifier.js / core/rule-builder.js) — same mechanism,
    same CDN-hostname regex, same spankbang.com/sb-cd.com exception,
    confirmed against that project's actual source rather than assumed.
    NOT the same tier system matrix-constants.js's own header says this
    fork deliberately didn't port wholesale (L1-L5 for the whole Matrix
    panel) — this is a narrow, purpose-specific replication of level 4's
    behavior for one small, fixed site list, not a general level system.

    Behavior, confirmed against the real source rather than assumed
    symmetric:
      - ALL third-party FRAMES from these sites: blocked, unconditionally,
        no CDN exception — 3P-Matrix-lite's own comment is explicit that
        "frames are blocked unconditionally at L4" regardless of the CDN
        allowance below.
      - ALL third-party SCRIPTS from these sites: blocked, EXCEPT ones
        whose hostname contains "cdn" (CDN_HOST_REGEX below, identical to
        3P-Matrix-lite's own) — own-CDN assets can still load.
      - spankbang.com specifically: its own CDN, sb-cd.com, is allowed as
        third-party for BOTH frame and script — 3P-Matrix-lite's own
        DEFAULT_MATRIX_ALLOW_OVERRIDES entry, ported verbatim. This is
        the one case that DOES get a frame exception, but only for this
        one named site/CDN pair, not a general rule.

    Design: absent by default (normal browsing), present for the
    duration of an active Worry-free session — INVERSE of worry-free-
    extra-manager.js's own suppression rule (which is present by default,
    absent during a session) — matching cookie-clicker-autodeny-manager.js's
    own active/inactive state exactly, since that IS the same session.

    Session rules (not dynamic) — same reasoning as worry-free-extra-
    manager.js's own header: resets to empty on a genuine browser restart,
    matching "normal browsing" being the natural resting state, and (see
    cookie-clicker-autodeny-manager.js's clearAutoDenyOnBrowserStartup())
    a genuine restart already always ends any lingering Worry-free session
    outright — so there's no scenario where these rules need to survive a
    real restart in a "should still be present" state.

*******************************************************************************/

import { dnr } from '../data/ext-compat.js';
import {
    STRICT_3P_RULES_BASE_ID,
    STRICT_3P_BLOCK_PRIORITY,
    STRICT_3P_CDN_SCRIPT_ALLOW_PRIORITY,
    STRICT_3P_SPANKBANG_ALLOW_PRIORITY,
} from './dnr-budgets.js';

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

// The 24 ADULT_SITE_MATCHES hostnames, bare (no scheme/wildcard) — DNR's
// initiatorDomains wants bare domains, not match-pattern syntax. Kept as
// an independent, explicit list rather than derived at runtime from
// compiled-filters.js's own wildcard-pattern array, since that module is
// the DNR-rule-building layer and importing it here for one string-
// transform would be a heavier coupling than this short, rarely-changed
// list justifies. If ADULT_SITE_MATCHES gains or loses a domain, this
// list needs the same edit — both are small and reviewed together.
const HIGH_RISK_HOSTNAMES = [
    'pornhub.com', 'xhamster.com', 'xvideos.com', 'xnxx.com', 'eporner.com',
    'redtube.com', 'tube8.com', 'xgroovy.com', 'xgroovy.tv', 'youporn.com',
    'spankbang.com', 'porntrex.com', 'onlyfans.com', 'theporndude.com',
    'xvideos.es', 'xhamsterlive.com', 'fpo.xxx', 'qorno.com', 'pornpics.com',
    'f95zone.to', 'xhamster19.com', 'beeg.com', 'tnaflix.com',
    'coveryourtracks.eff.org',
];

// Identical to 3P-Matrix-lite's own CDN_HOST_REGEX (data/constants.js) —
// matches "cdn" only within a URL's HOST portion, never path/query.
const CDN_HOST_REGEX = '^[a-z][a-z0-9+.-]*://[^/]*cdn[^/]*(/|$)';
// Always-valid fallback if the regex engine ever rejects the above (same
// defensive pattern 3P-Matrix-lite itself uses, checked once below) —
// looser (matches "cdn" anywhere in the full URL, not just the host),
// but never leaves the ruleset broken.
const CDN_URL_FILTER_FALLBACK = '*cdn*';

// spankbang.com's own CDN — ported verbatim from 3P-Matrix-lite's
// DEFAULT_MATRIX_ALLOW_OVERRIDES.
const SPANKBANG_HOSTNAME = 'spankbang.com';
const SPANKBANG_CDN_HOSTNAME = 'sb-cd.com';

const RULE_ID_FRAME_BLOCK        = STRICT_3P_RULES_BASE_ID;
const RULE_ID_SCRIPT_BLOCK       = STRICT_3P_RULES_BASE_ID + 1;
const RULE_ID_SCRIPT_CDN_ALLOW   = STRICT_3P_RULES_BASE_ID + 2;
const RULE_ID_SPANKBANG_CDN_ALLOW = STRICT_3P_RULES_BASE_ID + 3;
const ALL_RULE_IDS = [ RULE_ID_FRAME_BLOCK, RULE_ID_SCRIPT_BLOCK, RULE_ID_SCRIPT_CDN_ALLOW, RULE_ID_SPANKBANG_CDN_ALLOW ];

/******************************************************************************/

async function isCdnRegexSupported() {
    try {
        const result = await dnr.isRegexSupported({ regex: CDN_HOST_REGEX, isCaseSensitive: false });
        return result?.isSupported === true;
    } catch {
        return false; // couldn't check — use the always-valid fallback
    }
}

async function buildRules() {
    const cdnRegexOk = await isCdnRegexSupported();
    const cdnScriptCondition = cdnRegexOk
        ? { regexFilter: CDN_HOST_REGEX, isUrlFilterCaseSensitive: false }
        : { urlFilter: CDN_URL_FILTER_FALLBACK };

    return [
        // Frames: blocked unconditionally, no CDN exception — matches
        // 3P-Matrix-lite's own level-4 behavior exactly (see this file's
        // own header for the citation).
        {
            id: RULE_ID_FRAME_BLOCK,
            priority: STRICT_3P_BLOCK_PRIORITY,
            action: { type: 'block' },
            condition: {
                initiatorDomains: HIGH_RISK_HOSTNAMES,
                resourceTypes: [ 'sub_frame' ],
                domainType: 'thirdParty',
            },
        },
        // Scripts: blocked by default...
        {
            id: RULE_ID_SCRIPT_BLOCK,
            priority: STRICT_3P_BLOCK_PRIORITY,
            action: { type: 'block' },
            condition: {
                initiatorDomains: HIGH_RISK_HOSTNAMES,
                resourceTypes: [ 'script' ],
                domainType: 'thirdParty',
            },
        },
        // ...except a request whose own hostname contains "cdn".
        {
            id: RULE_ID_SCRIPT_CDN_ALLOW,
            priority: STRICT_3P_CDN_SCRIPT_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: Object.assign({
                initiatorDomains: HIGH_RISK_HOSTNAMES,
                resourceTypes: [ 'script' ],
                domainType: 'thirdParty',
            }, cdnScriptCondition),
        },
        // spankbang.com's own sb-cd.com CDN — frame AND script, the one
        // named exception that also covers frames.
        {
            id: RULE_ID_SPANKBANG_CDN_ALLOW,
            priority: STRICT_3P_SPANKBANG_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: {
                initiatorDomains: [ SPANKBANG_HOSTNAME ],
                requestDomains: [ SPANKBANG_CDN_HOSTNAME ],
                resourceTypes: [ 'sub_frame', 'script' ],
                domainType: 'thirdParty',
            },
        },
    ];
}

async function addRules() {
    try {
        const rules = await buildRules();
        await dnr.updateSessionRules({ addRules: rules, removeRuleIds: ALL_RULE_IDS });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-strict-3p-manager addRules:', reason);
    }
}

async function removeRules() {
    try {
        await dnr.updateSessionRules({ removeRuleIds: ALL_RULE_IDS });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-strict-3p-manager removeRules:', reason);
    }
}

/******************************************************************************/
// Public interface
/******************************************************************************/

// Called directly from startAutoDeny() — the session is becoming active
// RIGHT NOW, so the strict block rules must go on immediately.
export async function onWorryFreeSessionStart() {
    await addRules();
}

// Called directly from cancelAutoDeny()/expireAutoDeny() — the session
// just ended, so the strict block rules must come off immediately.
export async function onWorryFreeSessionEnd() {
    await removeRules();
}

// Re-derives the correct rule state from the persisted session state and
// fixes any mismatch — same reasoning and call sites as worry-free-
// extra-manager.js's own reconcileWorryFreeExtraSuppressionRule(). Kept
// even though clearAutoDenyOnBrowserStartup() already makes the genuine-
// browser-restart case moot (a real restart always ends the session
// outright, so these rules should never need to survive one) — this
// still guards a plain SW-cold-start mismatch, the same case
// reconcileWorryFreeExtraSuppressionRule() itself guards for its own,
// oppositely-signed rule.
export async function reconcileWorryFreeStrict3pRules(isActive) {
    let rules = [];
    try {
        rules = await dnr.getSessionRules();
    } catch {
        return; // couldn't read session rules — leave alone
    }
    const present = ALL_RULE_IDS.every(id => rules.some(r => r.id === id));
    if ( isActive === true && !present ) { await addRules(); }
    else if ( isActive !== true && present ) { await removeRules(); }
}
