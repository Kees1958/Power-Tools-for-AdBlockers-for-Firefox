/*******************************************************************************

    uBlock Origin - a comprehensive, efficient content blocker
    Copyright (C) 2026-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/******************************************************************************/
//
// Architecture note: this module holds the pure filter-compiling logic
// (parsing custom filters into DNR rules / cosmetic scripts). It has no
// side effects at import time and no messaging — the caller
// (js/core/compiled-filters.js) calls its exports directly, in-process,
// since Firefox's background context (an event page, not a restricted
// service worker) has no dynamic-module-import restriction requiring a
// separate offscreen-document execution context. This module used to
// live under js/offscreen/ and run inside a Chrome-only offscreen
// document; that mechanism has been removed entirely (Firefox-only
// codebase — see CHANGELOG). See ARCHITECTURE.md for the five-tier
// model this module now participates in directly (core/).
//
// Exception to the tier model's core/ -> util/, data/ dependency rule:
// this module imports from ../ui/ (static-filtering-parser.js,
// ubo-parser.js) because those are shared parsing modules also used by
// the dashboard's filter editor, not page-presentation code despite
// their folder. This exception predates this module's move into core/
// (it applied equally when this code lived in the offscreen/ folder,
// which was itself outside the tier model) — noted here rather than
// left implicit now that the module is inside the tier model.
//
/******************************************************************************/

import * as sfp from '../../ui/static-filtering-parser.js';
import { minimizeRules, minimizeRuleset, validateRules } from '../../ui/ubo-parser.js';
import { makeCosmeticScripts } from './make-cosmetic-filters.js';
import { parseNetworkFilter } from '../../ui/ubo-parser.js';
import { safeReplace } from './safe-replace.js';
import { dnr } from '../../data/ext-compat.js';
import { webext } from '../../data/ext-compat.js';

/******************************************************************************/

// Resource-type strings needed by parseNetworkFilter() below. Previously
// fetched via a message round-trip to the service worker because the
// offscreen document couldn't access declarativeNetRequest directly —
// no longer needed now that this code runs in the background context,
// where `dnr` (../../data/ext-compat.js) is already available.
const resourceTypes = Object.values(dnr.ResourceType);

/******************************************************************************/


/******************************************************************************/

export function compileCosmeticFilter(parser, output) {
    const { compiled, exception } = parser.result;
    if ( compiled === undefined ) { return; }
    const sanitized = sanitizeCompiledCosmeticFilter(compiled);
    const matches = [];
    const excludeMatches = [];
    for ( const { hn, not, bad } of parser.getExtFilterDomainIterator() ) {
        if ( bad ) { continue; }
        if ( not && exception ) { continue; }
        if ( not || exception ) {
            excludeMatches.push(hn);
        } else if ( hn === '*' ) {
            if ( parser.options.trustedSource !== true ) { continue; }
            matches.length = 0;
            matches.push('*');
        } else {
            if ( matches[0] === '*' ) { continue; }
            matches.push(hn);
        }
    }
    // This should not happen
    if ( matches.length === 0 && excludeMatches.length === 0 ) { return; }
    // Only negated hostnames => generic cosmetic filter
    if ( exception === false ) {
        if ( matches.length === 0 && excludeMatches.length !== 0 ) { return; }
    }
    const details = output.get(sanitized) ?? {};
    if ( details.matches === undefined ) {
        details.matches = [];
        details.excludeMatches = [];
        output.set(sanitized, details);
    }
    if ( matches.length ) {
        if ( matches.includes('*') ) {
            details.matches = [ '*' ];
        } else if ( details.matches.includes('*') === false ) {
            details.matches.push(...matches);
        }
    }
    if ( excludeMatches.length ) {
        details.excludeMatches.push(...excludeMatches);
    }
}

function sanitizeCompiledCosmeticFilter(compiled) {
    if ( compiled.startsWith('{') === false ) { return compiled; }
    const parsed = JSON.parse(compiled);
    parsed.raw = undefined;
    return JSON.stringify(parsed);
}

/******************************************************************************/

export function compileFilters(listid, text, context = {}) {
    if ( Boolean(text) === false ) { return; }

    const parser = new sfp.AstFilterParser(context);

    const unminimizedRules = [];
    const specificCosmeticDetails = new Map();

    const lines = text.split(/\n/).map(a => a.trim());
    const filterStats = {
       total: 0,
       accepted: 0,
       rejected: 0,
    };
    for ( const line of lines ) {
        parser.parse(line);
        if ( parser.hasError() ) { continue; }
        // Scriptlet rules (+js()) are silently skipped — the userScripts
        // permission has been removed and scriptlet output is not registered.
        if ( parser.isScriptletFilter() ) { continue; }
        if ( parser.isCosmeticFilter() ) {
            if ( parser.hasOptions() === false ) { continue; }
            compileCosmeticFilter(parser, specificCosmeticDetails);
            continue;
        }
        if ( parser.isNetworkFilter() ) {
            filterStats.total += 1;
            const rule = parseNetworkFilter(parser, {
                resourceTypes,
            });
            if ( rule ) {
                unminimizedRules.push(rule);
                filterStats.accepted += 1;
            } else {
                filterStats.rejected += 1;
            }
            continue;
        }
    }

    let minimizedRules = minimizeRuleset(unminimizedRules);
    minimizedRules = minimizeRules(minimizedRules);
    minimizedRules = validateRules(minimizedRules);
    const regexRuleCount = minimizedRules.reduce((a, b) => {
        return b.condition.regexFilter ? a+1 : a;
    }, 0);

    return {
        filterStats,
        ruleStats: {
            total: minimizedRules.length,
            plain: minimizedRules.length - regexRuleCount,
            regex: regexRuleCount,
        },
        dnrRules: minimizedRules,
        specificCosmeticDetails,
    };
}

/******************************************************************************/

export async function toMv3Data(rulesetid, compiledData) {
    const isolated = [];

    if ( Boolean(compiledData) === false ) { return; }

    if ( compiledData.specificCosmeticDetails.size ) {
        const result = makeCosmeticScripts(rulesetid, compiledData.specificCosmeticDetails);
        if ( result ) {
            const [
                cssAPI,
                isolatedAPI,
                proceduralAPI,
                template,
            ] = await Promise.all([
                fetch(webext.runtime.getURL('js/scripting/css-api.js')).then(response => response.text()),
                fetch(webext.runtime.getURL('js/scripting/isolated-api.js')).then(response => response.text()),
                fetch(webext.runtime.getURL('js/scripting/css-procedural-api.js')).then(response => response.text()),
                fetch(webext.runtime.getURL('js/core/filter-compiler/css-compiled.template.js')).then(response => response.text()),
            ]);
            const code = [
                cssAPI,
                isolatedAPI,
                proceduralAPI,
                safeReplace(template, 'self.$cssSpecificData$', JSON.stringify(result.data)),
            ].join('\n');
            const hostnames = result.data.hasEntities || result.data.regexes.length
                ? '*'
                : result.data.hostnames;
            isolated.push({
                id: `${rulesetid}-css-specific`,
                code,
                hostnames,
            });
        }
    }

    const output = {}
    if ( compiledData.dnrRules.length ) {
        output.dnrRules = minimizeRuleset(compiledData.dnrRules);
        output.dnrRules = minimizeRules(output.dnrRules);
        output.dnrRules = validateRules(output.dnrRules);
    }
    if ( isolated.length ) {
        output.isolated = isolated;
    }

    return output;
}

/******************************************************************************/
