/*
 * tracker-radar-lookup.js — Domain -> known-tracker lookup
 *
 * Public interface:
 *   preloadTrackerRadarData() — kicks off the dynamic import of the dataset
 *                             and builds the lookup Map, once per SW
 *                             lifetime. Call unawaited (fire-and-forget) —
 *                             see this function's own comment for why.
 *   lookupTracker(domain)   — returns { owner, onPGL, fingerprinting }
 *                             or null. Fully synchronous; safe to call
 *                             before preloadTrackerRadarData() resolves
 *                             (returns null for everything until then,
 *                             never throws).
 *   resetTrackerRadarCache() — drops the built lookup Map AND the cached
 *                              dataset module/in-flight promise (release
 *                              guard; forces a fresh preload+rebuild on the
 *                              next preloadTrackerRadarData() call — used
 *                              after a dataset update ships, or by tests)
 *
 * Wraps js/data/tracker-radar-data.js (the compacted DuckDuckGo Tracker
 * Radar dataset — see that file's header for build parameters/provenance).
 *
 * BRAVE VARIANT — ported verbatim from uBlock-Stripped-Dynamic v9.2.6
 * (the last version to have this module before the parent project
 * removed it entirely in v9.3.0, judging the old merged "breakage risk"
 * column redundant with Worry-Free mode's own filtering). Re-added here
 * per explicit request: AdShield Extra's Brave/power-user audience
 * specifically wanted this signal back, in a simpler form than the old
 * breakage-risk merge — see matrix-panel.js's own "known tracker" Y/N
 * column, its only consumer. This module does nothing on its own; it has
 * no listeners, no timers, no background activity. The Map below is
 * built once (lazy, via preloadTrackerRadarData() — see that function's
 * own comment for why it's no longer a synchronous first-lookup build)
 * and kept for the service worker's lifetime — cheap enough (2,082
 * entries) that rebuilding per session would be wasted work, but the
 * module still exposes an explicit release path.
 *
 * Porting note (uBlock-Stripped-Dynamic v9.4.9, item 2): previously
 * `import { TRACKER_RADAR_DATA } from '../data/tracker-radar-data.js'`
 * was a static top-level import, so this ~73KB dataset (2,082 entries)
 * parsed on every service-worker cold start, regardless of whether the
 * Matrix panel was ever opened in that session. A first fix attempt — a
 * dynamic import() inside lookupTracker() itself — was wrong and would
 * have been wrong here too: lookupTracker() is called synchronously from
 * matrix-panel.js's live webRequest listener, which fires on every
 * network request while a Matrix session is active, so making it async
 * would ripple async overhead into a per-request hot path. Correct fix:
 * dynamic import moved into an explicit preload function
 * (preloadTrackerRadarData(), below), called unawaited as the very first
 * line of startMatrix() in matrix-panel.js — runs in parallel with that
 * function's own setup and the tab reload it ends with, both of which
 * take far longer than this dataset's own load time. lookupTracker()
 * itself stays fully synchronous throughout, reading from the
 * module-level Map below (empty until the preload resolves).
 */

/******************************************************************************/
// Lazy-built lookup Map. Empty (not null) until preloadTrackerRadarData()
// resolves, so lookupTracker() can stay synchronous and safe to call at
// any time — see that function's own comment.
/******************************************************************************/

let domainToTrackerInfo = new Map();

// Caches the in-flight/resolved preload promise itself (not just its
// result) so a second preloadTrackerRadarData() call in the same SW
// lifetime — e.g. a second Matrix session started before the first
// dynamic import() finished — awaits the SAME import rather than kicking
// off a redundant second one.
let preloadPromise = null;

/******************************************************************************/
// Public API
/******************************************************************************/

// Kicks off the dynamic import of js/data/tracker-radar-data.js and builds
// domainToTrackerInfo from it. Deliberately NOT awaited by its caller
// (startMatrix() in matrix-panel.js) — this function returns a promise so
// a caller COULD await it if ever needed (e.g. tests), but the whole
// point of moving the import here was to let it run in parallel with the
// rest of session start, not to block on it. Safe to call more than once
// per SW lifetime — the second call reuses preloadPromise instead of
// re-importing.
export function preloadTrackerRadarData() {
    if ( preloadPromise !== null ) { return preloadPromise; }

    preloadPromise = import('../data/tracker-radar-data.js').then(({ TRACKER_RADAR_DATA }) => {
        const built = new Map();
        const { entities, domains } = TRACKER_RADAR_DATA;

        for ( const domain in domains ) {
            const [ entityIndex, onPGL, fingerprinting ] = domains[domain];
            built.set(domain, {
                owner: entities[entityIndex] ?? 'Unknown',
                // Peter Lowe's Ad and tracking server list membership (exact
                // domain match) — the Matrix panel's breakage-risk GREEN
                // signal. See tracker-radar-data.js's header for full
                // provenance; this used to be a numeric 'prevalence' field,
                // dropped in favor of this more directly actionable boolean.
                onPGL,
                // DDG's own 0-3 fingerprinting-API-use score — see
                // js/data/tracker-radar-data.js's header comment for exactly
                // what each level means. Drives the monitor panel's API-misuse
                // color indicator.
                fingerprinting,
            });
        }

        domainToTrackerInfo = built;
    }).catch(reason => {
        // Degrade safely: leave domainToTrackerInfo as whatever it already
        // was (empty, on first failure) rather than throwing into
        // startMatrix()'s unawaited call. lookupTracker() keeps returning
        // null for everything, same as before any preload ever ran.
        console.error('[uBlock-Dynamic] preloadTrackerRadarData:', reason);
    });

    return preloadPromise;
}

// domain is expected to already be reduced to eTLD+1 (see
// matrix-classifier.js's etldPlusOne) — this module does no normalization of
// its own, to avoid a second copy of that suffix logic.
export function lookupTracker(domain) {
    return domainToTrackerInfo.get(domain) ?? null;
}

// Release guard: drop the built Map AND the cached preload promise, so the
// next preloadTrackerRadarData() call re-imports and rebuilds fresh
// instead of reusing the old cached promise/data. Not called during
// normal operation today — exposed for a future "dataset updated, don't
// wait for SW restart" path and for tests.
export function resetTrackerRadarCache() {
    domainToTrackerInfo = new Map();
    preloadPromise = null;
}
