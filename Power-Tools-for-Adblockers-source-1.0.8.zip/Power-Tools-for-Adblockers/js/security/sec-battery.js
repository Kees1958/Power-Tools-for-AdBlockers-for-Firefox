/*
 * sec-battery.js — Security scriptlet: worryFreeAntiFingerprintEnabled toggle
 *
 * Battery Status API mitigation — logic extracted VERBATIM from
 * js/security/sec-adult-fingerprint.js's own already-proven
 * navigator.getBattery() interceptor (C21: reuse a proven
 * implementation, don't write a new one). Firefox and Safari removed
 * the Battery Status API entirely, specifically because battery level +
 * charging time turned out to be a precise cross-session fingerprint
 * with no comparably strong legitimate use case — see
 * sec-adult-fingerprint.js's own header for the full reasoning.
 *
 * Unlike sec-adult-fingerprint.js (applied unconditionally on a curated
 * high-risk site list), this file is applied SITEWIDE but ONLY for the
 * duration of an active Worry-free session with this specific toggle
 * enabled — see js/core/compiled-filters.js's SECURITY_SCRIPTLETS entry
 * for this file (worryFreeAntiFingerprintOverride) and
 * js/core/scripting-manager.js's isWorryFreeAntiFingerprintActive
 * computation for the gating.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){
    'use strict';

    // ── Battery status fingerprinting ────────────────────────────────────────
    // Uses Object.getPrototypeOf(navigator) rather than the bare `Navigator`
    // global — this content-script environment's lint globals only declare
    // the lowercase `navigator` instance, not the `Navigator` interface
    // constructor (same reasoning as sec-adult-fingerprint.js's own comment).
    const navigatorProto = Object.getPrototypeOf(navigator);
    if ( typeof navigatorProto.getBattery === 'function' ) {
        navigatorProto.getBattery = new Proxy(navigatorProto.getBattery, { apply: function() {
            console.info('[uBol] blocked navigator.getBattery read');
            return Promise.reject(new TypeError('getBattery is blocked on this site'));
        } });
    }
})();
