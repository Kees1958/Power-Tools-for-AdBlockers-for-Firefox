/* Strict eval blocker for the adult-site match list in compiled-filters.js. */
'use strict';
(function(){
    'use strict';
    const nativeEval = window.eval;
    window.eval = function() {
        console.info('[uBol] strict eval blocked');
        return undefined;
    };
    window.eval.toString = nativeEval.toString.bind(nativeEval);
})();
