/*
 * mode-routes.js — Site-mode / filtering-mode message-route adapters
 *
 * Same three-layer split as matrix-routes.js / security-routes.js /
 * ruleset-routes.js (see matrix-routes.js's own header for the full
 * rationale):
 *   Layer 1 — message-routes.js:  POLICY
 *   Layer 2 — this file:          ADAPTER
 *   Layer 3 — mode-manager.js, site-mode-manager.js, scripting-manager.js
 *             — the actual logic
 *
 * Largest of the four route files split out of background.js so far (10
 * handlers) — this is the last piece of "target #2" (mode/security/
 * ruleset routes), after security-routes.js and ruleset-routes.js.
 *
 * refreshToolbarIconsForOpenTabs() moved here alongside its only caller
 * (handleSetFilteringModeDetails) rather than staying in background.js —
 * it had exactly one external call site, confirmed by grep before moving,
 * same verification standard as every other relocation in this series.
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleSiteModeGet, handleSiteModeGetAll, handleSiteModeSet,
 *   handleSiteModeSetAll, handleGetFilteringMode, handleSetFilteringMode,
 *   handleGetFilteringModeDetails, handleSetFilteringModeDetails,
 *   handleGetDefaultFilteringMode, handleSetDefaultFilteringMode
 */

import { browser, localRead, localWrite } from '../data/ext.js';
import { broadcastMessage } from '../data/broadcast.js';

import {
    getDefaultFilteringMode,
    getFilteringMode,
    getFilteringModeDetails,
    setDefaultFilteringMode,
    setFilteringMode,
    setFilteringModeDetails,
    setFilteringModesBulk,
} from '../core/mode-manager.js';

import {
    applySiteMode,
    getSiteMode,
    invalidateSiteModeCache,
    filteringLevelForMode,
    SITE_MODE_DEFAULT,
} from '../core/site-mode-manager.js';

import {
    registerContentScripts,
    registerSecurityContentScripts,
    registerCookieClickerContentScripts,
    registerCookieClickerAutoDenyContentScripts,
} from '../core/scripting-manager.js';

import { setToolbarIconForLevel } from '../core/action.js';

/******************************************************************************/

async function refreshToolbarIconsForOpenTabs() {
    const tabs = await browser.tabs.query({}).catch(reason => {
        console.error(`[uBlock-Dynamic] refreshToolbarIconsForOpenTabs/tabs.query/${reason}`);
        return [];
    });
    await Promise.all(tabs.map(async tab => {
        if ( typeof tab.id !== 'number' ) { return; }
        let hostname;
        try {
            hostname = new URL(tab.url).hostname;
        } catch {
            return;
        }
        if ( hostname === '' ) { return; }
        const level = await getFilteringMode(hostname);
        try {
            await setToolbarIconForLevel(tab.id, level);
        } catch(reason) {
            console.error(`[uBlock-Dynamic] refreshToolbarIconsForOpenTabs/setIcon/${reason}`);
        }
    }));
}

/******************************************************************************/
// 4-way site mode / allowlist
/******************************************************************************/

export async function handleSiteModeGet(request) {
    const mode = await getSiteMode(request.hostname);
    return { mode };
}

export async function handleSiteModeGetAll() {
    const all = await localRead('siteModes') ?? {};
    return all;
}

export async function handleSiteModeSet(request) {
    const { hostname, mode, tabId } = request;
    // BUG FIX (ported from uBlock-Stripped-Dynamic's own Privacy &
    // Security porting work, found there after this same redesign):
    // registerContentScripts()/registerSecurityContentScripts() were
    // already correctly re-run on every site-mode change, but
    // registerCookieClickerContentScripts()/
    // registerCookieClickerAutoDenyContentScripts() — a THIRD,
    // independently site-mode-scoped content-script group (see
    // scripting-manager.js's own buildSiteModeMatchScope() call in
    // both) — were never included. A site toggled off then back on
    // kept using whichever scope was in effect the last time cookie-
    // clicker happened to be registered (e.g. extension startup), which
    // could silently exclude that site — previously-working
    // cookie-consent-clicker rules would stop firing with no error
    // anywhere, since the rules themselves were still correctly stored.
    const result = await applySiteMode(hostname, mode, tabId, {
        setFilteringMode,
        registerContentScripts,
        registerSecurityContentScripts,
        registerCookieClickerContentScripts,
        registerCookieClickerAutoDenyContentScripts,
    });
    return result;
}

export async function handleSiteModeSetAll(request) {
    const { siteModes: newModes } = request;
    if ( newModes instanceof Object === false ) { return {}; }
    const oldModes = await localRead('siteModes') ?? {};
    await localWrite('siteModes', newModes);
    invalidateSiteModeCache();
    // BUG FIX: this used to only write storage. That left a domain
    // typed into the Allow list editor looking saved while filtering
    // stayed fully active for it — the single-site toggle path
    // (applySiteMode(), above) always calls setFilteringMode() to
    // write the actual DNR exemption rule; this bulk path never did.
    //
    // BUG FIX (this release): the fix above only reconciled hostnames
    // whose mode differed from the CURRENTLY STORED 'siteModes' — the
    // same storage this diff compares against. If filteringModeDetails
    // (the actual DNR-backing state) ever desynced from 'siteModes' at
    // some point in the past (e.g. an entry saved before the bug fix
    // above existed, so it was never given a matching setFilteringMode()
    // call), every subsequent save would see "no change" for that
    // hostname and never re-sync it — the desync became permanently
    // stuck, surviving indefinitely even after the code was fixed,
    // because the stored data carried the bug forward. Reconciling every
    // hostname in the UNION of old+new unconditionally, on every save —
    // not gated on a diff — makes each save self-healing: any existing
    // desync gets corrected the next time the person saves anything via
    // the editor, without needing them to manually touch each entry.
    // Slightly more work per save (a redundant read-modify-write for
    // truly-unchanged entries) in exchange for removing this whole class
    // of "the diff got it wrong somehow" bugs — reuses the existing,
    // well-tested setFilteringMode()/applyFilteringMode() per-hostname
    // logic rather than rebuilding the none/basic Sets directly here,
    // which would risk a new bug in that function's hierarchy/subtree-
    // pruning logic (see mode-manager.js's pruneHostnameFromSet()/
    // pruneDescendantHostnamesFromSet()).
    const allHostnames = new Set([ ...Object.keys(oldModes), ...Object.keys(newModes) ]);
    // Porting note (v9.4.9, item 7): was a loop calling setFilteringMode()
    // once per hostname — N full read-modify-write storage round trips and
    // N native DNR rebuilds for N hostnames. setFilteringModesBulk() does
    // one of each instead, reusing the exact same per-hostname mutation
    // logic (applyFilteringMode()) internally — see that function's own
    // comment in mode-manager.js.
    const hostnameLevelPairs = [ ...allHostnames ].map(hostname => {
        const mode = newModes[hostname] ?? SITE_MODE_DEFAULT;
        return [ hostname, filteringLevelForMode(mode) ];
    });
    if ( hostnameLevelPairs.length > 0 ) {
        await setFilteringModesBulk(hostnameLevelPairs);
    }
    if ( allHostnames.size > 0 ) {
        // BUG FIX — same missing-registration class as
        // handleSiteModeSet()'s own comment above: cookie-clicker's two
        // independently site-mode-scoped content-script groups were
        // never included here either.
        await Promise.all([
            registerContentScripts(),
            registerSecurityContentScripts(),
            registerCookieClickerContentScripts(),
            registerCookieClickerAutoDenyContentScripts(),
        ]);
    }
    // Same caveat applySiteMode() documents for the single-site path:
    // an already-open tab for a changed hostname needs a manual reload
    // to actually stop already-injected scriptlets or clear an
    // already-applied block count — this bulk path affects potentially
    // many hostnames at once, so it does not force-reload every
    // matching open tab automatically.
    return newModes;
}

/******************************************************************************/
// Filtering mode (levels)
/******************************************************************************/

export async function handleGetFilteringMode(request) {
    return getFilteringMode(request.hostname);
}

export async function handleSetFilteringMode(request) {
    const beforeLevel = await getFilteringMode(request.hostname);
    if ( request.level === beforeLevel ) { return beforeLevel; }
    const afterLevel = await setFilteringMode(request.hostname, request.level);
    await registerContentScripts();
    if ( typeof request.tabId === 'number' ) {
        setToolbarIconForLevel(request.tabId, afterLevel);
    }
    return afterLevel;
}

export async function handleGetFilteringModeDetails() {
    return getFilteringModeDetails(true);
}

export async function handleSetFilteringModeDetails(request) {
    await setFilteringModeDetails(request.modes);
    await registerContentScripts();
    const defaultFilteringMode = await getDefaultFilteringMode();
    broadcastMessage({ defaultFilteringMode });
    refreshToolbarIconsForOpenTabs();
    return getFilteringModeDetails(true);
}

export async function handleGetDefaultFilteringMode() {
    return getDefaultFilteringMode();
}

export async function handleSetDefaultFilteringMode(request) {
    const beforeLevel = await getDefaultFilteringMode();
    const afterLevel = await setDefaultFilteringMode(request.level);
    if ( afterLevel !== beforeLevel ) {
        await registerContentScripts();
    }
    return afterLevel;
}

/******************************************************************************/
