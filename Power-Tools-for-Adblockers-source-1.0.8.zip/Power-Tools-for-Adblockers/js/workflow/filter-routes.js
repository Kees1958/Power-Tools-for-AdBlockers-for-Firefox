/*
 * filter-routes.js — Custom cosmetic filter / CSS-injection message-route
 * adapters
 *
 * Same three-layer split as matrix-routes.js / security-routes.js /
 * ruleset-routes.js / mode-routes.js (see matrix-routes.js's own header
 * for the full rationale):
 *   Layer 1 — message-routes.js:  POLICY
 *   Layer 2 — this file:          ADAPTER
 *   Layer 3 — core/filter-manager.js — the actual logic
 *
 * Named filter-routes.js (domain noun), not filter-manager-routes.js
 * (module name) — matching the naming convention the other four route
 * files already established (matrix-/security-/ruleset-/mode-routes.js
 * are all named after the feature domain, not the core/ module they
 * happen to call into).
 *
 * Three of these ten (handleInsertCSS, handleRemoveCSS,
 * handleInjectCSSProceduralAPI) are the lowest-level CSS-injection bridge
 * — plain browser.scripting calls, no filter-manager.js logic involved at
 * all — grouped here anyway because they're the mechanism
 * startCustomFilters()/injectCustomFilters() build on top of, not because
 * they share an implementation with the other seven.
 *
 * Deliberately NOT included here: handleGetSandboxFilters/
 * handleSetSandboxFilters, which stay in background.js — see the doc
 * comment directly on those two handlers (and REFACTOR_PLAN.md) for why
 * splitting them wouldn't map to anything real underneath.
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleInsertCSS, handleRemoveCSS, handleInjectCSSProceduralAPI,
 *   handleStartCustomFilters, handleTerminateCustomFilters,
 *   handleInjectCustomFilters, handleAddCustomFilters,
 *   handleClearCosmeticRules, handleDeleteCosmeticRule,
 *   handleGetCustomCosmeticRules
 *
 * Trust-boundary hardening (security-audit pass, see Security_evaluatie.md):
 * every route in this file is CONTENT_SCRIPT or ANY classified in
 * message-routes.js, meaning dispatchRoutedMessage() applies no origin
 * check at all before calling in here — see isFromThisExtension()/
 * trustedHostnameFromSender() below, both ported from the identical
 * pattern already used by privacy-inspector-routes.js and
 * custom-scriptlets.js/cookie-clicker-routes.js's own sender.url-based
 * hostname derivation.
 */

import { browser, webextFlavor, runtime } from '../data/ext.js';
import { isScriptlet } from '../util/utils.js';

import {
    startCustomFilters,
    terminateCustomFilters,
    injectCustomFilters,
    addCustomFilters,
    clearAllCustomFilters,
    deleteCustomFilter,
    getAllCustomFiltersWithDates,
} from '../core/filter-manager.js';

import { registerContentScripts } from '../core/scripting-manager.js';
import { updateCompiledFilters } from '../core/compiled-filters.js';

// ── Trust-boundary hardening (security-audit pass — Security_evaluatie.md) ──
// Every handler below is reachable with CONTENT_SCRIPT or ANY sender
// classification (see message-routes.js's SENDER_KINDS — neither gets an
// isTrustedOrigin() check at the routing layer), so each one validates its
// own sender/data here, same posture privacy-inspector-routes.js's
// handlePrivacyInspectorEvent()/handleGetMatchingScriptletRules() already
// established for the identical situation.

// sender.id is always the extension's own id for a genuine message reaching
// this listener — Chrome stamps it, page content can't forge it — so this
// is defense-in-depth, not a fix for an exploitable gap today. Same exact
// check, same reasoning, as privacy-inspector-routes.js's two content-
// script-sourced handlers (see that file's own comment on why it's needed
// even though CONTENT_SCRIPT routes get no routing-layer origin check).
function isFromThisExtension(sender) {
    return sender?.id === runtime.id;
}

// Derives the hostname a content-script- or picker-relayed message is
// really operating on — never trust a request-supplied hostname directly.
// Real reason: css-user.js/tool-overlay.js derive their hostname from
// `document.baseURI`, which a page can spoof via `<base href="...">`
// before the content script ever reads it. `sender.url`/`sender.tab.url`
// are Chrome's own authoritative record of the frame's/tab's URL and are
// not something page content can rewrite — same proven pattern already
// used by custom-scriptlets.js's injectCustomScriptletsForFrame() call
// site and privacy-inspector.js's recordPrivacyInspectorEvent() ("never
// trust tabId alone", sender.url || sender.tab?.url for the frame's own
// URL) — ported here rather than re-derived, per this project's own
// reuse-a-proven-solution convention.
//
// preferTabUrl: the picker's own UI (picker.js) runs inside a TRUSTED
// chrome-extension://<id>/picker/picker.html iframe overlaid on the real
// page (see tool-overlay.js's install()) — for messages it sends,
// sender.url is the IFRAME's own extension-origin URL, not the page being
// picked from; sender.tab.url (the tab hosting that iframe) is the value
// that actually means "the page the user is picking on". For a genuine
// page-context content script (css-user.js), sender.url already is the
// correct frame URL and should be preferred.
function trustedHostnameFromSender(sender, { preferTabUrl = false } = {}) {
    const url = preferTabUrl
        ? (sender?.tab?.url || sender?.url || '')
        : (sender?.url || sender?.tab?.url || '');
    try {
        return new URL(url).hostname;
    } catch {
        return '';
    }
}

// Shared benign-race check — ported verbatim from filter-manager.js's
// injectCustomFilters() (see that function's own comment for the full
// explanation: a content script reports its own frame ID, then that
// frame navigates away before the SW's async scripting.* call actually
// runs; there is no API to check frame liveness beforehand, so the
// reject is unavoidable and harmless). Reused here rather than
// reimplemented, per this project's own reuse-a-proven-solution
// principle — same three substrings, same downgrade-to-warn reasoning
// (Chrome/Brave's extension Errors panel surfaces console.error, not
// console.warn — this is what actually stops the benign case from
// showing up there while still being visible in the regular console).
function isFrameGoneError(reason) {
    const msg = String(reason);
    return msg.includes('No frame with id') ||
           msg.includes('No tab with id') ||
           msg.includes('Frame with ID');
}

/******************************************************************************/
// Low-level CSS-injection bridge (no filter-manager.js involved)
/******************************************************************************/

export async function handleInsertCSS(request, sender, tabId, frameId) {
    if ( isFromThisExtension(sender) === false ) { return false; }
    if ( frameId === false ) { return false; }
    // https://bugs.webkit.org/show_bug.cgi?id=262491
    if ( frameId !== 0 && webextFlavor === 'safari' ) { return; }
    return browser.scripting.insertCSS({
        css: request.css,
        origin: 'USER',
        target: { tabId, frameIds: [ frameId ] },
    }).catch(reason => {
        if ( isFrameGoneError(reason) ) {
            console.warn(`[uBlock-Dynamic] insertCSS: frame gone (${reason})`);
        } else {
            console.error(`[uBlock-Dynamic] insertCSS/${reason}`);
        }
    });
}

export async function handleRemoveCSS(request, sender, tabId, frameId) {
    if ( isFromThisExtension(sender) === false ) { return false; }
    if ( frameId === false ) { return false; }
    // https://bugs.webkit.org/show_bug.cgi?id=262491
    if ( frameId !== 0 && webextFlavor === 'safari' ) { return; }
    return browser.scripting.removeCSS({
        css: request.css,
        origin: 'USER',
        target: { tabId, frameIds: [ frameId ] },
    }).catch(reason => {
        if ( isFrameGoneError(reason) ) {
            console.warn(`[uBlock-Dynamic] removeCSS: frame gone (${reason})`);
        } else {
            console.error(`[uBlock-Dynamic] removeCSS/${reason}`);
        }
    });
}

export async function handleInjectCSSProceduralAPI(request, sender, tabId, frameId) {
    if ( isFromThisExtension(sender) === false ) { return; }
    return browser.scripting.executeScript({
        files: [ '/js/scripting/css-procedural-api.js' ],
        target: { tabId, frameIds: [ frameId ] },
        injectImmediately: true,
    }).catch(reason => {
        if ( isFrameGoneError(reason) ) {
            console.warn(`[uBlock-Dynamic] executeScript: frame gone (${reason})`);
        } else {
            console.error(`[uBlock-Dynamic] executeScript/${reason}`);
        }
    });
}

/******************************************************************************/
// filter-manager.js delegation
/******************************************************************************/

export async function handleStartCustomFilters(request, sender, tabId, frameId) {
    if ( isFromThisExtension(sender) === false ) { return; }
    if ( frameId === false ) { return; }
    return startCustomFilters(tabId, frameId);
}

export async function handleTerminateCustomFilters(request, sender, tabId, frameId) {
    if ( isFromThisExtension(sender) === false ) { return; }
    if ( frameId === false ) { return; }
    return terminateCustomFilters(tabId, frameId);
}

export async function handleInjectCustomFilters(request, sender, tabId, frameId) {
    if ( isFromThisExtension(sender) === false ) { return; }
    if ( frameId === false ) { return; }
    // WARNING FOR IMPLEMENTATION IMPACT: hostname is now derived from
    // sender.url/sender.tab.url, not request.hostname — a page that
    // spoofs document.baseURI via <base href> can no longer make this
    // handler look up or apply another hostname's stored custom filters.
    // For every legitimate call (css-user.js, unmodified page) this is
    // the same value document.baseURI would have reported anyway.
    const hostname = trustedHostnameFromSender(sender);
    if ( hostname === '' ) { return; }
    return injectCustomFilters(tabId, frameId, hostname);
}

export async function handleAddCustomFilters(request, sender) {
    if ( isFromThisExtension(sender) === false ) { return; }
    if ( Array.isArray(request.selectors) === false ) { return; }
    // WARNING FOR IMPLEMENTATION IMPACT: hostname is now derived from
    // sender.tab.url (the tab hosting the picker's trusted iframe), not
    // request.hostname (relayed from the page's own document.baseURI via
    // postMessage — spoofable with <base href>). A picked selector is now
    // always saved under the real page's hostname, never a hostname the
    // page itself claimed. For every legitimate picker use this is the
    // same value document.baseURI would have reported anyway.
    const hostname = trustedHostnameFromSender(sender, { preferTabUrl: true });
    if ( hostname === '' ) { return; }
    const modified = await addCustomFilters(hostname, request.selectors);
    if ( modified !== true ) { return; }
    const hasScriptletFilters = request.selectors.some(a => isScriptlet(a));
    const hasPlainFilters = request.selectors.some(a => isScriptlet(a) === false);
    const promises = [];
    if ( hasPlainFilters ) {
        promises.push(registerContentScripts());
    }
    if ( hasScriptletFilters ) {
        promises.push(
            updateCompiledFilters()
        );
    }
    await Promise.all(promises);
    return;
}

export async function handleClearCosmeticRules() {
    // See handleDeleteCosmeticRule() below — same reasoning applies to the
    // bulk-clear path.
    await clearAllCustomFilters();
    await registerContentScripts();
    return { ok: true };
}

export async function handleDeleteCosmeticRule(request) {
    const { hostname, selector } = request;
    // Delegates to filter-manager.js's deleteCustomFilter() rather than
    // reading/writing site.* storage directly here — that function's
    // write path funnels through writeToStorage()/removeFromStorage(),
    // which refreshes the hostname-indexed cache as part of the same
    // operation. Doing the raw storage mutation in this file instead (as
    // before) would silently leave that cache stale until something else
    // happened to rebuild it.
    await deleteCustomFilter(hostname, selector);
    await registerContentScripts();
    return { ok: true };
}

export async function handleGetCustomCosmeticRules() {
    return getAllCustomFiltersWithDates();
}

/******************************************************************************/
