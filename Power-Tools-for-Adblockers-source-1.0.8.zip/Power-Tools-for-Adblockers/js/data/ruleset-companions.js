/*
 * ruleset-companions.js — Single source of truth for which hidden
 * companion ruleset(s) accompany each visible dedicated filter. Two kinds
 * of companion exist:
 *   1. "AG Base overflow" rulesets — see tools/build-rulesets.mjs's
 *      countryOverflow config for how these are built.
 *   2. "_removeparam" rulesets — the redirect-action (unsafe for Chrome
 *      Web Store skip-review) rules split out of an otherwise mostly-safe
 *      list, so routine content refreshes of the safe majority aren't
 *      blocked by a handful of unsafe rules. See tools/build-rulesets.mjs's
 *      splitRemoveparam flag for how these are built.
 * Both kinds are applied at runtime the same way — see
 * js/core/static-rulesets.js's setRulesetEnabled().
 *
 * Enabling a key here also enables every ruleset id in its value array;
 * disabling the key disables them too. This keeps AdGuard Base's
 * per-country content (extracted at build time so it isn't shipped/matched
 * for every user regardless of need) in sync with the visible filter a
 * user actually toggles, without the dashboard needing to know these
 * hidden rulesets exist — see dashboard/filter-manager-ui.js's display-name
 * map, which intentionally has no entry for any *_overflow_* id.
 *
 * ruleset_agbase_overflow_other has no entry here (and no visible-filter
 * companion): it holds extended-EU countries with no dedicated filter of
 * their own, so it's only ever enabled directly, via detected browser
 * locale (see enableLocaleLanguageFilter() in js/workflow/background.js).
 */

// BRAVE VARIANT (v1.0.0) — empty. Every entry that used to live here paired
// a language filter with its hidden AG-Base-overflow or _removeparam
// companion; all language filters (and ruleset_adguard_base itself, which
// the overflow buckets were extracted from) were dropped for this variant
// — see the header comment on js/core/static-rulesets.js's
// STATIC_RULESET_IDS for why. Left as an empty, frozen object rather than
// deleted so setRulesetEnabled() and any future companion of either
// documented kind still has exactly one place to register.
export const RULESET_COMPANIONS = Object.freeze({});
