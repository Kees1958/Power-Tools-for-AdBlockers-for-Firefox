/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

*******************************************************************************/

// BRAVE VARIANT — the advanced-user confirmation gate (GATE_KEY,
// loadGateState()/applyGateState(), the #advancedUserCheck change
// listener, and enableAllProtections()'s bulk-enable-on-unlock) was
// REMOVED ENTIRELY per explicit request — dashboard.html's
// #advancedUserGate div is gone, so there is nothing left for any of
// that machinery to gate. Every Privacy & Security checkbox is now
// directly interactive from page load; this file only reflects stored
// config into the checkboxes and saves changes back out.

import { dom, qs$, qsa$ } from '../js/ui/dom.js';
import { sendMessage } from '../js/data/ext.js';
import { ADVANCED_SETTING_KEY, ADVANCED_ITEM_KEYS } from '../js/core/worry-free-advanced.js';
import {
    requestDownloadGuardPermission,
    hasDownloadGuardPermission,
} from '../js/ui/download-guard-permission.js';

/******************************************************************************/
// Load current security config and reflect in the UI checkboxes.

// The last config drawn -- click handlers must not `await` before asking for a
// permission (the prompt needs the click's user gesture), so they read this.
let renderedConfig = null;

// Whether the row "Block first-party downloads..." is switched on AND its
// downloads-API watcher is missing the optional permission -> show the notice.
async function renderDownloadGuardNotice(config) {
    const notice = qs$('#downloadGuardNotice');
    if ( !notice ) { return; }
    const wanted = config?.[ADVANCED_SETTING_KEY] === true &&
        config?.[ADVANCED_ITEM_KEYS.FIRST_PARTY_DOWNLOADS] !== false;
    notice.hidden = wanted === false || await hasDownloadGuardPermission();
}

async function renderSecurityConfig() {
    const config = await sendMessage({ what: 'getSecurityConfig' });
    if ( !config ) { return; }
    renderedConfig = config;
    for ( const input of qsa$('section[data-pane="security"] input[data-setting]') ) {
        const key = input.dataset.setting;
        if ( Object.hasOwn(config, key) ) {
            input.checked = config[key];
        }
    }
    await renderDownloadGuardNotice(config);
}

/******************************************************************************/
// Handle toggle changes.

dom.on(
    'section[data-pane="security"]',
    'change',
    'input[type="checkbox"][data-setting]',
    async ev => {
        const input = ev.target;
        const key = input.dataset.setting;
        const value = input.checked;
        // Ticking the download row while 'advanced' is on needs the optional
        // `downloads` permission: ask FIRST, before any await (user gesture).
        const permissionRequest =
            ( key === ADVANCED_ITEM_KEYS.FIRST_PARTY_DOWNLOADS && value === true &&
              renderedConfig?.[ADVANCED_SETTING_KEY] === true )
                ? requestDownloadGuardPermission()
                : null;
        input.disabled = true;
        try {
            await sendMessage({ what: 'setSecurityConfig', key, value });
            if ( permissionRequest ) { await permissionRequest; }
            // Redraw from the stored config: the background may have applied a
            // side effect (for example the tier hierarchy in js/core/worry-free-
            // tiers.js normalises related settings) and the download-permission
            // notice depends on several settings at once.
            await renderSecurityConfig();
        } finally {
            input.disabled = false;
        }
    }
);

// The Filter (block) lists tab holds the switches that gate this pane's groups
// (and the download-permission notice depends on them) -- redraw whenever this
// pane is shown.
dom.on('#dashboard-nav', 'click', '.tabButton', ev => {
    if ( ev.target.dataset.pane === 'security' ) { renderSecurityConfig(); }
});

/******************************************************************************/

// The notice's button: the request is the FIRST call in the handler.
qs$('#downloadGuardGrantButton')?.addEventListener('click', async ( ) => {
    const request = requestDownloadGuardPermission();
    await request;
    await renderSecurityConfig();
});

renderSecurityConfig();

/******************************************************************************/
