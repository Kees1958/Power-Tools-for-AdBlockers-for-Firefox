// .stylelintrc.mjs — config for tools/check-stylelint-style-guide.mjs.
// Loads ONLY this project's own two custom rules (tools/stylelint-plugins/),
// which encode STYLE_GUIDE_LIGHT.md / STYLE_GUIDE_DARK.md. No third-party
// rule sets are enabled on purpose — the check is informational and
// scoped to the documented contrast findings.
export default {
    plugins: [
        './tools/stylelint-plugins/verified-color-mix-opacity.mjs',
        './tools/stylelint-plugins/no-unsafe-status-color-as-text.mjs',
    ],
    rules: {
        'ubol/verified-color-mix-opacity': true,
        'ubol/no-unsafe-status-color-as-text': true,
    },
};
