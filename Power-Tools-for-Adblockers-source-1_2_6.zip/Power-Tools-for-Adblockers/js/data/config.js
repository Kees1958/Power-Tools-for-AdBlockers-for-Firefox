/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * config.js — Extension configuration loading and persistence
 *
 * Public interface:
 *   loadRulesetConfig()      — loads rulesetConfig from storage on SW startup
 *   saveRulesetConfig()      — persists rulesetConfig to chrome.storage.local
 *   saveSecurityConfig()     — persists securityConfig to chrome.storage.local
 *   rulesetConfig {Object}   — runtime config (version, autoReload, showBlockedCount, etc.)
 *   securityConfig {Object}  — security/privacy toggle states
 *   swLifecycle {Object}     — SW lifecycle state vector (phase, startPhase, firstRun, wakeupRun)
 *   SW_PHASES {Object}       — frozen enum of valid swLifecycle.phase values
 *   process                  — alias for swLifecycle (backward compat)
 *
 * Persisted: chrome.storage.local (full) + chrome.storage.session (fast wakeup cache)
 */


import {
    localRead, localWrite,
    sessionRead, sessionWrite,
} from './ext.js';

/******************************************************************************/

export const rulesetConfig = {
    version: '',
    autoReload: true,
    showBlockedCount: true,
    hasBroadHostPermissions: true,
};

// ─────────────────────────────────────────────────────────────────────────
// Government-domain default allowlist — single shared definition, applied
// to every Security & Privacy toggle below (not just one), since these
// checks are prone to interfering with government portals' session/SSO
// mechanisms. Deliberately a small, verified starter set rather than a
// guess at every country's civic domain scheme:
//   - 'gov'    — covers all US federal .gov sites (e.g. irs.gov, usa.gov)
//   - 'gov.it' — covers all Italian public-administration sites (e.g.
//                agenziaentrate.gov.it), the concrete case that prompted
//                this — see CHANGELOG for the specific research.
// allowlistToExcludeMatches() (compiled-filters.js) turns each of these
// into BOTH an exact-host and a '*.'-subdomain match pattern, so listing
// the bare suffix here covers every site under it, not just one example.
// Extend this list the same way any other securityAllowlist entry already
// is — one hostname per line, '#' for comments — if more countries'
// government domains need the same treatment.
const GOV_DOMAIN_ALLOWLIST = [
    '# Government domains',
    'gov',
    'gov.it',
].join('\n');

export const securityConfig = {
    // ── DNR-based toggles (network layer) ────────────────────────────────────
    // blockPunycodeLinks (blocked all-origin punycode links) replaced by
    // blockSuspicious3pLinks in the uBlock-Stripped-Dynamic fork — see
    // js/core/matrix-detect.js for the IP-literal/non-standard-port
    // predicates this toggle's DNR rules mirror, and ruleset-manager.js's
    // securitySlots for the actual rule composition. Scoped to third-party
    // only now (was all-origin before). A 4th pattern — known DDNS/free-
    // hosting domains — was originally its own separate toggle
    // (blockDdnsFreeHosting) but was folded into this one: both share the
    // same "suspicious 3P link" intent, and splitting them into two
    // checkboxes just meant two toggles to remember to enable instead of
    // one. See runVersionMigration() in background.js for the one-time
    // migration that carries an existing install's separate on/off state
    // for the two forward into this single combined toggle.
    //
    // BRAVE VARIANT — punycode detection REMOVED from this check entirely
    // per explicit request (was pattern 1 of 4; the DNR rule slot
    // SECURITY_RULES_BASE_ID+5 that implemented it is retired too — see
    // dnr-budgets.js). Base default is true, NOT false — a real bug,
    // caught and fixed: this entry's gating logic in ruleset-manager.js
    // is `isWorryFreeActive && securityConfig.blockSuspicious3pLinks
    // !== false` (worryFreeGatedOptOut — see that comment there), so a
    // stored value of literal `false` is the actual opt-out signal, not
    // "off by default". Storing `false` as the default meant this
    // protection could never activate at all, not even during an active
    // Worry-free session — the exact opposite of "enabled by default in
    // Worry-free mode" (the "Security enhancements with low risk" group
    // in the Privacy & Security tab). `true` is what a not-yet-opted-out
    // default actually looks like under this gating scheme.
    blockSuspicious3pLinks: true,
    // blockLoginWith — REMOVED v8.5.7, per explicit request (see CHANGELOG
    // for the full history). background.js's runVersionMigration() cleans
    // up any leftover stored key and dynamic DNR rule from installs that
    // predate this removal.
    blockWebBundles:         true,
    // ── Scriptlet-based toggles (MAIN world, browser.scripting API) ───────────
    blockPings:              true,
    // BRAVE VARIANT — blockAlertDialogs + blockConfirmDialogs merged into
    // one setting/checkbox per explicit request ("Block alert, confirm
    // and prompt scam" — both are the exact same tech-support-scam
    // pattern, just three different dialog APIs). Still two separate
    // scriptlets under the hood (sec-alertbuster.js, sec-dialogbuster.js)
    // — see compiled-filters.js's SECURITY_SCRIPTLET_BUILTIN_MATCHES,
    // both entries now keyed to this same setting.
    blockDialogSpam:         true,
    blockObfuscatedEval:     true,
    // BRAVE VARIANT — worryFreeGatedOptOut (see compiled-filters.js's
    // own entry), converted from worryFreeOverride per explicit
    // clarification: only ever applies during an active Worry-free
    // session. Base default true, NOT false — same bug class already
    // fixed for blockSuspicious3pLinks/blockScpPrivacy/blockScpSecurity:
    // the gating logic is `isWorryFreeActive && securityConfig[key] !==
    // false`, so a stored `false` default is the actual opt-out signal
    // and would mean this could never activate at all, not "off until
    // Worry-free".
    blockAdultNoEval:        true,
    // Applies every fingerprinting-detection mitigation Privacy Inspector
    // knows how to apply (canvas, WebGL, WebGL-fingerprint, audio, timezone,
    // navigator.plugins, device info, WebRTC) directly to the same curated
    // high-risk site list blockAdultNoEval already uses — see
    // SECURITY_SCRIPTLET_BUILTIN_MATCHES.blockAdultFingerprinting in
    // compiled-filters.js (shared constant, not a second copy of the list).
    // Same worryFreeGatedOptOut correction and same true-default
    // reasoning as blockAdultNoEval above.
    blockAdultFingerprinting: true,
    // ── SCP (Sandboxed Content Permissions) — this release ────────────────────
    // Privacy & Security tab's "Low website breakage risk enhancements
    // (enabled by default when 'safe regions' is enabled in Worry-free)"
    // group. Base default true — same worryFreeGatedOptOut semantics
    // as blockSuspicious3pLinks/blockObfuscatedEval above: this checkbox
    // only matters DURING an active Worry-free session outside a
    // familiar TLD — it has no effect at all otherwise, and unchecking
    // it is a genuine opt-out. The gating logic is `isWorryFreeActive &&
    // securityConfig[key] !== false` (ruleset-manager.js's
    // securitySlots), so — same bug class as blockSuspicious3pLinks,
    // caught and fixed together — a stored `false` default would mean
    // the protection could never activate at all, not "off until
    // Worry-free". `true` is what a not-yet-opted-out default looks
    // like under this gating scheme.
    blockScpPrivacy: true,  // camera, microphone, display-capture, clipboard-read
    blockScpSecurity: true, // bluetooth, serial, hid, usb, local-network-access
    // Fingerprinting protections scoped to non-familiar-TLD domains (same
    // sec-adult-fingerprint scriptlet blockAdultFingerprinting uses — see
    // compiled-filters.js's own SECURITY_SCRIPTLETS entry). Default true,
    // per explicit request and matching this group's own "(enabled by
    // default when 'safe regions' is enabled in Worry-free)" heading.
    blockScpFingerprint: true,
    // -- "Advanced" / Medium website breakage risk group (1.2.0) ------------------
    // Privacy & Security tab's "Medium website breakage risk enhancements
    // (enabled by default when 'advanced' is enabled in Worry-free)" group.
    // Same worryFreeGatedOptOut semantics as the SCP items above: base default
    // TRUE (an unchecked box is the opt-out signal, so a stored false default
    // could never activate), and each row only does anything DURING an active
    // Worry-free session with worryFreeAdvancedTldProtectionsEnabled (below,
    // default OFF) turned on. The key strings are duplicated in
    // js/core/worry-free-advanced.js (this data/ tier may not import core/);
    // tools/check-advanced-protections.mjs fails the suite if they drift.
    blockMediumFirstPartyDownloads: true, // CSP sandbox without allow-downloads (main_frame/sub_frame)
    enforceMediumSandboxSafeScripts: true, // CSP sandbox (safe flags) + script-src without unsafe-eval
    blockMediumThirdParty: true,           // third-party requests except HTML, images, media
    blockMediumFingerprint: true,          // Privacy Inspector Low + Medium risk mitigations, on websites outside safe regions
    // Global Privacy Control was REMOVED (see CHANGELOG) — its DNR rule's
    // required broad scope (first-party AND third-party, unlike every
    // other Security toggle) made Chrome's icon badge count deeply
    // misleading whenever it was on (Chrome counts modifyHeaders matches
    // the same as real blocks), and no accurate-yet-simple fix existed
    // that didn't add real complexity for a single toggle. Removed rather
    // than shipped with a known-misleading side effect.
    // Startup-only action — no scriptlet, no DNR rule. Consulted exactly
    // once per genuine browser launch (browser.runtime.onStartup, NOT the
    // routine MV3 service-worker sleep/wake cycle — see history-cleaner.js
    // and background.js's onStartup listener for why that distinction
    // matters here specifically). See history-cleaner.js for exactly
    // which chrome.browsingData data types this clears (history +
    // cookies + cache) and which it deliberately never touches —
    // passwords (Chrome itself ignores that flag since Chrome 144 — see
    // that file's header) and site permissions (no corresponding
    // chrome.browsingData data type exists at all).
    deleteHistoryOnStart: true,
    // Startup-only action, same shape as deleteHistoryOnStart just above —
    // no scriptlet, no DNR rule, consulted exactly once per genuine
    // browser launch (v8.5.5, see js/workflow/background.js's onStartup
    // listener and cookie-clicker-autodeny-manager.js's startAutoDeny()).
    // Default OFF: Worry-free does not start itself unless explicitly
    // enabled here.
    startWorryFreeOnBrowserStartup: false,
    // (v8.6.13) Consolidated from six independent checkboxes down to two
    // — per explicit request, after a real, flagged concern about the
    // underlying suppression mechanism: each item's "off" state works by
    // adding a session-scoped, UNCONDITIONAL (`condition: {}`) DNR allow
    // rule that outranks this whole reserved priority tier — see
    // worry-free-extra-manager.js's own header for the full mechanism.
    // That rule doesn't distinguish "the specific requests THIS item
    // would have blocked" from "everything" — so with six independently-
    // toggleable items, turning off any ONE could in principle suppress
    // ALL of them for that session, not just its own. Two groups doesn't
    // make that mathematically impossible (the same rule shape still
    // applies), but it does mean the six-way confusion collapses to two
    // deliberately-coarse choices instead — accepted explicitly ("I
    // don't mind when all filters are enabled at the same time").
    worryFreeSecurityProtectionsEnabled: true, // "Security & Privacy tab" protections (gates the existing worryFreeOverride mechanism — see compiled-filters.js/ruleset-manager.js) — UNCHANGED, not part of this consolidation
    // Default OFF, per explicit request — unlike every other Worry-free
    // item above (default ON), this one starts disabled. Gates the
    // timezone + battery-status pair (js/security/sec-tz-fingerprint.js,
    // js/security/sec-battery.js) — see compiled-filters.js's
    // SECURITY_SCRIPTLETS entries for these two (worryFreeAntiFingerprintOverride)
    // and scripting-manager.js's isWorryFreeAntiFingerprintActive for the
    // gating. Deliberately its own, separate key — not folded into
    // worryFreeSecurityProtectionsEnabled above, which is an unrelated
    // Security & Privacy tab master switch.
    worryFreeAntiFingerprintEnabled: false,
    // RETIRED (v9.1.7) — "Enable extra blocklist" (EasyList adult
    // ad-servers + transcend.io + Disconnect/Ghostery social media)
    // removed entirely, per explicit request — the underlying ruleset
    // and suppression rule are both gone (see dnr-budgets.js's
    // WORRY_FREE_EXTRA_RULES_BASE_ID/WORRY_FREE_SOCIAL_RULES_BASE_ID own
    // retirement comments), not just this checkbox. Migration cleanup
    // (background.js's runVersionMigration()) deletes this key from any
    // existing install's stored securityConfig.
    // "Enable extra security protections for domains outside
    // familiar, low-risk regions": blocks third-party scripts/frames
    // PLUS downloads from domains outside the TLD whitelist (see tools/
    // build-rulesets.mjs's buildWorryFreeDownloadBlockRule() for the
    // download mechanism). Both always toggle together now.
    // Default TRUE, per explicit request (changed from the prior default
    // of false). Real, sometimes-noticeable site-breakage risk still
    // applies unchanged (blocking third-party scripts/frames/downloads
    // wholesale for anything outside the familiar-TLD list) — this
    // flip accepts that risk deliberately, it isn't a claim the risk
    // went away. Still user-toggleable in the dashboard's Worry-free
    // settings if it causes problems on a given site.
    worryFreeSecurityTldProtectionsEnabled: true,
    // 1.2.0 -- "Enable the advanced 'safe regions' protections additionally
    // (see Privacy & Security tab)". Gates the four Medium-risk rows above.
    // Default OFF: unlike the extra 'safe regions' item, these carry medium
    // site-breakage risk (blocks third-party stylesheets/fonts/XHR, forbids
    // eval, sandboxes pages, blocks page downloads outside safe regions), so a
    // person must opt in. Key string duplicated in js/core/worry-free-advanced.js.
    worryFreeAdvancedTldProtectionsEnabled: false,
    // Four new, independently-toggleable worry-free items (v9.1.4) — NOT
    // part of the six-checkboxes-to-two consolidation above. Each has its
    // own genuinely domain-scoped suppression rule (see worry-free-extra-
    // manager.js's SUPPRESSION_RULES and dnr-budgets.js's
    // WORRY_FREE_ADGUARD_TRACKING_RULES_BASE_ID and neighbors), so
    // turning one off cannot silently suppress a sibling item too — the
    // correctness gap that made the original six items unsafe to leave
    // independently toggleable. Default true, matching every other
    // worry-free blocklist item's default. (Was five items —
    // worryFreeGhosteryOtherEnabled retired this release, see
    // dnr-budgets.js's WORRY_FREE_GHOSTERY_OTHER_RULES_RETIRED_BASE_ID
    // comment; migration cleanup below deletes it from any existing
    // install's stored securityConfig, same pattern as
    // worryFreeBlocklistEnabled's own retirement above.)
    // worryFreeAdguardTrackingEnabled, worryFreeEasylistAdserversEnabled,
    // worryFreePeterloweEnabled, worryFreeDisconnectOtherEnabled — all
    // four removed (found while checking THIRD_PARTY_LICENSES.md's
    // accuracy after the Disconnect ruleset removal): none referenced
    // anywhere outside this file. Each one's underlying ruleset was
    // already removed — ruleset_adguard_tracking_servers/
    // ruleset_easylist_adservers/ruleset_peterlowe predate this Firefox
    // port entirely (see tools/build-rulesets.mjs's own retirement
    // comments), ruleset_disconnect_other in this port's 1.0.1 — but the
    // config flags gating them were never cleaned up until now.
    // NOTE: the former autoApplyPrivacyExtras manual toggle has been removed
    // (7.0.0) — see applyPrivacyExtrasForHost() in js/core/custom-scriptlets.js,
    // which now applies unconditionally on "Block All" instead of being gated
    // on a dashboard checkbox here.
};

// Per-toggle hostname allowlists — comma or newline separated hostnames.
// DNR toggles: hostnames added to excludedInitiatorDomains on the DNR rule.
// Scriptlet toggles: hostnames added to excludeMatches on the content script directive
//   (the scriptlet simply does not run on those pages).
export const securityAllowlist = {
    blockSuspicious3pLinks: GOV_DOMAIN_ALLOWLIST,
    blockWebBundles:         GOV_DOMAIN_ALLOWLIST,
    blockPings:              GOV_DOMAIN_ALLOWLIST,
    blockDialogSpam:         GOV_DOMAIN_ALLOWLIST,
    blockObfuscatedEval:     GOV_DOMAIN_ALLOWLIST,
    blockAdultNoEval:        GOV_DOMAIN_ALLOWLIST,
    // blockAdultFingerprinting intentionally has no allowlist entry here: it
    // is already scoped to a fixed high-risk site list (not applied broadly,
    // nothing to exempt sites from).
};

// Re-exported so background.js's one-time version-migration step (the
// established place in this codebase for "existing users' saved config
// needs a new default retroactively applied") can append the exact same
// list to already-installed users' saved allowlists, instead of this only
// taking effect for fresh installs. See runVersionMigration() there.
export { GOV_DOMAIN_ALLOWLIST };

export const defaultConfig = Object.assign({}, rulesetConfig);

/******************************************************************************/
// SW lifecycle state vector
// Applies the same swimming-lane pattern used in block-monitor.js.
//
// Phases (SW startup lane — one linear sequence per SW lifetime):
//
//   [booting] — loadRulesetConfig() in progress; no config available yet
//       │
//       ▼
//   [starting] — startSession() in progress; config loaded, rules being applied
//       │  startPhase tracks the sub-step within starting:
//       │    'migration'   — runVersionMigration() running
//       │    'permissions' — syncWithBrowserPermissions() running
//       │    'scripts'     — registerContentScripts/UserScripts running
//       │    'finalising'  — security rules, badge, AG data loading
//       │
//       ├──(success)──► [ready]  — fully initialised; all event listeners active
//       │
//       └──(throw)────► [error]  — start() threw; errorReason holds the message
//                                  Chrome may attempt a one-shot reload (goodStart guard)
//
// The `phase` field is the authoritative signal used by all isFullyInitialized
// consumers. The three boolean flags (firstRun, wakeupRun, firstAlarm) are
// retained as named fields on the same vector so background.js call sites
// need no mass rename.
/******************************************************************************/

export const SW_PHASES = Object.freeze({
    BOOTING:  'booting',
    STARTING: 'starting',
    READY:    'ready',
    ERROR:    'error',
});

export const swLifecycle = {
    owner:       'background',
    phase:       SW_PHASES.BOOTING,
    startPhase:  null,      // sub-step within STARTING, null otherwise
    errorReason: null,      // set on ERROR, null otherwise
    // Boot-time flags — set once by loadRulesetConfig, never change after
    firstRun:    false,     // true  → fresh install (no prior rulesetConfig in storage)
    wakeupRun:   false,     // true  → SW restarted mid-session (session storage present)
    firstAlarm:  false,     // true  → first alarm tick after a wakeup has been handled
};

// Backward-compat alias — existing `process.firstRun` / `process.wakeupRun`
// references in background.js continue to work without a mass rename.
export const process = swLifecycle;

let pendingOpPromise = Promise.resolve();

/******************************************************************************/

async function _loadRulesetConfig() {
    const sessionData = await sessionRead('rulesetConfig');
    if ( sessionData ) {
        Object.assign(rulesetConfig, sessionData);
        process.wakeupRun = true;
    } else {
        const localData = await localRead('rulesetConfig');
        if ( localData ) {
            Object.assign(rulesetConfig, localData);
        }
        sessionWrite('rulesetConfig', rulesetConfig);
        if ( !localData ) {
            localWrite('rulesetConfig', rulesetConfig);
            process.firstRun = true;
        }
    }
    const savedSecurity = await localRead('securityConfig');
    if ( savedSecurity ) {
        Object.assign(securityConfig, savedSecurity);
    } else {
        localWrite('securityConfig', securityConfig);
    }
    const savedAllowlist = await localRead('securityAllowlist');
    if ( savedAllowlist ) {
        Object.assign(securityAllowlist, savedAllowlist);
    } else {
        localWrite('securityAllowlist', securityAllowlist);
    }
}

async function _saveRulesetConfig() {
    sessionWrite('rulesetConfig', rulesetConfig);
    return localWrite('rulesetConfig', rulesetConfig);
}

export async function saveSecurityConfig() {
    return localWrite('securityConfig', securityConfig);
}

export async function saveSecurityAllowlist() {
    return localWrite('securityAllowlist', securityAllowlist);
}

/******************************************************************************/

export function loadRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_loadRulesetConfig);
    return pendingOpPromise;
}

export function saveRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_saveRulesetConfig);
    return pendingOpPromise;
}
