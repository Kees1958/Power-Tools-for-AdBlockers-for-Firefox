/*
 * timing-constants.js — shared timing values used by more than one feature
 *
 * Public interface: numeric constants only. No logic, no state.
 */

/*******************************************************************************

    DEFAULT_SESSION_TIMEOUT_MS
    ---------------------------
    The Matrix panel and the Privacy Inspector each independently chose a
    5-minute session timeout -- same value, but a coincidence of two
    unrelated features, not a structural coupling between them. Named once
    here so the literal itself can't drift out of sync between the 4 places
    that use it: js/core/matrix-panel.js, js/core/privacy-inspector.js,
    matrix/matrix-panel.js and privacy/privacy-inspector.js (each feature's
    SW-side guard and its UI-side countdown display). (An earlier version of
    this comment named the Block Monitor and monitor/monitor-panel.js, which
    do not exist in this Firefox fork; corrected in 1.1.1.)

    Each consumer still assigns this to its own locally-named constant
    (e.g. `const SESSION_TIMEOUT_MS = DEFAULT_SESSION_TIMEOUT_MS;`) rather
    than importing and using DEFAULT_SESSION_TIMEOUT_MS directly everywhere
    — so a future feature can deliberately diverge from this default later
    by simply no longer importing it, without this file's name implying
    the two timeouts must always match.

*******************************************************************************/
export const DEFAULT_SESSION_TIMEOUT_MS = 5 * 60 * 1000;

// 1.2.6 -- sleep safeguard. A Privacy Inspector / Matrix session that is still
// running when Firefox puts the background (event page) to sleep is ended exactly
// like a session that ran out its time: same stop path, and the reason handed to the
// panel is the SAME one a timed ending uses, so the panel shows its usual "time is
// up" message. Named once here so both session modules and the tests agree on it.
// (Why: a sleeping page's timers do not run, so nothing would end the session at its
// deadline; ending it when the page goes to sleep keeps the 5-minute limit honest.)
export const SESSION_SLEEP_END_REASON = 'timeout';
