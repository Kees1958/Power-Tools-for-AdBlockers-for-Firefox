/*
 * download-guard-permission.js -- asking for / checking the OPTIONAL `downloads`
 * permission that the row "Block first-party downloads on websites outside the
 * safe-regions." (1.2.4) needs for its downloads-API watcher.
 *
 * The permissions are optional (manifest optional_permissions) so nobody who never
 * turns that row on is asked for them and adding them cannot hold back an update.
 * BOTH are requested in ONE prompt (a prompt needs the click's user gesture, so it
 * cannot be split in two): `downloads` (cancel the download) and `notifications`
 * (tell the person it was blocked and why). Only `downloads` is needed for the guard
 * to work; without `notifications` it is silent.
 * A permission prompt only works from a user gesture, so requestDownloadGuard-
 * Permission() must be the FIRST thing a click handler calls -- before any
 * `await` -- and it never throws: a refusal (or a browser that rejects the
 * request) just resolves to false, and the Privacy & Security tab then shows a
 * notice with a "Grant permission" button.
 *
 * Public interface: requestDownloadGuardPermission(), hasDownloadGuardPermission()
 * Dependencies: ../data/ext.js (browser), ../core/worry-free-advanced.js
 *   (DOWNLOAD_GUARD_PERMISSION -- constants only; the guard itself lives in the
 *   background and is deliberately NOT imported into a page)
 */

import { browser } from '../data/ext.js';
import { DOWNLOAD_GUARD_PERMISSION, DOWNLOAD_GUARD_PERMISSIONS } from '../core/worry-free-advanced.js';

export function requestDownloadGuardPermission() {
    try {
        return Promise.resolve(
            browser.permissions.request({ permissions: [ ...DOWNLOAD_GUARD_PERMISSIONS ] })
        ).then(granted => granted === true, () => false);
    } catch {
        return Promise.resolve(false);
    }
}

export async function hasDownloadGuardPermission() {
    try {
        return await browser.permissions.contains({ permissions: [ DOWNLOAD_GUARD_PERMISSION ] }) === true;
    } catch {
        return false;
    }
}
