/*******************************************************************************

    uBol-stripped — Allow list editor (dashboard Allow list tab)

    The CodeMirror editor shows and edits a plain list of domains for which
    filtering is turned off (allow-listed). One domain per line.

    Internally these map to siteModes entries with mode 0 (no-filtering).
    All other domains remain at the default mode 1 (basic / on).

*******************************************************************************/

import {
    siteModesFromText,
    textFromSiteModes,
    extractSaferegionsFromText,
    textFromSaferegions,
} from '../util/site-mode-parser.js';
import { sendMessage } from '../data/ext.js';

/******************************************************************************/

export class ModeEditor {
    constructor(editor) {
        this.editor = editor;
        this.bc = null;
    }

    on() {}
    off() {}

    async getText() {
        const siteModes = await sendMessage({ what: 'siteModeGetAll' });
        // sendMessage() resolves to `undefined` when every retry attempt
        // failed (SW not ready, messaging error, etc.) — indistinguishable
        // by value from a legitimate empty {} response otherwise. Throwing
        // here (instead of defaulting to {}) lets the caller (develop.js)
        // tell the difference and refuse to show an editable-and-savable
        // blank editor that could silently overwrite the real stored list.
        if ( siteModes === undefined ) {
            throw new Error('siteModeGetAll: no response from background');
        }
        // $saferegions lines are additive to the same editor, but treated
        // more leniently on load than the plain allow-list domains above:
        // a failed/undefined response here falls back to an empty list
        // rather than throwing, since the plain domains are this editor's
        // primary content and a $saferegions hiccup shouldn't block seeing
        // (or editing) them.
        const saferegionsDomains = await sendMessage({ what: 'saferegionsGetAll' });
        const saferegionsText = Array.isArray(saferegionsDomains)
            ? textFromSaferegions(saferegionsDomains)
            : '';
        return textFromSiteModes(siteModes) + saferegionsText;
    }

    async saveEditorText(editor) {
        const text = editor.getEditorText();
        // Pulled out FIRST — see extractSaferegionsFromText()'s own header
        // for why: a $saferegions line must never fall through and be
        // mistaken for a plain no-filtering domain by siteModesFromText().
        const { saferegionsDomains, remainingText } = extractSaferegionsFromText(text);
        const siteModes = siteModesFromText(remainingText);
        const [ saved, savedSaferegions ] = await Promise.all([
            sendMessage({ what: 'siteModeSetAll', siteModes }),
            sendMessage({ what: 'saferegionsSetAll', domains: saferegionsDomains }),
        ]);
        // Same undefined-means-failure distinction as getText() above:
        // handleSiteModeSetAll (background.js) always resolves with an
        // object on success — {} only for a genuinely empty list, never
        // undefined — so undefined here means the message itself failed.
        // Report failure rather than silently marking the editor "saved".
        if ( saved === undefined ) {
            console.error('[uBlock-Dynamic] Allow list editor: save failed — no response from background');
            return false;
        }
        const savedSaferegionsText = Array.isArray(savedSaferegions)
            ? textFromSaferegions(savedSaferegions)
            : textFromSaferegions(saferegionsDomains);
        editor.setEditorText(textFromSiteModes(saved) + savedSaferegionsText);
        return true;
    }

    updateView(editor, firstLine, lastLine) {
        // No inline validation needed — plain domain list
    }

    // No newlineAssistant: plain list needs no auto-indentation prefix
}
