/*******************************************************************************

    uBol-stripped — Allow list parser / serialiser

    Parses and serialises the plain domain list used in the Allow list
    dashboard editor.

    Format: one domain per line, blank lines and lines starting with # ignored.

    Internal representation: { [hostname]: 0 }
    All listed domains are mapped to mode 0 (no-filtering / off).

    Values:
      0 = OFF   / no-filtering  (the only mode exposed here)
      1 = BASIC / on            (the global default for unlisted domains)

*******************************************************************************/
/*
 * site-mode-parser.js -- plain-list serialiser/parser for the allow list editor
 *
 * Public interface:
 *   siteModesFromText(text)    -- parses plain list -> {hostname: 0} object
 *   textFromSiteModes(modes)   -- serialises {hostname: mode} -> plain list
 *   SECTION_NAMES              -- kept for compatibility (single-entry array)
 *
 * No state. No side effects. Pure serialisation utility.
 */


import punycode from './punycode.js';

/******************************************************************************/

// Kept for compatibility with mode-editor.js newlineAssistant lookup.
// Only one implicit "section" now — the domain list itself.
export const SECTION_NAMES = ['allow-list'];

/******************************************************************************/

export function siteModesFromText(text) {
    const out = {};

    for ( const rawLine of text.split(/\n|\r\n|\r/) ) {
        const trimmed = rawLine.trim();

        // Skip blank lines and comments
        if ( trimmed === '' || trimmed.startsWith('#') ) { continue; }

        const raw = trimmed.toLowerCase();
        const hn  = punycode.toASCII(raw);
        if ( hn.length > 0 && hn.length <= 253 ) {
            // All listed domains are no-filtering (mode 0)
            out[hn] = 0;
        }
    }

    return out;
}

/******************************************************************************/

export function textFromSiteModes(siteModes) {
    const domains = [];

    for ( const [hn, mode] of Object.entries(siteModes) ) {
        // Only emit domains that are explicitly turned off (mode 0)
        if ( mode !== 0 ) { continue; }
        // Skip the internal sentinel; it has no meaning in the plain list
        if ( hn === 'all-urls' ) { continue; }
        domains.push(punycode.toUnicode(hn));
    }

    domains.sort((a, b) => a.localeCompare(b));
    return domains.length > 0 ? domains.join('\n') + '\n' : '';
}

/******************************************************************************/
// $saferegions — a line of the form "@@example.com$saferegions" exempts
// that one domain from every worry-free protection (see saferegions-
// manager.js). The leading "@@" is REQUIRED, not optional — this mirrors
// the real ABP/uBlock "exception rule" prefix ($saferegions is
// conceptually an exception, exempting a domain from protections, same
// as any other @@-prefixed allow rule in this filter-list ecosystem),
// and it's exactly what the reference screenshot's own example showed.
// A bare "example.com$saferegions" (no @@) is NOT recognized as a
// $saferegions directive at all — it falls through untouched to
// siteModesFromText() like any other line that isn't one.
//
// Pulled out of the editor text BEFORE siteModesFromText() sees the
// remainder, so a recognized $saferegions line can never accidentally
// become a no-filtering entry too (they are two independent, unrelated
// things: a no-filtering domain is not exempt from worry-free, and a
// worry-free exemption does not turn off ordinary filtering).
/******************************************************************************/

const SAFEREGIONS_PREFIX = '@@';
const SAFEREGIONS_SUFFIX = '$saferegions';

export function extractSaferegionsFromText(text) {
    const saferegionsDomains = [];
    const remainingLines = [];

    for ( const rawLine of text.split(/\n|\r\n|\r/) ) {
        const trimmed = rawLine.trim();
        if ( trimmed === '' || trimmed.startsWith('#') ) {
            remainingLines.push(rawLine);
            continue;
        }
        const lower = trimmed.toLowerCase();
        if ( lower.startsWith(SAFEREGIONS_PREFIX) === false || lower.endsWith(SAFEREGIONS_SUFFIX) === false ) {
            remainingLines.push(rawLine);
            continue;
        }
        const rawDomain = trimmed.slice(SAFEREGIONS_PREFIX.length, trimmed.length - SAFEREGIONS_SUFFIX.length);
        // Defensive strip of any FURTHER leading '@' beyond the required
        // "@@" above (e.g. a stray third '@') — BEFORE handing the
        // string to punycode.toASCII(). That library's mapDomain()
        // (js/util/punycode.js) splits the WHOLE string on every '@' and
        // only ever keeps the SECOND '@'-delimited segment (its own
        // comment: "in email addresses, only the domain name should be
        // punycoded" — it assumes user@domain shape); an extra leading
        // '@' left in front of the domain hits this exact same class of
        // silent collapse the required "@@" prefix above was designed
        // around. Confirmed directly: punycode.toASCII('@@bbc.com')
        // === '@', not 'bbc.com'.
        const domainPart = rawDomain.replace(/^@+/, '');
        const hn = punycode.toASCII(domainPart.toLowerCase());
        if ( hn.length > 0 && hn.length <= 253 ) {
            saferegionsDomains.push(hn);
        }
        // Deliberately NOT pushed to remainingLines — this line is fully
        // consumed here, whether or not the domain part was valid, so an
        // invalid $saferegions line is dropped rather than falling
        // through to siteModesFromText() and being mistaken for a plain
        // no-filtering domain.
    }

    return {
        saferegionsDomains,
        remainingText: remainingLines.join('\n'),
    };
}

export function textFromSaferegions(domains) {
    const lines = domains
        .map(hn => punycode.toUnicode(hn))
        .sort((a, b) => a.localeCompare(b))
        .map(hn => `${SAFEREGIONS_PREFIX}${hn}${SAFEREGIONS_SUFFIX}`);
    return lines.length > 0 ? lines.join('\n') + '\n' : '';
}

/******************************************************************************/
