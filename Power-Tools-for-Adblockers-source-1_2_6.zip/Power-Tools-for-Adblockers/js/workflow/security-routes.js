/*
 * security-routes.js — Security & Privacy config/allowlist message-route
 * adapters
 *
 * Same three-layer split as matrix-routes.js (see that file's own header
 * for the full rationale):
 *   Layer 1 — message-routes.js:  POLICY
 *   Layer 2 — this file:          ADAPTER (request shape <-> plain state mutation)
 *   Layer 3 — data/config.js's securityConfig/securityAllowlist (the state
 *             itself) + core/scripting-manager.js/core/ruleset-manager.js
 *             (what re-applying a change actually does)
 *
 * Unlike Matrix, there's no single "security-manager.js" this file adapts
 * to — securityConfig/securityAllowlist are plain, directly-mutated state
 * objects (data/config.js), and applying a change means calling into
 * whichever of scripting-manager.js/ruleset-manager.js the changed key
 * actually affects. That dispatch logic (SECURITY_SCRIPTLET_TOGGLE_KEYS /
 * SECURITY_HYBRID_TOGGLE_KEYS / SECURITY_STARTUP_ONLY_KEYS below) is
 * genuinely part of the adapter layer, not misplaced business logic —
 * it's translating "which config key changed" into "which of the two
 * re-registration functions needs to run," the same kind of shape-
 * translation this layer already does for every other handler here.
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleGetSecurityAllowlist, handleGetSecurityConfig,
 *   handleSetSecurityAllowlist, handleSetSecurityConfig
 */

import {
    securityConfig,
    securityAllowlist,
    saveSecurityConfig,
    saveSecurityAllowlist,
} from '../data/config.js';

import { registerSecurityContentScripts } from '../core/scripting-manager.js';
import { updateSecurityRules } from '../core/ruleset-manager.js';
import { reconcileWorryFreeHighRiskHeaderRules } from '../core/worry-free-high-risk-headers-manager.js';
import { ADVANCED_ITEM_KEYS } from '../core/worry-free-advanced.js';
import {
    isWorryFreeTierSettingKey,
    computeTierCascade,
    computeTierNormalization,
} from '../core/worry-free-tiers.js';
import { reconcileWorryFreeExtraSuppressionRule } from '../core/worry-free-extra-manager.js';
import { getAutoDenyState } from '../core/cookie-clicker-autodeny-manager.js';

/******************************************************************************/

// Keys whose change is applied via registerSecurityContentScripts() (MAIN-
// world sec-*.js content script registration) rather than a DNR rule
// update. Named at module scope (not re-created per call) so the two
// handlers that need it (setSecurityConfig, setSecurityAllowlist) share
// one definition instead of two copies of the same literal list.
const SECURITY_SCRIPTLET_TOGGLE_KEYS = new Set([
    'blockPings',
    'blockDialogSpam', 'blockObfuscatedEval',
    'blockAdultNoEval', 'blockAdultFingerprinting',
    'blockScpFingerprint',
    // 1.2.0 -- the 'advanced' fingerprint row. (The three tier checkboxes
    // that gate whole groups -- including 'advanced' -- do NOT go through this
    // set: see handleSetSecurityConfig()'s tier path below.)
    ADVANCED_ITEM_KEYS.FINGERPRINT,
]);

// Keys that need BOTH registerSecurityContentScripts() AND
// updateSecurityRules() on change — every other key here is exclusively
// one or the other (see SECURITY_SCRIPTLET_TOGGLE_KEYS above). Currently
// empty: enableGPC was the only key that ever needed both (the
// navigator.globalPrivacyControl scriptlet plus a separate DNR rule),
// and GPC was removed as a feature (see CHANGELOG). Kept as real,
// reusable infrastructure — both this Set and the dispatch logic that
// reads it below — rather than removed outright, since a future toggle
// needing the same "both calls" treatment is a real possibility, not a
// hypothetical one, given it's already happened once.
// (1.2.2: the tier checkboxes, which are the keys that need "everything
// re-applied", now have their own path -- see applyTierChange() below -- so
// this set is empty again.)
const SECURITY_HYBRID_TOGGLE_KEYS = new Set();

// Keys that ALSO need reconcileWorryFreeHighRiskHeaderRules() on change —
// currently just blockAdultFingerprinting itself (this release). Session
// start/end alone (cookie-clicker-autodeny-manager.js) can't catch this
// case: the session's own active/inactive state doesn't change when only
// this checkbox does, so a reconcile call is needed here too, on top of
// the scriptlet re-registration SECURITY_SCRIPTLET_TOGGLE_KEYS already
// triggers for this same key — see worry-free-high-risk-headers-
// manager.js's own header for why this key needs both.
const SECURITY_HIGH_RISK_HEADER_TOGGLE_KEYS = new Set([ 'blockAdultFingerprinting' ]);

// Keys that need NEITHER call — persisted only, consulted at the next
// browser.runtime.onStartup instead of taking effect immediately (there
// is nothing to "register" or "apply" right now; see history-cleaner.js).
const SECURITY_STARTUP_ONLY_KEYS = new Set([ 'deleteHistoryOnStart', 'startWorryFreeOnBrowserStartup' ]);

/******************************************************************************/

export async function handleGetSecurityAllowlist() {
    return securityAllowlist;
}

// Re-applies everything a tier checkbox can switch, in one place: the sec-*
// scriptlets (Low/Medium fingerprint rows), the dynamic DNR slots (Very-low,
// Low and Medium header/block rules), the static third-party/download rules
// (the 'safe regions' tier, via their suppression rules) and the high-risk-
// site header rules (Very-low group). Before 1.2.2 these were only refreshed
// by a session start/end, so a checkbox changed mid-session did not take
// effect until the next session.
async function reapplyWorryFreeTierEffects() {
    const sessionState = await getAutoDenyState();
    await registerSecurityContentScripts();
    await updateSecurityRules();
    await reconcileWorryFreeExtraSuppressionRule(sessionState?.active === true);
    await reconcileWorryFreeHighRiskHeaderRules();
}

// The three Filter-tab tier checkboxes: ticking one also ticks every tier
// below it, unticking one also unticks every tier above it (worry-free-
// tiers.js owns the rule). The whole result is saved once and re-applied,
// and the resulting config is returned so the UI can redraw ALL the boxes.
async function applyTierChange(key, value) {
    Object.assign(securityConfig, computeTierCascade(key, value === true));
    await saveSecurityConfig();
    await reapplyWorryFreeTierEffects();
    return securityConfig;
}

export async function handleGetSecurityConfig() {
    // Repair a stored state that breaks the hierarchy (e.g. an older install
    // with 'safe regions' ticked while the 'extra' box is off): the higher
    // tier was already ineffective, this only makes the checkboxes truthful.
    const repairs = computeTierNormalization(securityConfig);
    if ( Object.keys(repairs).length !== 0 ) {
        Object.assign(securityConfig, repairs);
        await saveSecurityConfig();
    }
    return securityConfig;
}

export async function handleSetSecurityAllowlist(request) {
    const { key, value } = request;
    if ( Object.hasOwn(securityAllowlist, key) === false ) { return; }
    securityAllowlist[key] = value;
    await saveSecurityAllowlist();
    // Re-apply the relevant rule so the new allowlist takes effect immediately.
    if ( SECURITY_SCRIPTLET_TOGGLE_KEYS.has(key) ) {
        await registerSecurityContentScripts();
    } else {
        await updateSecurityRules();
    }
    return securityAllowlist;
}

export async function handleSetSecurityConfig(request) {
    const { key, value } = request;
    if ( Object.hasOwn(securityConfig, key) === false ) { return; }
    if ( isWorryFreeTierSettingKey(key) ) { return applyTierChange(key, value); }
    securityConfig[key] = value;
    await saveSecurityConfig();
    if ( SECURITY_STARTUP_ONLY_KEYS.has(key) ) { return securityConfig; }
    // Scriptlet-based toggles are registered via browser.scripting (MAIN world
    // content scripts) — call registerSecurityContentScripts() which is the
    // single function that owns all sec-* content script registrations.
    // All other keys are pure DNR toggles handled by updateSecurityRules.
    // Hybrid keys (SECURITY_HYBRID_TOGGLE_KEYS) need both calls, not just one.
    const isScriptletToggle = SECURITY_SCRIPTLET_TOGGLE_KEYS.has(key);
    if ( isScriptletToggle ) {
        await registerSecurityContentScripts();
    }
    if ( isScriptletToggle === false || SECURITY_HYBRID_TOGGLE_KEYS.has(key) ) {
        await updateSecurityRules();
    }
    if ( SECURITY_HIGH_RISK_HEADER_TOGGLE_KEYS.has(key) ) {
        await reconcileWorryFreeHighRiskHeaderRules();
    }
    return securityConfig;
}

/******************************************************************************/
