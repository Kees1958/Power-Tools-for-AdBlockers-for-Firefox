/*
 * sec-medium-fingerprint.js -- Security scriptlet: blockMediumFingerprint toggle
 *
 * Privacy & Security tab, "Medium website breakage risk enhancements (enabled
 * by default when 'advanced' is enabled in Worry-free)", row 3. Applies the
 * Privacy Inspector's LOW and MEDIUM risk mitigations -- and deliberately
 * nothing from its HIGH tier -- on websites outside the safe regions.
 *
 * SCOPE (changed in 1.2.3, per explicit request): "on websites outside safe
 * regions" -- the top-level page AND every frame, first- or third-party.
 * Before 1.2.3 this ran in third-party frames only, behind a guard copied from
 * sec-scp-fingerprint.js; that guard is gone. WHICH sites are "outside safe
 * regions" is decided entirely by the directive's excludeMatches (familiar TLDs
 * plus $saferegions domains, computed in compiled-filters.js), so a page or
 * frame on a safe-region domain never gets this script at all. Expect real
 * breakage on first-party pages (2D canvas, Web Audio, window.name and
 * visibilitychange are all used by ordinary sites) -- that is the stated
 * "medium website breakage risk".
 *
 * WHICH SIGNALS: the tiers are those of js/data/scriptlet-rule-labels.js's
 * RULE_INFO table (the single source of truth the Inspector's own risk badges
 * read). The `covers:` lines below name every RULE_INFO argument this file
 * handles; tools/check-advanced-protections.mjs fails the suite if a Low or
 * Medium entry is missing from that list, or a High one appears in it, so
 * this file cannot silently drift from the Inspector's triage.
 *
 *   Low:    IdleDetector, NDEFReader, navigator.plugins / mimeTypes,
 *           navigator.getBattery, window.name
 *   Medium: canvas 2d context, navigator.permissions.query,
 *           AudioContext / OfflineAudioContext, visibilitychange listeners
 *   NOT applied (High): WebRTC, WebGL, timezone, clipboard, sendBeacon,
 *           hardwareConcurrency/deviceMemory/... -- those stay with the
 *           existing Low-tier blockScpFingerprint item / the Inspector.
 *
 * HOW: same philosophy as sec-scp-fingerprint.js -- prefer a spec-legal,
 * non-throwing outcome (null context, rejected promise, empty list, absent
 * API) over throwing, so ordinary feature-detecting code degrades instead of
 * crashing. That is a deliberately gentler form of the Inspector's own
 * "abort-on-property-read" mitigation for the same signals. Each mitigation
 * is wrapped so that one already-locked-down property (another wrapper got
 * there first, e.g. sec-scp-fingerprint.js when both are on) can never stop
 * the others from applying.
 *
 * A MAIN-world script cannot `import` (no module scope in this injection
 * context -- see registerSecurityContentScripts() in scripting-manager.js).
 * There is deliberately NO top-level / third-party guard here (see SCOPE).
 * tools/check-advanced-protections.mjs fails the suite if a
 * `window === window.top` guard is ever reintroduced.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS,
 *                ADVANCED_ITEM_KEYS.FINGERPRINT entry)
 * Gated by:      the 'advanced' tier (js/core/worry-free-tiers.js: a live
 *                Worry-free session AND the extra, safe-regions and advanced
 *                checkboxes) AND the row's own checkbox
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){
    'use strict';

    // >>> LOW-TIER MITIGATIONS: shared VERBATIM by sec-scp-fingerprint.js and sec-medium-fingerprint.js
    // >>> (a MAIN-world script cannot import). tools/check-scp-fingerprint-tier.mjs fails the suite if the
    // >>> copies differ, so edit ALL THREE places (both scriptlets) or none.
    // Runs one mitigation; a failure (property already locked down by another
    // wrapper on this page) is not fatal and must not stop the others.
    function guarded(mitigation) {
        try { mitigation(); } catch { /* leave that one signal as-is */ }
    }

    // -- LOW: IdleDetector / NDEFReader --------------------------------------
    // covers: IdleDetector
    // covers: NDEFReader
    // Both are rare, permission-gated APIs. Reported as absent (undefined) so
    // `if ( window.IdleDetector )` / `typeof NDEFReader` feature checks take
    // their "unsupported" branch instead of throwing.
    [ 'IdleDetector', 'NDEFReader' ].forEach(function(apiName) {
        guarded(function() {
            if ( (apiName in window) === false ) { return; }
            Object.defineProperty(window, apiName, {
                configurable: true,
                get: function() {
                    console.info('[uBol] hid ' + apiName + ' (medium-risk fingerprinting protection)');
                    return undefined;
                },
            });
        });
    });

    // -- LOW: navigator.plugins / mimeTypes / getBattery ----------------------
    // covers: navigator.plugins
    // covers: navigator.mimeTypes
    // covers: navigator.getBattery
    // Same treatment as sec-scp-fingerprint.js (empty list; rejected promise).
    const navigatorProto = Object.getPrototypeOf(navigator);
    [ 'plugins', 'mimeTypes' ].forEach(function(prop) {
        guarded(function() {
            Object.defineProperty(navigatorProto, prop, {
                configurable: true,
                get: function() {
                    console.info('[uBol] blocked navigator.' + prop + ' read');
                    return [];
                },
            });
        });
    });
    guarded(function() {
        if ( typeof navigatorProto.getBattery !== 'function' ) { return; }
        navigatorProto.getBattery = new Proxy(navigatorProto.getBattery, { apply: function() {
            console.info('[uBol] blocked navigator.getBattery read');
            return Promise.reject(new TypeError('getBattery is blocked on this site'));
        } });
    });

    // -- LOW: window.name ------------------------------------------------------
    // covers: name
    // Keeps window.name empty and ignores writes, so it cannot carry an
    // identifier across navigations. (The frame's real browsing-context name,
    // used for target="..." links, is not affected -- only the script-visible
    // property.)
    guarded(function() {
        Object.defineProperty(window, 'name', {
            configurable: true,
            get: function() { return ''; },
            set: function() {},
        });
    });
    // <<< END LOW-TIER MITIGATIONS

    // -- MEDIUM: canvas 2D context ---------------------------------------------
    // covers: 2d
    // getContext('2d') returns null (spec-legal "context type unavailable").
    // Other context types are untouched here -- WebGL is a HIGH-tier signal
    // and stays with blockScpFingerprint / the Inspector.
    guarded(function() {
        const canvasProto = window.HTMLCanvasElement && window.HTMLCanvasElement.prototype;
        if ( !canvasProto || !canvasProto.getContext ) { return; }
        canvasProto.getContext = new Proxy(canvasProto.getContext, {
            apply: function(target, thisArg, args) {
                if ( args.length > 0 && args[0] === '2d' ) {
                    console.info('[uBol] blocked canvas 2d fingerprint read');
                    return null;
                }
                return Reflect.apply(target, thisArg, args);
            },
        });
    });

    // -- MEDIUM: navigator.permissions.query -------------------------------------
    // covers: navigator.permissions.query
    // query() may legally reject, so callers already need a .catch().
    guarded(function() {
        const permissionsProto = window.Permissions && window.Permissions.prototype;
        if ( !permissionsProto || typeof permissionsProto.query !== 'function' ) { return; }
        permissionsProto.query = new Proxy(permissionsProto.query, { apply: function() {
            console.info('[uBol] blocked navigator.permissions.query');
            return Promise.reject(new TypeError('permissions.query is blocked on this site'));
        } });
    });

    // -- MEDIUM: Web Audio (AudioContext and OfflineAudioContext) ---------------
    // covers: AudioContext
    // covers: OfflineAudioContext
    // Replaced by a self-consistent inert stub (same shape as
    // sec-scp-fingerprint.js's OfflineAudioContext stub, extended with the
    // live-context surface: state/resume/suspend/close) so ordinary call
    // sequences complete without throwing -- they just never produce audio.
    function audioNoop() {}
    function stubAudioNode() {
        return {
            connect: audioNoop, disconnect: audioNoop,
            start: audioNoop, stop: audioNoop,
            gain: { value: 0 }, frequency: { value: 0 },
        };
    }
    function makeAudioContextReplacement(apiName) {
        function replacement() {
            console.info('[uBol] blocked audio context: ' + apiName);
        }
        replacement.prototype = {
            createOscillator: stubAudioNode,
            createGain: stubAudioNode,
            createBufferSource: stubAudioNode,
            createScriptProcessor: stubAudioNode,
            createAnalyser: function() {
                return Object.assign(stubAudioNode(), {
                    fftSize: 2048,
                    frequencyBinCount: 1024,
                    getByteFrequencyData: audioNoop,
                    getFloatFrequencyData: audioNoop,
                });
            },
            destination: {},
            state: 'suspended',
            currentTime: 0,
            sampleRate: 44100,
            addEventListener: audioNoop,
            removeEventListener: audioNoop,
            resume: function() { return Promise.resolve(); },
            suspend: function() { return Promise.resolve(); },
            close: function() { return Promise.resolve(); },
            startRendering: function() {
                return Promise.resolve({
                    getChannelData: function() { return new Float32Array(0); },
                    length: 0,
                    sampleRate: 44100,
                    numberOfChannels: 1,
                });
            },
        };
        return replacement;
    }
    [
        'AudioContext', 'webkitAudioContext',
        'OfflineAudioContext', 'webkitOfflineAudioContext',
    ].forEach(function(apiName) {
        guarded(function() {
            if ( !window[apiName] ) { return; }
            window[apiName] = makeAudioContextReplacement(apiName);
        });
    });

    // -- MEDIUM: visibilitychange listeners ---------------------------------------
    // covers: visibilitychange
    // Registering a visibilitychange listener silently does nothing (no
    // throw), so a page cannot observe tab-switching.
    guarded(function() {
        const eventTargetProto = window.EventTarget && window.EventTarget.prototype;
        if ( !eventTargetProto || !eventTargetProto.addEventListener ) { return; }
        eventTargetProto.addEventListener = new Proxy(eventTargetProto.addEventListener, {
            apply: function(target, thisArg, args) {
                if ( args.length > 0 && String(args[0]) === 'visibilitychange' ) {
                    console.info('[uBol] ignored visibilitychange listener');
                    return;
                }
                return Reflect.apply(target, thisArg, args);
            },
        });
    });
})();
