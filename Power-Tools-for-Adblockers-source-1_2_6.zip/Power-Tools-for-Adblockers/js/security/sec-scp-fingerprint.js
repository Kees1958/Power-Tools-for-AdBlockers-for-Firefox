/*
 * sec-scp-fingerprint.js -- Security scriptlet: blockScpFingerprint toggle
 *
 * Privacy & Security tab, Low website breakage risk group, row "Enforce
 * low-risk fingerprinting protections in third-party frames outside safe
 * regions." Applies ONLY the Privacy Inspector's LOW-risk mitigations, inside
 * THIRD-PARTY frames:
 *
 *   IdleDetector, NDEFReader, navigator.plugins / mimeTypes,
 *   navigator.getBattery, window.name
 *
 * The tiers are those of js/data/scriptlet-rule-labels.js's RULE_INFO table
 * (the single source of truth the Inspector's own risk badges read). The
 * `covers:` lines below name every RULE_INFO argument this file handles;
 * tools/check-scp-fingerprint-tier.mjs fails the suite if a Low entry is
 * missing, or a Medium/High one appears.
 *
 * CHANGED in 1.2.6 (per explicit request -- "that is an error"): until 1.2.5
 * this file was a copy of sec-adult-fingerprint.js and ALSO blocked canvas,
 * WebGL, timezone, audio and WebRTC, which the Inspector rates Medium/High,
 * so the row's "low-risk" label did not match what it did. Those signals are
 * no longer touched by this row: canvas 2D and audio are covered by the
 * advanced tier's Medium row (sec-medium-fingerprint.js); WebGL, timezone and
 * WebRTC stay with the curated high-risk-site scriptlet (sec-adult-
 * fingerprint.js) and the Privacy Inspector's own per-site rules.
 *
 * A MAIN-world script cannot `import` (no module scope in this injection
 * context -- see registerSecurityContentScripts() in scripting-manager.js), so
 * the Low-tier block below is a literal copy shared with
 * sec-medium-fingerprint.js (it is marked; the tier check compares the two).
 *
 * Scope guard (unchanged -- this row is about THIRD-PARTY frames):
 *   - Top-level page (window === window.top): does nothing.
 *   - A frame whose origin equals the top page's own origin (same-origin
 *     frame, read via location.ancestorOrigins' last entry -- the
 *     outermost ancestor): does nothing. Known limit: a frame on a
 *     DIFFERENT subdomain of the same site still counts as third-party
 *     here (no public-suffix list available in a MAIN-world script) --
 *     over-protects, never under-protects.
 *   - location.ancestorOrigins itself unsupported (documented as such
 *     for Firefox in MDN's compatibility data; Mozilla bug 1085214 -- check
 *     your target Firefox version): falls through and applies the
 *     mitigation to same-origin frames too -- fails CLOSED (over-protects)
 *     rather than open (under-protects) when the browser can't answer the
 *     "is this really third-party" question at all.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS,
 *                blockScpFingerprint entry, scriptFile: 'sec-scp-fingerprint')
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){
    'use strict';

    // ── Third-party-frame guard — see this file's own header ────────────────
    if ( window === window.top ) { return; }
    const ancestorOrigins = window.location.ancestorOrigins;
    if ( ancestorOrigins && ancestorOrigins.length > 0 ) {
        const topOrigin = ancestorOrigins[ancestorOrigins.length - 1];
        if ( topOrigin === window.location.origin ) { return; }
    }
    // else: ancestorOrigins unsupported by this browser (documented as
    // such for Firefox) — fall through and apply the mitigation. Fails
    // CLOSED (over-protects a same-origin frame) rather than open.

    // >>> LOW-TIER MITIGATIONS: shared VERBATIM by sec-scp-fingerprint.js and sec-medium-fingerprint.js
    // >>> (a MAIN-world script cannot import). tools/check-scp-fingerprint-tier.mjs fails the suite if the
    // >>> copies differ, so edit ALL THREE places (both scriptlets) or none.
    // Runs one mitigation; a failure (property already locked down by another
    // wrapper on this page) is not fatal and must not stop the others.
    function guarded(mitigation) {
        try { mitigation(); } catch { /* leave that one signal as-is */ }
    }

    // -- LOW: IdleDetector / NDEFReader --------------------------------------
    // covers: IdleDetector
    // covers: NDEFReader
    // Both are rare, permission-gated APIs. Reported as absent (undefined) so
    // `if ( window.IdleDetector )` / `typeof NDEFReader` feature checks take
    // their "unsupported" branch instead of throwing.
    [ 'IdleDetector', 'NDEFReader' ].forEach(function(apiName) {
        guarded(function() {
            if ( (apiName in window) === false ) { return; }
            Object.defineProperty(window, apiName, {
                configurable: true,
                get: function() {
                    console.info('[uBol] hid ' + apiName + ' (medium-risk fingerprinting protection)');
                    return undefined;
                },
            });
        });
    });

    // -- LOW: navigator.plugins / mimeTypes / getBattery ----------------------
    // covers: navigator.plugins
    // covers: navigator.mimeTypes
    // covers: navigator.getBattery
    // Same treatment as sec-scp-fingerprint.js (empty list; rejected promise).
    const navigatorProto = Object.getPrototypeOf(navigator);
    [ 'plugins', 'mimeTypes' ].forEach(function(prop) {
        guarded(function() {
            Object.defineProperty(navigatorProto, prop, {
                configurable: true,
                get: function() {
                    console.info('[uBol] blocked navigator.' + prop + ' read');
                    return [];
                },
            });
        });
    });
    guarded(function() {
        if ( typeof navigatorProto.getBattery !== 'function' ) { return; }
        navigatorProto.getBattery = new Proxy(navigatorProto.getBattery, { apply: function() {
            console.info('[uBol] blocked navigator.getBattery read');
            return Promise.reject(new TypeError('getBattery is blocked on this site'));
        } });
    });

    // -- LOW: window.name ------------------------------------------------------
    // covers: name
    // Keeps window.name empty and ignores writes, so it cannot carry an
    // identifier across navigations. (The frame's real browsing-context name,
    // used for target="..." links, is not affected -- only the script-visible
    // property.)
    guarded(function() {
        Object.defineProperty(window, 'name', {
            configurable: true,
            get: function() { return ''; },
            set: function() {},
        });
    });
    // <<< END LOW-TIER MITIGATIONS
})();
