/*
 * worry-free-tiers.js -- the three-tier Worry-free protection hierarchy.
 *
 * The Filter (block) lists tab's "Automatically enable during Worry-free safe
 * surfing mode" section has three checkboxes, and each one gates the group of
 * Privacy & Security protections it belongs to:
 *
 *   tier 'extra'       -- "Enable the extra Worry-free safe surfing protections"
 *                         gates the "Very low website breakage risk" group.
 *   tier 'safeRegions' -- "Enable the extra 'safe regions' protections
 *                         additionally" gates the "Low website breakage risk"
 *                         group.
 *   tier 'advanced'    -- "Enable the advanced 'safe regions' protections
 *                         additionally" gates the "Medium website breakage
 *                         risk" group.
 *
 * THE HIERARCHY (a rule, not a convention): a tier is only allowed when every
 * tier BELOW it is allowed.  safeRegions needs extra; advanced needs extra AND
 * safeRegions.  It is enforced in two independent places, both defined here:
 *
 *   1. GATING (getWorryFreeTierState) -- what actually switches protections.
 *      A higher tier is never effective unless the lower ones are, whatever is
 *      stored (an old install, an imported backup, a hand-edited value).
 *   2. THE CHECKBOXES (computeTierCascade / computeTierNormalization) --
 *      ticking a higher tier automatically ticks the lower ones; unticking a
 *      lower tier automatically unticks the higher ones, so the boxes can
 *      never show a state the gating would not honour.
 *
 * Public interface: constants and pure functions only. No state, no imports.
 * Every consumer (ruleset-manager.js, compiled-filters.js, worry-free-extra-
 * manager.js, security-routes.js) imports from here -- nothing else may
 * re-derive which tier gates what (C21: one proven mechanism, not four).
 */

/******************************************************************************/
// CONFIGURATION -- declared once (B1)
/******************************************************************************/

export const WORRY_FREE_TIER = Object.freeze({
    EXTRA: 'extra',
    SAFE_REGIONS: 'safeRegions',
    ADVANCED: 'advanced',
});

// Lowest tier first. The ORDER is the hierarchy: index N requires every index
// below N. `key` is the securityConfig setting behind the Filter-tab checkbox;
// `onWhenUnset` is what an absent/undefined stored value means (config.js
// defaults: extra and safeRegions are ON, advanced is OFF -- so the first two
// are "on unless explicitly false", the last "on only if explicitly true").
export const WORRY_FREE_TIER_DEFS = Object.freeze([
    Object.freeze({ tier: WORRY_FREE_TIER.EXTRA,        key: 'worryFreeSecurityProtectionsEnabled',    onWhenUnset: true  }),
    Object.freeze({ tier: WORRY_FREE_TIER.SAFE_REGIONS, key: 'worryFreeSecurityTldProtectionsEnabled', onWhenUnset: true  }),
    Object.freeze({ tier: WORRY_FREE_TIER.ADVANCED,     key: 'worryFreeAdvancedTldProtectionsEnabled', onWhenUnset: false }),
]);

export const WORRY_FREE_TIER_SETTING_KEYS = Object.freeze(
    Object.fromEntries(WORRY_FREE_TIER_DEFS.map(def => [ def.tier, def.key ]))
);

/******************************************************************************/
// FUNCTIONS
/******************************************************************************/

function isSettingOn(config, def) {
    const value = config?.[def.key];
    return def.onWhenUnset ? value !== false : value === true;
}

export function isWorryFreeTierSettingKey(key) {
    return WORRY_FREE_TIER_DEFS.some(def => def.key === key);
}

// Which tiers are EFFECTIVELY active right now. `isSessionActive` is whether a
// Worry-free session is running. A tier is active only if its own checkbox is
// on AND the tier below it is active (extra also needs the session), so the
// result is always a prefix of the hierarchy: a higher tier can never be true
// while a lower one is false.
export function getWorryFreeTierState(config, isSessionActive) {
    let below = isSessionActive === true;
    const state = {};
    for ( const def of WORRY_FREE_TIER_DEFS ) {
        below = below && isSettingOn(config, def);
        state[def.tier] = below;
    }
    return state;
}

// What ticking/unticking `changedKey` must do to the three checkboxes.
// Returns { [settingKey]: boolean } including the changed key itself, or {}
// for a key that is not a tier key.
//   ticking a tier   -> that tier and every tier below it become ON
//   unticking a tier -> that tier and every tier above it become OFF
export function computeTierCascade(changedKey, value) {
    const index = WORRY_FREE_TIER_DEFS.findIndex(def => def.key === changedKey);
    if ( index === -1 ) { return {}; }
    const updates = {};
    if ( value === true ) {
        for ( let i = 0; i <= index; i++ ) { updates[WORRY_FREE_TIER_DEFS[i].key] = true; }
    } else {
        for ( let i = index; i < WORRY_FREE_TIER_DEFS.length; i++ ) { updates[WORRY_FREE_TIER_DEFS[i].key] = false; }
    }
    return updates;
}

// Repairs a stored state that breaks the hierarchy (a tier on while a lower
// one is off): the higher tier is switched off -- it was already ineffective
// (see getWorryFreeTierState), so this only makes the checkboxes honest.
// Returns { [settingKey]: false } for every key that needs correcting.
export function computeTierNormalization(config) {
    const updates = {};
    let lowerOff = false;
    for ( const def of WORRY_FREE_TIER_DEFS ) {
        const on = isSettingOn(config, def);
        if ( lowerOff && on ) { updates[def.key] = false; }
        if ( on === false || updates[def.key] === false ) { lowerOff = true; }
    }
    return updates;
}
