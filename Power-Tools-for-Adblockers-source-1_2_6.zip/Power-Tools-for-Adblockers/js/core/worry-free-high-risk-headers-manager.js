/*******************************************************************************

    uBlock-Stripped-Dynamic — Worry-free high-risk-sites header manager

    Manages two session-scoped chrome.declarativeNetRequest rules, present
    ONLY for the duration of an active Worry-free session AND while
    blockAdultFingerprinting itself is not explicitly disabled, for exactly
    the same 24-site list worry-free-strict-3p-manager.js already blocks
    third-party frames/scripts on (HIGH_RISK_HOSTNAMES, imported from that
    file rather than held as a third independent copy — see that constant's
    own header comment).

    These are the SAME two Permissions-Policy header protections the Low-
    tier blockScpPrivacy/blockScpSecurity items apply outside safe regions
    (js/core/ruleset-manager.js's SCP_PRIVACY_BLOCK_RULE_ID/
    SCP_SECURITY_BLOCK_RULE_ID) — same header values, reused verbatim below
    (tools/check-high-risk-sites-sync.mjs fails if the two ever diverge) —
    just scoped to this fixed 24-site list instead of "every domain outside
    the familiar-TLD list", and gated by blockAdultFingerprinting instead of
    blockScpPrivacy/blockScpSecurity. This is what makes
    blockAdultFingerprinting's own dashboard label accurate: "Always
    enforce safe-regions protections on high-risk websites" — before this
    module existed, that checkbox only ran the fingerprint-mitigation
    content script, not any header protection at all.

    Why no suppression rule (unlike worry-free-extra-manager.js's
    SUPPRESSION_RULES pattern): this checkbox adds/removes the rules
    THEMSELVES (see reconcileWorryFreeHighRiskHeaderRules() below), so the
    9.6.0-class cross-suppression bug (one shared unconditional allow rule
    silently turning off more than one item) cannot occur here — there is
    only ever one rule pair to add or remove, not several sharing one
    switch.

    Why no new 3P/download rule for these sites: worry-free-strict-3p-
    manager.js already blocks all third-party frames and all non-CDN
    third-party scripts on this exact site list, unconditionally, for the
    whole session. A CSP/header rule on requests that are already blocked
    would be redundant.

    Session rules (not dynamic) — same reasoning as worry-free-strict-3p-
    manager.js's own header: resets to empty on a genuine browser restart,
    matching cookie-clicker-autodeny-manager.js's clearAutoDenyOnBrowserStartup()
    already always ending any lingering session outright on a real restart.

    Public interface:
      onWorryFreeSessionStart() / onWorryFreeSessionEnd() — called directly
        from cookie-clicker-autodeny-manager.js's startAutoDeny()/
        restoreNow(), same call-site pattern as worry-free-strict-3p-
        manager.js's own pair
      reconcileWorryFreeHighRiskHeaderRules() — re-derives the correct rule
        state from the CURRENT session state and blockAdultFingerprinting
        config value, and fixes any mismatch. Called at SW/background
        startup (a plain cold-start case, same as worry-free-strict-3p-
        manager.js's own reconcile) AND whenever blockAdultFingerprinting
        itself is toggled while a session is already active (security-
        routes.js) — unlike the strict-3p rules, THIS module's "should be
        present" state depends on more than just session-active, so a
        config-only change needs its own reconcile call, not just the
        session start/end pair.

*******************************************************************************/

import { dnr } from '../data/ext-compat.js';
import { localRead } from '../data/ext.js';
import { securityConfig } from '../data/config.js';
import { HIGH_RISK_HOSTNAMES } from './worry-free-strict-3p-manager.js';
import {
    HIGH_RISK_HEADERS_RULES_BASE_ID,
    HIGH_RISK_HEADERS_PRIORITY,
} from './dnr-budgets.js';

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

// MUST match js/core/ruleset-manager.js's SCP_PRIVACY_BLOCK_RULE_ID/
// SCP_SECURITY_BLOCK_RULE_ID header values exactly — verified by
// tools/check-high-risk-sites-sync.mjs, not just by this comment.
const HIGH_RISK_PRIVACY_HEADER_VALUE = 'camera=(), microphone=(), display-capture=(), clipboard-read=()';
const HIGH_RISK_SECURITY_HEADER_VALUE = 'bluetooth=(), serial=(), hid=(), usb=(), local-network-access=()';

const RULE_ID_PRIVACY  = HIGH_RISK_HEADERS_RULES_BASE_ID;
const RULE_ID_SECURITY = HIGH_RISK_HEADERS_RULES_BASE_ID + 1;
const ALL_RULE_IDS = [ RULE_ID_PRIVACY, RULE_ID_SECURITY ];

/******************************************************************************/

function buildRules() {
    return [
        {
            id: RULE_ID_PRIVACY,
            priority: HIGH_RISK_HEADERS_PRIORITY,
            action: {
                type: 'modifyHeaders',
                responseHeaders: [ {
                    header: 'Permissions-Policy',
                    operation: 'append',
                    value: HIGH_RISK_PRIVACY_HEADER_VALUE,
                } ],
            },
            condition: {
                requestDomains: HIGH_RISK_HOSTNAMES,
                resourceTypes: [ 'main_frame', 'sub_frame' ],
            },
        },
        {
            id: RULE_ID_SECURITY,
            priority: HIGH_RISK_HEADERS_PRIORITY,
            action: {
                type: 'modifyHeaders',
                responseHeaders: [ {
                    header: 'Permissions-Policy',
                    operation: 'append',
                    value: HIGH_RISK_SECURITY_HEADER_VALUE,
                } ],
            },
            condition: {
                requestDomains: HIGH_RISK_HOSTNAMES,
                resourceTypes: [ 'main_frame', 'sub_frame' ],
            },
        },
    ];
}

async function addRules() {
    try {
        // Single atomic call, remove-then-add together — a partly-
        // registered state (one rule id already present from a previous
        // call) otherwise throws "does not have a unique ID" on the next
        // add attempt.
        await dnr.updateSessionRules({ addRules: buildRules(), removeRuleIds: ALL_RULE_IDS });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-high-risk-headers-manager addRules:', reason);
    }
}

async function removeRules() {
    try {
        await dnr.updateSessionRules({ removeRuleIds: ALL_RULE_IDS });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-high-risk-headers-manager removeRules:', reason);
    }
}

// isWorryFreeActive — independent copy of the exact same cycle-free-read
// pattern already established in js/core/ruleset-manager.js's own
// updateSecurityRules() and js/core/scripting-manager.js's
// isAutoDenySessionActive() — "one more independent copy of one string,
// same 'must match exactly' posture as COOKIE_CLICKER_STORAGE_KEY", kept
// as a duplicate here too rather than importing across files that don't
// currently depend on each other, for the same reasoning those two give.
async function isWorryFreeActive() {
    const AUTO_DENY_STORAGE_KEY = 'cookieClicker.autoDeny';
    const autoDenyStored = await localRead(AUTO_DENY_STORAGE_KEY).catch(() => undefined);
    return (typeof autoDenyStored === 'object' && autoDenyStored !== null && autoDenyStored.active === true)
        && securityConfig.worryFreeSecurityProtectionsEnabled !== false;
}

/******************************************************************************/
// Public interface
/******************************************************************************/

// Called directly from cookie-clicker-autodeny-manager.js's startAutoDeny()
// — the session is becoming active RIGHT NOW. Still gated on
// blockAdultFingerprinting itself: a session starting while that box is
// unchecked must not add the rules.
export async function onWorryFreeSessionStart() {
    if ( securityConfig.blockAdultFingerprinting === false ) { return; }
    await addRules();
}

// Called directly from cookie-clicker-autodeny-manager.js's restoreNow()
// (cancelAutoDeny()/expireAutoDeny()'s shared path) — the session just
// ended, so these rules must come off immediately regardless of the
// checkbox's own value (nothing to gate — removing is always correct
// once the session itself is over).
export async function onWorryFreeSessionEnd() {
    await removeRules();
}

// Re-derives the correct rule state from the CURRENT session state and
// blockAdultFingerprinting config value, and fixes any mismatch. Two
// call-site classes:
//   1. SW/background startup (background.js) — a plain cold-start
//      mismatch, same reasoning as worry-free-strict-3p-manager.js's own
//      reconcileWorryFreeStrict3pRules().
//   2. blockAdultFingerprinting itself toggled while a session is already
//      active (security-routes.js) — session start/end alone can't catch
//      this, since the session doesn't change state when only the
//      checkbox does.
export async function reconcileWorryFreeHighRiskHeaderRules() {
    const shouldBePresent = await isWorryFreeActive() && securityConfig.blockAdultFingerprinting !== false;
    let rules = [];
    try {
        rules = await dnr.getSessionRules();
    } catch {
        return; // couldn't read session rules — leave alone
    }
    const present = ALL_RULE_IDS.every(id => rules.some(r => r.id === id));
    if ( shouldBePresent && !present ) { await addRules(); }
    else if ( !shouldBePresent && present ) { await removeRules(); }
}
