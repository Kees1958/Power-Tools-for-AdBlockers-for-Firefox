/*
 * worry-free-advanced.js -- shared definitions for the "advanced" (Medium
 * website breakage risk) Worry-free protections, 1.2.0.
 *
 * Privacy & Security tab group: "Medium website breakage risk enhancements
 * (enabled by default when 'advanced' is enabled in Worry-free)". The gate is
 * the Filter (block) lists tab's "Enable the advanced 'safe regions'
 * protections additionally" checkbox (ADVANCED_SETTING_KEY below).
 *
 * The four items, and where each is implemented:
 *   1. blockMediumFirstPartyDownloads   -- CSP `sandbox` header WITHOUT
 *      allow-downloads (and, since 1.2.4, without allow-popups-to-escape-
 *      sandbox) on main_frame/sub_frame responses outside safe regions.
 *      DNR slot: ruleset-manager.js (ADVANCED_FIRST_PARTY_DOWNLOAD_BLOCK_RULE_ID).
 *      PLUS (1.2.4) a downloads-API watcher, js/core/download-guard.js, for the
 *      downloads a response header cannot stop (browser-initiated ones).
 *   2. enforceMediumSandboxSafeScripts  -- CSP `sandbox` header with a
 *      "safe scripts" flag set (scripts stay allowed; escape/redirect flags are
 *      dropped) PLUS a script-src that forbids eval. Same slot builder
 *      (ADVANCED_SANDBOX_SAFE_SCRIPTS_RULE_ID).
 *   3. blockMediumThirdParty            -- blocks third-party requests to
 *      hosts outside safe regions for every resource type EXCEPT plain HTML
 *      documents (main_frame, sub_frame), images and media. Stylesheets and
 *      fonts ARE blocked. Slot: ADVANCED_THIRD_PARTY_BLOCK_RULE_ID; its
 *      safe-region exemption is a fourth purpose in
 *      worry-free-familiar-tld-manager.js and saferegions-manager.js.
 *   4. blockMediumFingerprint           -- js/security/sec-medium-fingerprint.js
 *      (the Privacy Inspector's Low + Medium risk mitigations, on websites
 *      outside safe regions: the page itself and every frame -- 1.2.3; it was
 *      third-party frames only in 1.2.0-1.2.2). Registered from
 *      compiled-filters.js. Row order in Privacy & Security (1.2.3): items 1,
 *      2, 4, 3 of this list.
 *
 * "Outside safe regions" reuses the existing mechanism unchanged: a
 * higher-priority allow rule per familiar TLD / $saferegions domain cancels
 * the block/header rule. Items 1 and 2 are header rules at
 * WORRY_FREE_SCP_BLOCK_PRIORITY, so the EXISTING SCP allow band already
 * exempts them; only item 3 needed a new exemption band.
 *
 * Public interface: constants and pure functions only. No state.
 * Dependencies: ../data/ext-compat.js (dnr -- read lazily, inside functions).
 */

import { dnr } from '../data/ext-compat.js';
import { WORRY_FREE_TIER, WORRY_FREE_TIER_SETTING_KEYS } from './worry-free-tiers.js';

/******************************************************************************/
// CONFIGURATION -- every switch, key and value this feature uses, declared
// once (B1). Anything else in the codebase must import from here.
/******************************************************************************/

// The Filter (block) lists tab checkbox that turns the whole group on -- the
// 'advanced' tier of the three-tier hierarchy in worry-free-tiers.js, which
// owns the key and the rule that this tier needs BOTH lower tiers (the extra
// Worry-free protections and the extra 'safe regions' protections).
// Default OFF (config.js): medium breakage risk is opt-in.
export const ADVANCED_SETTING_KEY = WORRY_FREE_TIER_SETTING_KEYS[WORRY_FREE_TIER.ADVANCED];

// securityConfig keys of the four Privacy & Security rows. Each defaults to
// true (config.js) and follows worryFreeGatedOptOut semantics: unchecking one
// is a genuine opt-out, but a checked row does nothing unless Worry-free is
// active AND ADVANCED_SETTING_KEY is on.
export const ADVANCED_ITEM_KEYS = Object.freeze({
    FIRST_PARTY_DOWNLOADS: 'blockMediumFirstPartyDownloads',
    SANDBOX_SAFE_SCRIPTS:  'enforceMediumSandboxSafeScripts',
    THIRD_PARTY_BLOCK:     'blockMediumThirdParty',
    FINGERPRINT:           'blockMediumFingerprint',
});

// Item 1. Every CSP sandbox flag EXCEPT allow-downloads and (since 1.2.4)
// EXCEPT allow-popups-to-escape-sandbox. Popups a sandboxed page opens used to
// ESCAPE the sandbox, so a script in a popup could start the download the page
// itself could not; without that flag a popup inherits the sandbox (and with it
// the missing allow-downloads). allow-popups stays, so popups still open.
// This is the shipped rulesets/ruleset_worryfree_downloadblock.json flag list
// (the existing third-party download block, which keeps allow-popups-to-escape-
// sandbox) MINUS that one flag; tools/check-advanced-protections.mjs fails the
// suite if the two ever differ by anything else.
export const ADVANCED_NO_DOWNLOADS_SANDBOX_FLAGS = Object.freeze([
    'allow-forms',
    'allow-modals',
    'allow-orientation-lock',
    'allow-pointer-lock',
    'allow-popups',
    'allow-presentation',
    'allow-same-origin',
    'allow-scripts',
    'allow-storage-access-by-user-activation',
    'allow-top-navigation',
    'allow-top-navigation-by-user-activation',
    'allow-top-navigation-to-custom-protocols',
]);
export const ADVANCED_NO_DOWNLOADS_SANDBOX_VALUE =
    `sandbox ${ADVANCED_NO_DOWNLOADS_SANDBOX_FLAGS.join(' ')}`;
// The flag that used to be in that list and was removed in 1.2.4 -- named once
// so the drift check and tests can assert its ABSENCE without a magic string.
export const ADVANCED_ESCAPE_POPUPS_FLAG = 'allow-popups-to-escape-sandbox';

// Item 1 also has a second half: a downloads-API watcher (js/core/download-
// guard.js) that cancels downloads the sandbox header cannot see (browser-
// initiated ones: "Save link as", address bar, bookmarks, the PDF viewer's
// Save, ...). The `downloads` permission is OPTIONAL (manifest
// optional_permissions): it is requested from a click on the 'advanced' or
// row-1 checkbox, so nobody who never enables this is asked, and adding it
// does not block anyone's update.
export const DOWNLOAD_GUARD_PERMISSION = 'downloads';
// 1.2.6: the watcher also SHOWS A MESSAGE when it cancels a download. That needs the
// `notifications` permission, optional for the same reasons and requested in the SAME
// prompt (a permission prompt needs the click's user gesture, so it cannot be split
// into two consecutive requests). Without it the watcher still works, silently.
export const DOWNLOAD_GUARD_NOTIFY_PERMISSION = 'notifications';
export const DOWNLOAD_GUARD_PERMISSIONS = Object.freeze([
    DOWNLOAD_GUARD_PERMISSION,
    DOWNLOAD_GUARD_NOTIFY_PERMISSION,
]);

// Item 2. "Safe scripts" sandbox: scripts, same-origin and forms keep working;
// dropped are the flags that let a page escape or redirect (allow-top-
// navigation*, allow-popups-to-escape-sandbox) and allow-modals. NOTE
// allow-downloads is deliberately INCLUDED: this item must not silently block
// downloads on its own -- that is item 1's job. When both are on the browser
// enforces both policies, so downloads are blocked.
export const ADVANCED_SAFE_SCRIPTS_SANDBOX_FLAGS = Object.freeze([
    'allow-downloads',
    'allow-forms',
    'allow-orientation-lock',
    'allow-pointer-lock',
    'allow-popups',
    'allow-presentation',
    'allow-same-origin',
    'allow-scripts',
    'allow-storage-access-by-user-activation',
]);
// Forbids eval()/new Function()/string timers by omitting 'unsafe-eval', while
// NOT restricting where scripts may load from (`*`, plus data:/blob:, which
// `*` does not cover) and keeping inline scripts working. 'wasm-unsafe-eval'
// is kept so WebAssembly keeps working -- it is not eval.
export const ADVANCED_SCRIPT_SRC_NO_EVAL =
    "script-src * data: blob: 'unsafe-inline' 'wasm-unsafe-eval'";
export const ADVANCED_SAFE_SCRIPTS_HEADER_VALUE =
    `sandbox ${ADVANCED_SAFE_SCRIPTS_SANDBOX_FLAGS.join(' ')}; ${ADVANCED_SCRIPT_SRC_NO_EVAL}`;

// Item 3. Resource types a third party may still load: plain HTML documents
// (main_frame, sub_frame), images and video/audio. Everything else --
// including stylesheets and fonts -- is blocked.
export const ADVANCED_3P_EXEMPT_RESOURCE_TYPES = Object.freeze([
    'main_frame', 'sub_frame', 'image', 'media',
]);
// Used only if the browser does not expose dnr.ResourceType (never expected in
// Firefox; keeps the rule builders total in a test harness). Must not
// intersect ADVANCED_3P_EXEMPT_RESOURCE_TYPES -- checked by the suite.
export const ADVANCED_3P_FALLBACK_BLOCKED_RESOURCE_TYPES = Object.freeze([
    'script', 'stylesheet', 'font', 'object', 'xmlhttprequest',
    'ping', 'csp_report', 'websocket', 'other',
]);

/******************************************************************************/
// FUNCTIONS
/******************************************************************************/

// The resource types the third-party block (item 3) covers, derived from the
// browser's own enum so the rule can never name a type this Firefox rejects
// (an unknown type would make the whole updateDynamicRules() call fail).
// The matching exemption rules MUST use exactly this list, so both callers
// get it from here.
export function getAdvancedThirdPartyBlockedResourceTypes() {
    // `dnr` is a lazy Proxy over browser.declarativeNetRequest (ext-compat.js);
    // reading through it can throw where that API is absent (test harnesses).
    let enumObject;
    try { enumObject = dnr?.ResourceType; } catch { enumObject = undefined; }
    const all = (typeof enumObject === 'object' && enumObject !== null)
        ? Object.values(enumObject)
        : [];
    const derived = all.filter(type => ADVANCED_3P_EXEMPT_RESOURCE_TYPES.includes(type) === false);
    return derived.length > 0 ? derived : [ ...ADVANCED_3P_FALLBACK_BLOCKED_RESOURCE_TYPES ];
}

// Single definition of "is this advanced item live right now": the 'advanced'
// TIER is effective (which already means a live Worry-free session AND the
// 'extra' tier AND the 'safe regions' tier AND the advanced checkbox -- see
// getWorryFreeTierState()) AND the row itself is not opted out
// (worryFreeGatedOptOut semantics -- `!== false`, because the stored default
// is true; see config.js).
export function isAdvancedItemActive(config, itemKey, tierState) {
    return tierState?.[WORRY_FREE_TIER.ADVANCED] === true &&
        config?.[itemKey] !== false;
}
