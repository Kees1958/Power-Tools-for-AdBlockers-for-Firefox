/*******************************************************************************

    uBlock-Stripped-Dynamic — Never-consent / cookie-clicker auto-deny
    Copyright (C) 2026-present Kees1958

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/Kees1958/uBol-stripped
*/
/*
 * cookie-clicker-autodeny-manager.js — "Never consent for 30 minutes": a
 * timed, GLOBAL (all tabs) session during which every recognized consent
 * banner is auto-denied, using DDG's vendored eval-snippets action layer
 * (see js/scripting/autodeny-snippets.generated.js).
 *
 * Directly modeled on js/core/temp-disable-manager.js — same state-vector
 * shape, same guarded init/clear/release lifecycle, same four-independent-
 * paths resilience against MV3 service-worker restarts (see §6.3 of the
 * design doc). Reused, not reinvented — see each section below for the
 * exact 1:1 mapping.
 *
 * Public interface:
 *   getAutoDenyState()   — { active, untilMs?, remainingMs?, startedAtMs? }
 *   startAutoDeny()       — begin (or restart) the fixed-duration session
 *   cancelAutoDeny()       — end early (popup toggle-off, D6)
 *   expireAutoDeny()       — end on schedule (deferred-jobs alarm)
 *
 * Persisted: chrome.storage.local[STORAGE_KEY] -> { active: true, untilMs,
 * startedAtMs } | absent (absent = inactive — see getAutoDenyState()).
 *
 * Precedence (D5): a saved per-site cookie-clicker rule ALWAYS wins over
 * this session, even while active — see js/scripting/cookie-clicker-
 * click.js's own precedence check, which reads getAutoDenyState() itself.
 * This module owns the session lifecycle only, never the precedence
 * decision — that stays where the two candidate actions actually meet,
 * same separation-of-concerns temp-disable-manager.js's own header
 * documents for its filtering-mode lever.
 */


import {
    localRead, localRemove, localWrite,
} from '../data/ext.js';

import { registerJob, removeJob } from '../data/alarms.js';

import { broadcastMessage } from '../data/broadcast.js';

import {
    registerCookieClickerAutoDenyContentScripts,
    registerSecurityContentScripts,
} from './scripting-manager.js';

import {
    onWorryFreeSessionStart, onWorryFreeSessionEnd,
} from './worry-free-extra-manager.js';

import {
    onWorryFreeSessionStart as onWorryFreeSessionStartStrict3p,
    onWorryFreeSessionEnd as onWorryFreeSessionEndStrict3p,
} from './worry-free-strict-3p-manager.js';

import {
    onWorryFreeSessionStart as onWorryFreeSessionStartHighRiskHeaders,
    onWorryFreeSessionEnd as onWorryFreeSessionEndHighRiskHeaders,
} from './worry-free-high-risk-headers-manager.js';

import { updateSecurityRules } from './ruleset-manager.js';

/******************************************************************************/
// Config — magic numbers declared once, here. Referenced by: this module,
// popup.js's countdown UI (via getAutoDenyState()'s returned untilMs/
// startedAtMs, never by re-deriving the duration itself), and
// js/scripting/cookie-clicker-click.js's precedence check (via
// getAutoDenyState()'s `active` field only).
/******************************************************************************/

const STORAGE_KEY = 'cookieClicker.autoDeny';
const JOB_NAME = 'cookieClickerAutoDenyExpire';

// (8.2.16) Promoted from a single fixed duration to a chosen one, per the
// original design comment's own anticipated follow-up. Person picks from
// a small fixed set via the action dialog's own dropdown
// (js/scripting/cookie-clicker-picker.js) — same "fixed set of options,
// not a free-text field" posture as temp-disable's own
// ALLOWED_DURATIONS_MINUTES, so a compromised/buggy content script can
// never request an arbitrary duration: startAutoDeny() below validates
// against this exact array and silently falls back to the default for
// anything else.
//
// (8.5.5) Third option changed from a fixed 180 minutes to `null` —
// "until next session", same untilMs === null convention as temp-
// disable-manager.js's own indefinite ("until browser restart") pause,
// reused deliberately rather than inventing a second one. Per explicit
// request, this is now also the DEFAULT (was 60) — no expiry job is ever
// registered for it (see startAutoDeny() below); the only things that
// ever end it are an explicit cancel or clearAutoDenyOnBrowserStartup()
// (which already unconditionally ends ANY active session on a genuine
// restart, timed or not — no change needed there for this to work).
const AUTO_DENY_DURATION_OPTIONS_MINUTES = [ 20, 60, null ];
const AUTO_DENY_DURATION_DEFAULT_MINUTES = null;

const MS_PER_MINUTE = 60 * 1000;

// NOTE — no raw setTimeout/setInterval constant here, deliberately. Both
// are wiped the instant the service worker restarts (routine in MV3, not
// a rare edge case), so neither can be the actual persistence mechanism
// for a 30-minute window. The real mechanism is chrome.alarms (via the
// existing js/data/alarms.js registerJob() deferred-jobs queue, which
// DOES survive SW restarts) plus the self-healing check built into
// getAutoDenyState() itself — see that function below.

/******************************************************************************/
// State — in-memory mirror of storage, same convention as temp-disable-
// manager.js's own `cache` (module-scoped, populated lazily, re-assigned
// directly on every write, never separately invalidated since every write
// is immediately authoritative).
//
// GUARD — init: readState() below is the ONE place `cache` transitions
// from undefined (not yet loaded) to its real value.
// GUARD — clear/release: writeState(null), called from restoreNow() only,
// is the ONE place the persisted key is removed; `cache` is reassigned in
// the same call so the two can never drift.
/******************************************************************************/

let cache;

async function readState() {
    if ( cache !== undefined ) { return cache; }
    cache = await localRead(STORAGE_KEY) ?? null;
    return cache;
}

async function writeState(state) {
    cache = state;
    if ( state === null ) {
        return localRemove(STORAGE_KEY);
    }
    return localWrite(STORAGE_KEY, state);
}

/******************************************************************************/
// Public state read — also the single place that self-heals a missed
// expiry (path 2 of the four-path resilience scheme; see this module's
// own header for paths 1/3/4).
/******************************************************************************/

export async function getAutoDenyState() {
    const state = await readState();
    if ( state === null ) { return { active: false }; }
    // (8.5.5) untilMs === null means "until next session" — no expiry to
    // self-heal against at all, same as temp-disable-manager.js's own
    // indefinite pause. Only an explicit cancel or a genuine browser
    // restart (clearAutoDenyOnBrowserStartup()) ever ends this.
    if ( state.untilMs === null ) {
        return { active: true, untilMs: null, startedAtMs: state.startedAtMs };
    }
    if ( Date.now() >= state.untilMs ) {
        await restoreNow();
        return { active: false };
    }
    return {
        active: true,
        untilMs: state.untilMs,
        remainingMs: state.untilMs - Date.now(),
        startedAtMs: state.startedAtMs,
    };
}

/******************************************************************************/
// Guarded restore — the single place the session ever ends: releases both
// the storage entry AND the deferred alarm job together (never one
// without the other), unregisters the auto-deny content-script group
// (D11 — registration-presence IS the gate), then broadcasts the new
// state (path 3).
//
// GUARD: no-op if already restored (state === null) — early-cancel
// (cancelAutoDeny(), D6 toggle-off) and scheduled expiry (expireAutoDeny())
// can legitimately race right at the boundary; without this guard,
// whichever call loses the race would still try to remove an
// already-removed job and unregister an already-unregistered script.
/******************************************************************************/

async function restoreNow() {
    const state = await readState();
    if ( state === null ) { return; }
    await writeState(null);
    // (8.5.5) An "until next session" (untilMs === null) session never had
    // a job registered in the first place — same guard as temp-disable-
    // manager.js's own restoreNow() for its indefinite pause.
    if ( state.untilMs !== null ) {
        await removeJob(JOB_NAME);
    }
    await registerCookieClickerAutoDenyContentScripts(); // RELEASE — sees active:false, unregisters (D11)
    await registerSecurityContentScripts(); // RELEASE — re-reads isAutoDenySessionActive()==false, drops the worryFreeOverride scriptlets back to whatever securityConfig itself says (v8.3.12)
    await onWorryFreeSessionEnd(); // RELEASE — re-adds the WORRY_FREE_EXTRA_ALLOW_PRIORITY suppression rule (see worry-free-extra-manager.js)
    await onWorryFreeSessionEndStrict3p(); // RELEASE — drops the strict 3P block-all-except-CDN rules for the 24 high-risk sites (v8.4.10, see worry-free-strict-3p-manager.js)
    await onWorryFreeSessionEndHighRiskHeaders(); // RELEASE — drops the two Permissions-Policy header rules for the same 24 sites (this release — see worry-free-high-risk-headers-manager.js)
    await updateSecurityRules(); // RELEASE — re-reads the auto-deny state (freshly, inside updateSecurityRules() itself) and finds it inactive; the strict3p/adult-site fingerprint overrides this feeds lapse back to their pre-session state (v8.5.7 — login-with's own force-disable was removed together with the feature itself, see CHANGELOG)
    broadcastMessage({ cookieClickerAutoDeny: { active: false } });
}

/******************************************************************************/

// Starts (or restarts, extending the countdown) the auto-deny session.
// Starts (or restarts, extending the countdown) the auto-deny session.
// `requestedDurationMinutes` comes from the person's own dropdown choice
// in the action dialog (D6/§5.1) — validated against
// AUTO_DENY_DURATION_OPTIONS_MINUTES here, never trusted as-is, same
// guard posture as every other content-script-sourced input this
// project validates workflow-side rather than relying on the sender to
// have sent something sane.
export async function startAutoDeny(requestedDurationMinutes) {
    const durationMinutes = AUTO_DENY_DURATION_OPTIONS_MINUTES.includes(requestedDurationMinutes)
        ? requestedDurationMinutes
        : AUTO_DENY_DURATION_DEFAULT_MINUTES;
    // (8.5.5) null means "until next session" — no expiry timestamp, no
    // deferred job. Same untilMs === null convention as temp-disable-
    // manager.js's own indefinite pause.
    const untilMs = durationMinutes === null ? null : Date.now() + durationMinutes * MS_PER_MINUTE;
    const startedAtMs = Date.now();
    await writeState({ active: true, untilMs, startedAtMs });
    if ( untilMs !== null ) {
        await registerJob(JOB_NAME, untilMs); // path 1 — survives SW restart
    }
    await registerCookieClickerAutoDenyContentScripts(); // INIT — sees active:true, registers (D11)
    await registerSecurityContentScripts(); // INIT — re-reads isAutoDenySessionActive()==true, activates blockAdultNoEval/blockAdultFingerprinting for the session if the person hadn't already enabled them (v8.3.12, worryFreeOverride — see compiled-filters.js)
    await onWorryFreeSessionStart(); // INIT — removes the WORRY_FREE_EXTRA_ALLOW_PRIORITY suppression rule, making the reserved-tier extra blocklist + TLD-scoped 3P block effective (see worry-free-extra-manager.js)
    await onWorryFreeSessionStartStrict3p(); // INIT — adds the strict 3P block-all-except-CDN rules for the 24 high-risk sites (v8.4.10, ported from Kees1958/3P-Matrix-lite's own level 4 — see worry-free-strict-3p-manager.js)
    await onWorryFreeSessionStartHighRiskHeaders(); // INIT — adds the two Permissions-Policy header rules for the same 24 sites, gated additionally on blockAdultFingerprinting itself (this release — see worry-free-high-risk-headers-manager.js)
    // NOTE (v8.4.10): coveryourtracks.eff.org's own extra protection no
    // longer lives here — it's now covered by adding the site to
    // compiled-filters.js's ADULT_SITE_MATCHES instead (via the existing
    // worryFreeOverride on blockAdultNoEval/blockAdultFingerprinting,
    // registerSecurityContentScripts() below), which gives it the same
    // full 6-vector protection set the curated high-risk sites get,
    // superseding the narrower dedicated layer this file used to add.
    await updateSecurityRules(); // INIT — re-reads the auto-deny state (freshly, inside updateSecurityRules() itself) and finds it active, applies the blockSuspicious3pLinks/blockWebBundles worryFreeOverride slots (v8.4.7) for the session's duration (v8.5.7 — login-with's own force-disable was removed together with the feature itself, see CHANGELOG)
    broadcastMessage({ cookieClickerAutoDeny: { active: true, untilMs } });
    return { active: true, untilMs, startedAtMs, durationMinutes };
}

// User-initiated early end — popup menu toggle-off (D6) or the countdown
// panel's own cancel control. Same effect as letting the timer run out,
// just sooner; both converge on restoreNow().
export async function cancelAutoDeny() {
    await restoreNow();
    return { active: false };
}

// Scheduled end, invoked from background.js's 'cookieClickerAutoDenyExpire'
// route when js/data/alarms.js's processDueJobs() finds this job's time
// has passed (path 1).
export async function expireAutoDeny() {
    await restoreNow();
    return { active: false };
}

// Called once from background.js's browser.runtime.onStartup listener —
// which fires only on a genuine browser launch, never on the routine
// service-worker sleep/wake cycles MV3 does constantly within a single
// browser session. Mirrors temp-disable-manager.js's own
// clearTempDisableOnBrowserStartup() exactly, same reasoning: Worry-free
// is meant to last only as long as the browsing session it was started
// in — if the browser itself restarts, protection should come back to
// normal browsing, not silently keep counting down on whatever time was
// left. Safe to call even when no session is active — restoreNow()'s own
// guard makes that a no-op.
//
// BUG FIXED: previously the untilMs deadline (persisted in
// chrome.storage.local, which survives a genuine browser restart by
// design) was left untouched on startup — only the session-scoped
// suppression rule got reconciled to match whatever state was already
// there (see reconcileWorryFreeExtraSuppressionRule() in worry-free-
// extra-manager.js, still used for the separate SW-cold-start/version-
// bump case in background.js's start(), where that IS the correct
// behavior). The result: closing and reopening the browser mid-session
// silently resumed the countdown instead of ending it. Reported as:
// "closing and reopening the browser, the Worry-free timer just
// continues, while a browser restart should turn all such timers off."
export async function clearAutoDenyOnBrowserStartup() {
    await restoreNow();
}

/******************************************************************************/
