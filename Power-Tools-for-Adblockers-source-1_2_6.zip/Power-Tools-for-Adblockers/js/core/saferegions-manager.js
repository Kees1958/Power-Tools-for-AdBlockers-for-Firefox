/*
 * saferegions-manager.js — per-domain $saferegions exemptions
 *
 * A person can type "@@example.com$saferegions" as a line in the Allow list
 * dashboard editor (see js/util/site-mode-parser.js's
 * extractSaferegionsFromText()/textFromSaferegions() and js/ui/mode-
 * editor.js). That one domain (and its subdomains, via the same
 * host-anchored urlFilter every familiar-TLD rule already uses) is then
 * exempted from every worry-free protection the familiar-TLD mechanism
 * (worry-free-familiar-tld-manager.js) already knows how to exempt a whole
 * TLD from — the same three purposes, same priority constants, same rule
 * shape, same builder function. This is deliberately NOT a "no filtering"
 * entry: the site is still filtered by everything else (static filter
 * lists, cosmetic/scriptlet rules, Matrix overrides, …) — only the
 * worry-free-specific protections are suppressed for it.
 *
 * Reuses buildTldAllowRules() from worry-free-familiar-tld-manager.js
 * rather than a second copy (rule 13 in the porting notes this was ported
 * from: "one list, one place" — two independent builders for the same
 * rule shape would drift apart the first time one of them changes and the
 * other doesn't). Only the id band (this module's own,
 * SAFEREGIONS_*_RULES_BASE_ID) and the input list (individual domains
 * instead of bare TLDs) differ from that module's own three calls.
 *
 * Public interface:
 *   getSaferegionsDomains()     — returns the current stored domain list
 *                                 (array of ASCII/punycoded hostnames),
 *                                 [] if nothing is stored yet
 *   setSaferegionsDomains(domains) — normalizes, persists, and
 *                                 regenerates the dynamic allow rules to
 *                                 match; returns the normalized list
 *   restoreSaferegionsRules()  — idempotent: (re)generates the dynamic
 *                                 rules from whatever is currently stored
 *                                 — called once at SW/background startup,
 *                                 same lifecycle as ensureFamiliarTldRules()
 */

import { dnr } from '../data/ext-compat.js';
import { localRead, localWrite } from '../data/ext.js';
import { buildTldAllowRules } from './worry-free-familiar-tld-manager.js';
import {
    WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY,
    WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
    WORRY_FREE_SCP_TLD_ALLOW_PRIORITY,
    SAFEREGIONS_TLD_ALLOW_RULES_BASE_ID,
    SAFEREGIONS_DOWNLOAD_TLD_ALLOW_RULES_BASE_ID,
    SAFEREGIONS_SCP_TLD_ALLOW_RULES_BASE_ID,
    SAFEREGIONS_RULES_END_ID,
    SAFEREGIONS_ADVANCED_3P_ALLOW_RULES_BASE_ID,
    ADVANCED_3P_TLD_ALLOW_PRIORITY,
} from './dnr-budgets.js';
import { getAdvancedThirdPartyBlockedResourceTypes } from './worry-free-advanced.js';

const STORAGE_KEY = 'saferegionsState';

/******************************************************************************/

export async function getSaferegionsDomains() {
    const domains = await localRead(STORAGE_KEY);
    return Array.isArray(domains) ? domains : [];
}

/******************************************************************************/
// (Re)generates all three dynamic rule sets from the given domain list and
// applies them atomically. Scoped strictly to this module's own reserved
// id band (SAFEREGIONS_TLD_ALLOW_RULES_BASE_ID ..
// SAFEREGIONS_RULES_END_ID) — the dynamic rules table is shared with
// several other subsystems (ruleset-manager.js, matrix-block-rules.js,
// builtin-whitelist-rules.js, mode-manager.js, worry-free-familiar-tld-
// manager.js), so this NEVER reads/removes/replaces the whole table, only
// the ids in its own band.
/******************************************************************************/

async function applySaferegionsRules(domains) {
    let existing;
    try {
        existing = await dnr.getDynamicRules();
    } catch (reason) {
        console.error('[uBlock-Dynamic] saferegions-manager/applySaferegionsRules(getDynamicRules):', reason);
        return;
    }
    const removeRuleIds = existing
        .filter(r => r.id >= SAFEREGIONS_TLD_ALLOW_RULES_BASE_ID && r.id < SAFEREGIONS_RULES_END_ID)
        .map(r => r.id);

    const addRules = [
        // The first three purposes: same condition shapes, same priorities as
        // worry-free-familiar-tld-manager.js's own applyFamiliarTldRules()
        // — see that function's own comment for why each shape is what it
        // is (SCP's main_frame+null-domainType in particular).
        ...buildTldAllowRules(domains, SAFEREGIONS_TLD_ALLOW_RULES_BASE_ID, WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY),
        ...buildTldAllowRules(domains, SAFEREGIONS_DOWNLOAD_TLD_ALLOW_RULES_BASE_ID, WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY),
        ...buildTldAllowRules(domains, SAFEREGIONS_SCP_TLD_ALLOW_RULES_BASE_ID, WORRY_FREE_SCP_TLD_ALLOW_PRIORITY, [ 'main_frame', 'sub_frame' ], null),
        // 1.2.0 -- fourth purpose, identical to
        // worry-free-familiar-tld-manager.js's advanced-third-party band (see
        // the comment there): same helper for the resource types, same
        // thirdParty scope, keyed on a literal domain.
        ...buildTldAllowRules(domains, SAFEREGIONS_ADVANCED_3P_ALLOW_RULES_BASE_ID, ADVANCED_3P_TLD_ALLOW_PRIORITY, getAdvancedThirdPartyBlockedResourceTypes(), 'thirdParty'),
    ];

    try {
        // Single atomic call — a partial apply (rules removed but not yet
        // re-added, or vice versa) would leave a window where either every
        // saferegions domain loses its exemption or every third-party
        // request is allowed, depending on which half landed first.
        await dnr.updateDynamicRules({ removeRuleIds, addRules });
    } catch (reason) {
        console.error('[uBlock-Dynamic] saferegions-manager/applySaferegionsRules(updateDynamicRules):', reason);
    }
}

/******************************************************************************/
// Public interface
/******************************************************************************/

export async function setSaferegionsDomains(domains) {
    // Dedupe + normalize — the parser (extractSaferegionsFromText()) already
    // lowercases and punycodes each domain, but a bulk caller (e.g. Restore
    // settings) may not have gone through that path.
    const normalized = [ ...new Set(domains.map(d => String(d).toLowerCase())) ].sort();
    await localWrite(STORAGE_KEY, normalized);
    await applySaferegionsRules(normalized);
    return normalized;
}

// Called once at SW/background startup — dynamic rules DO persist across
// service-worker/browser restarts, but a fresh install has none yet, and
// re-applying unconditionally (even for an empty list) is what clears out
// any leftover rules from a domain that was removed from the list since
// the last time this ran but before the browser restarted.
export async function restoreSaferegionsRules() {
    const domains = await getSaferegionsDomains();
    await applySaferegionsRules(domains);
}
