/*
 * worry-free-familiar-tld-manager.js — editable "familiar TLDs" allowlist
 *
 * BRAVE VARIANT (this release) — replaces the two former STATIC rulesets
 * (ruleset_worryfree_tldallow / ruleset_worryfree_download_tldallow, 52
 * hardcoded TLDs each, removed from manifest.json's rule_resources) with
 * a user-editable list, persisted to storage and applied as DYNAMIC DNR
 * rules — see dnr-budgets.js's own header on
 * WORRY_FREE_FAMILIAR_TLD_ALLOW_RULES_BASE_ID for why a static ruleset
 * can't be made editable at runtime at all.
 *
 * BASE_TLDS and the browser-language auto-detection logic are reused,
 * not reinvented, from the person's own 3P-Matrix-lite extension —
 * specifically core/tld-engine.js's mode-1 ("Browser") computeAutoTlds()
 * algorithm (BASE_TLDS, LANG_DEFAULT_COUNTRY, LANG_WORLD_DEFAULTS,
 * REGION_PAIRINGS, EU_LANGS), ported verbatim rather than the simpler
 * util/tld-utils.js browserCountryTlds() this module used at first. Same
 * project, same author, same language/country-code mismatch problem
 * already solved and proven there — see that engine's own comments for
 * exactly why each specific omission/inclusion exists (e.g. why bare
 * "sv" must NOT auto-map to a country, why "uk" the language and "uk"
 * the ccTLD must never be conflated). Adapted here to this codebase's
 * async/await + browser-namespace conventions (the original is
 * chrome.*-callback-style). Deliberately NOT ported: tld-engine.js's
 * mode-2/mode-3 ("Continent"/"Worldwide") LANG_TLD_MAP expansion — this
 * extension has no scope-mode selector, and the resulting worldwide
 * lists (up to a dozen countries per detected language) are sized for a
 * different UI than a single editable default value.
 *
 * Public interface:
 *   getFamiliarTlds()            — returns the current stored TLD list as
 *                                   one comma-separated string, computing
 *                                   and persisting the default on first
 *                                   read if nothing is stored yet
 *   getDefaultFamiliarTlds()     — computes (never persists) BASE_TLDS
 *                                   (unconditional) + the browser's own
 *                                   auto-detected country TLDs (which
 *                                   adds Five Eyes + Ireland specifically
 *                                   when English is detected), as one
 *                                   comma-separated string
 *   setFamiliarTlds(text)        — parses, normalizes, persists the given
 *                                   text as the new list, regenerates the
 *                                   dynamic allow rules to match
 *   restoreFamiliarTldsToDefault() — computes the default, persists it,
 *                                   regenerates the dynamic allow rules,
 *                                   and returns the default text (so the
 *                                   caller can repopulate its own UI
 *                                   without a second round-trip)
 *   ensureFamiliarTldRules()     — idempotent: (re)generates the dynamic
 *                                   rules from whatever's currently
 *                                   stored (or the computed default, on
 *                                   first run). Call once at SW startup —
 *                                   dynamic rules persist across restarts,
 *                                   but a fresh install has none yet.
 */

import { dnr } from '../data/ext-compat.js';
import { browser, localRead, localWrite } from '../data/ext.js';
import {
    WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY,
    WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
    WORRY_FREE_FAMILIAR_TLD_ALLOW_RULES_BASE_ID,
    WORRY_FREE_FAMILIAR_DOWNLOAD_TLD_ALLOW_RULES_BASE_ID,
    WORRY_FREE_FAMILIAR_TLD_RULES_END_ID,
    WORRY_FREE_SCP_TLD_ALLOW_RULES_BASE_ID,
    WORRY_FREE_SCP_TLD_ALLOW_RULES_END_ID,
    WORRY_FREE_SCP_TLD_ALLOW_PRIORITY,
    ADVANCED_3P_TLD_ALLOW_RULES_BASE_ID,
    ADVANCED_3P_TLD_ALLOW_RULES_END_ID,
    ADVANCED_3P_TLD_ALLOW_PRIORITY,
} from './dnr-budgets.js';
import { getAdvancedThirdPartyBlockedResourceTypes } from './worry-free-advanced.js';

const STORAGE_KEY = 'worryFreeFamiliarTlds';

/******************************************************************************/
// Default computation — reused from 3P-Matrix-lite, not reinvented.
/******************************************************************************/

// Generic TLDs always included regardless of browser language — verbatim
// from the original (pre-Brave-variant) uBlock-Stripped-Dynamic's own
// WORRY_FREE_GENERIC_TLDS (tools/build-rulesets.mjs), not 3P-Matrix-lite's
// smaller BASE_TLDS — per explicit request, since this list matches what
// the person remembered shipping with more TLDs.
const BASE_TLDS = [
    'com', 'net', 'org', 'info', 'biz', 'io', 'co', 'ai',
    'shop', 'store', 'site', 'online', 'tech', 'app', 'cloud', 'tv',
];

// Five Eyes country codes — verbatim from the original (pre-Brave-
// variant) uBlock-Stripped-Dynamic source's WORRY_FREE_FIVE_EYES_CC.
// NOT unconditional (corrected after an initial misread of the request)
// — only added when English is detected, via LANG_WORLD_DEFAULTS below,
// alongside Ireland. Kept as its own named constant so that entry reads
// as "Five Eyes + Ireland" rather than a re-typed literal list.
const FIVE_EYES_CC = [ 'us', 'uk', 'ca', 'au', 'nz' ];

// EU language codes — used only to add 'eu' to the auto-detected set when
// any EU-associated language is present, verbatim from 3P-Matrix-lite's
// data/constants.js EU_LANGS (this project's own five-tier layering
// keeps js/core/ from importing a sibling extension's files directly, so
// the constant is duplicated here rather than shared at import time —
// keep the two in sync by hand if either list changes).
const EU_LANGS = {
    bg: 1, hr: 1, cs: 1, da: 1, nl: 1, et: 1, fi: 1, fr: 1, de: 1, el: 1,
    hu: 1, ga: 1, it: 1, lv: 1, lt: 1, mt: 1, pl: 1, pt: 1, ro: 1, sk: 1, sl: 1, es: 1, sv: 1,
};

// Explicit mapping from a bare 2-letter language code to its most likely
// default COUNTRY — used ONLY when the browser reports a language with
// no region subtag at all (e.g. "nl", not "nl-NL"). Verbatim from
// tld-engine.js's LANG_DEFAULT_COUNTRY.
//
// Why this table exists at all: language code != country code in many
// cases. "sv" is the ISO code for Swedish, but "sv" is ALSO the ccTLD
// for El Salvador — without this map (and without deliberately omitting
// "sv" from it), a bare "sv" browser language would silently add El
// Salvador's TLD. Every omission below is as deliberate as every
// inclusion.
const LANG_DEFAULT_COUNTRY = {
    nl: 'nl', de: 'de', it: 'it', pl: 'pl',
    da: 'dk', fi: 'fi', el: 'gr', hu: 'hu', cs: 'cz',
    sk: 'sk', hr: 'hr', bg: 'bg', tr: 'tr',
    th: 'th', vi: 'vn', id: 'id', ja: 'jp', ko: 'kr',
    he: 'il', hi: 'in',
    // Omitted (ambiguous without a region subtag):
    //   sv — Swedish ≠ El Salvador's "sv" ccTLD; needs "sv-SE"
    //   no — kept out for consistency
    //   zh — could be CN, TW, HK, SG
    //   uk — Ukrainian language; "uk" ccTLD is the United Kingdom — never auto-guess
    //   ar — could be any of 20+ Arabic-speaking countries
};

// World languages spoken as a primary/official language across many
// countries, where a single "the" default country would be dishonest —
// add this small cluster of the most-read source countries instead.
// Checked BEFORE LANG_DEFAULT_COUNTRY for a bare tag (see
// computeBrowserCountryTlds() below) — these languages are deliberately
// absent from that other table for the same reason.
//
// English is NOT here — Five Eyes + Ireland are added by a separate,
// unconditional final check in computeBrowserCountryTlds() instead (see
// that function's own comment), so they apply whether English shows up
// bare ("en") or region-qualified ("en-US", "en-GB", etc.), not only the
// bare case every other entry in this table is limited to.
const LANG_WORLD_DEFAULTS = {
    fr: [ 'fr', 'be', 'ca' ],               // France, Belgium, Canada (Quebec)
    es: [ 'es', 'mx', 'ar' ],               // Spain, Mexico, Argentina — three largest sources
};

// Hand-picked region-pairing table — used only when the browser DOES
// supply a region subtag (e.g. "en-IE", "da-FO"). Adds a companion
// country alongside the region itself, only where that region has its
// own distinct national identity and its readers commonly also read the
// larger parent country's sources. Verbatim from tld-engine.js's
// REGION_PAIRINGS.
const REGION_PAIRINGS = {
    'en-ie': [ 'uk' ],   // Ireland <-> UK
    'en-uk': [ 'us' ],   // UK <-> US
    'en-gb': [ 'us' ],
    'en-us': [ 'uk' ],
    'da-fo': [ 'dk' ],   // Faroe Islands <-> Denmark
    'en-im': [ 'uk' ],   // Isle of Man <-> UK
    'fr-ca': [ 'fr' ],   // Canadian French <-> France
    'es-mx': [ 'es' ],   // Mexican Spanish <-> Spain
    'pt-br': [ 'pt' ],   // Brazilian Portuguese <-> Portugal
};

// Reads the browser's accepted languages and derives country TLDs —
// exact port of tld-engine.js's computeAutoTlds() at mode=1 ("Browser":
// country only, no continent/worldwide expansion). Never throws: any
// failure to read accept-languages just yields an empty auto-detected
// set (BASE_TLDS still apply on their own).
async function computeBrowserCountryTlds() {
    let langs;
    try {
        langs = await browser.i18n.getAcceptLanguages();
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-familiar-tld-manager/computeBrowserCountryTlds:', reason);
        return [];
    }
    const countries = [];
    let hasEuLang = false;
    let hasEnglishLang = false;
    for ( const lang of (langs ?? []) ) {
        const parts = lang.toLowerCase().split('-');
        const lc = parts[0];
        if ( EU_LANGS[lc] ) { hasEuLang = true; }
        if ( lc === 'en' ) { hasEnglishLang = true; }

        if ( parts.length > 1 ) {
            // Explicit region subtag present (e.g. "nl-BE" -> "be") — use
            // it directly; it's already an actual country, not a guess.
            const region = parts[parts.length - 1];
            if ( /^[a-z]{2,3}$/.test(region) && !countries.includes(region) ) {
                countries.push(region);
            }
            // Companion country from the hand-picked pairing table, if any.
            const pairKey = `${lc}-${region}`;
            for ( const c of (REGION_PAIRINGS[pairKey] ?? []) ) {
                if ( !countries.includes(c) ) { countries.push(c); }
            }
        } else if ( LANG_WORLD_DEFAULTS[lc] ) {
            // Bare world-language tag — add the whole cluster of
            // most-read source countries, not a single guess.
            for ( const c of LANG_WORLD_DEFAULTS[lc] ) {
                if ( !countries.includes(c) ) { countries.push(c); }
            }
        } else if ( LANG_DEFAULT_COUNTRY[lc] ) {
            // Bare tag for a language with one unambiguous default country.
            const dflt = LANG_DEFAULT_COUNTRY[lc];
            if ( !countries.includes(dflt) ) { countries.push(dflt); }
        }
        // Bare tag matching neither table (e.g. "zh", "ar") — no
        // TLD is added at all rather than guessing wrong; same as
        // tld-engine.js's own mode-1 behavior.
    }
    if ( hasEuLang && !countries.includes('eu') ) { countries.push('eu'); }
    // Final, unconditional check — runs regardless of what shape English
    // appeared in (bare "en" or region-qualified "en-US"/"en-GB"/etc.),
    // per explicit request: whenever English is present at all, add
    // Five Eyes + Ireland. Deduped against everything already collected
    // above (e.g. a region-qualified "en-GB" will already have pushed
    // "gb" and "us" via REGION_PAIRINGS — this only adds whichever of
    // Five Eyes + Ireland aren't already present, never a second copy).
    if ( hasEnglishLang ) {
        for ( const c of FIVE_EYES_CC ) {
            if ( !countries.includes(c) ) { countries.push(c); }
        }
        if ( !countries.includes('ie') ) { countries.push('ie'); }
    }
    return countries;
}

// BASE_TLDS (unconditional) + whatever the browser's own language
// settings auto-detect (which adds Five Eyes + Ireland specifically when
// English is detected — see computeBrowserCountryTlds()'s own final
// check above), deduped, as one comma-separated string — this is what a
// fresh install (or an explicit "restore TLD's" click) resets the list to.
export async function getDefaultFamiliarTlds() {
    const auto = await computeBrowserCountryTlds();
    const merged = [];
    for ( const t of [ ...BASE_TLDS, ...auto ] ) {
        if ( !merged.includes(t) ) { merged.push(t); }
    }
    return merged.join(', ');
}

/******************************************************************************/
// Parsing / normalization
/******************************************************************************/

// Splits on comma AND/OR whitespace (either separator style is accepted,
// matching how someone would naturally type or paste a list), lowercases,
// strips a leading dot if present (a person typing ".com" instead of
// "com" shouldn't produce a rule that can never match), dedupes, drops
// anything that isn't a plausible bare TLD (letters/digits only, 2-24
// chars — matches this project's own generic-TLD shape assumption
// elsewhere, e.g. compiled-filters.js's ADULT_SITE_MATCHES domain
// extraction), and drops empties from trailing/doubled separators.
const VALID_TLD_RE = /^[a-z0-9]{2,24}$/;

// Exported (1.2.4) so js/core/download-guard.js can turn the stored TLD text into
// the same list the DNR exemption rules are built from.
export function parseFamiliarTlds(text) {
    const seen = new Set();
    const tlds = [];
    for ( let raw of (text ?? '').split(/[,\s]+/) ) {
        raw = raw.trim().toLowerCase();
        if ( raw.startsWith('.') ) { raw = raw.slice(1); }
        if ( raw === '' || seen.has(raw) ) { continue; }
        if ( !VALID_TLD_RE.test(raw) ) { continue; }
        seen.add(raw);
        tlds.push(raw);
    }
    return tlds;
}

/******************************************************************************/
// Storage
/******************************************************************************/

export async function getFamiliarTlds() {
    const stored = await localRead(STORAGE_KEY);
    if ( typeof stored === 'string' && stored.trim() !== '' ) { return stored; }
    // Nothing stored yet (fresh install, or a version that predates this
    // feature) — compute, persist, and return the default so the next
    // read doesn't recompute it, and so ensureFamiliarTldRules() below
    // and getFamiliarTlds() always agree on what's "current".
    const defaultText = await getDefaultFamiliarTlds();
    await localWrite(STORAGE_KEY, defaultText);
    return defaultText;
}

/******************************************************************************/
// Dynamic DNR rule generation
/******************************************************************************/

// Host-anchored TLD test — NOT a substring test on the whole URL. `||`
// anchors the match at the start of a (sub-)domain label; `^` must be
// followed by a separator (anything except a letter, digit, or one of
// `_ - . %`) or the end of the URL — critically, a dot is NOT a
// separator, so this cannot match partway through a longer label.
// Was `*.${tld}*` (an unanchored substring test on the WHOLE URL,
// including path/query) until this fix: "com" anywhere — a subdomain
// label, the path, the query, or the first letters of a label like the
// ".fr" in "x.free-offers.ru" or the ".co" in "coupon-ads.xyz" — made a
// URL "safe" and exempt from every protection this module guards.
// `||com^` correctly matches `foo.com` (the "." before "com" is a valid
// label boundary, the end-of-host after it is a valid separator) but
// NOT `commit.foo.com`'s leading "com" (the very next character, "m",
// is not a separator, so `^` fails there) — confirmed against Chrome's
// own DNR `RuleCondition` documentation, which MDN documents identically.
function familiarTldUrlFilter(tld) {
    return `||${tld}^`;
}

// Builds the allow-rule set for one purpose (tldallow, download-tldallow,
// or SCP-tldallow) — same condition shape the two former static
// rulesets used (domainType: thirdParty), just generated at runtime
// instead of baked in at build time. resourceTypes
// defaults to the original [script, sub_frame] scope; the SCP purpose
// passes its own broader scope (see applyFamiliarTldRules() below) since
// permission APIs are typically invoked from the top-level page itself,
// not just scripts/sub_frames. domainType defaults to 'thirdParty'
// (matching the original two purposes, both third-party-only concerns);
// pass null to omit it entirely — REQUIRED for SCP, whose own block rule
// has thirdPartyOnly:false (applies to first-party too, since visiting
// an unfamiliar site directly should also have its permissions
// restricted) — an exemption still scoped to thirdParty-only would fail
// to exempt a familiar-TLD site visited directly, leaving its own
// first-party permissions incorrectly blocked. baseId + index per TLD —
// caller guarantees tlds.length stays well under the reserved band's own
// headroom (see dnr-budgets.js).
// Exported for reuse by saferegions-manager.js — a person-added
// `$saferegions` exemption for a single domain needs EXACTLY this same
// condition shape per purpose (priority, resourceTypes, domainType), just
// keyed on a literal domain instead of a bare TLD. `||domain^` is the
// identical host-anchor construct either way (see familiarTldUrlFilter()'s
// own header) — one rule-building function, not two independent copies
// that could quietly drift apart (rule 13, "one list, one place").
export function buildTldAllowRules(tlds, baseId, priority, resourceTypes = [ 'script', 'sub_frame' ], domainType = 'thirdParty') {
    return tlds.map((tld, i) => ({
        id: baseId + i,
        priority,
        action: { type: 'allow' },
        condition: {
            urlFilter: familiarTldUrlFilter(tld),
            ...(domainType ? { domainType } : {}),
            resourceTypes,
        },
    }));
}

// (Re)generates both dynamic rule sets from the given TLD list and
// applies them atomically. Scoped strictly to this module's own reserved
// id band (WORRY_FREE_FAMILIAR_TLD_ALLOW_RULES_BASE_ID ..
// WORRY_FREE_FAMILIAR_TLD_RULES_END_ID) — the dynamic rules table is
// shared with several other subsystems (ruleset-manager.js,
// matrix-block-rules.js, builtin-whitelist-rules.js, mode-manager.js), so
// this NEVER reads/removes/replaces the whole table, only the ids in its
// own band, mirroring ruleset-manager.js's own USER_RULES_BASE_ID-scoped
// pattern (not 3P-Matrix-lite's simpler wipe-everything approach, which
// is only safe there because that extension owns the entire dynamic
// table by itself).
async function applyFamiliarTldRules(tlds) {
    let existing;
    try {
        existing = await dnr.getDynamicRules();
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-familiar-tld-manager/applyFamiliarTldRules(getDynamicRules):', reason);
        return;
    }
    const removeRuleIds = existing
        .filter(r =>
            (r.id >= WORRY_FREE_FAMILIAR_TLD_ALLOW_RULES_BASE_ID && r.id < WORRY_FREE_FAMILIAR_TLD_RULES_END_ID) ||
            (r.id >= WORRY_FREE_SCP_TLD_ALLOW_RULES_BASE_ID && r.id < WORRY_FREE_SCP_TLD_ALLOW_RULES_END_ID) ||
            (r.id >= ADVANCED_3P_TLD_ALLOW_RULES_BASE_ID && r.id < ADVANCED_3P_TLD_ALLOW_RULES_END_ID)
        )
        .map(r => r.id);

    const addRules = [
        ...buildTldAllowRules(tlds, WORRY_FREE_FAMILIAR_TLD_ALLOW_RULES_BASE_ID, WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY),
        ...buildTldAllowRules(tlds, WORRY_FREE_FAMILIAR_DOWNLOAD_TLD_ALLOW_RULES_BASE_ID, WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY),
        // SCP (Sandboxed Content Permissions) — this release. main_frame
        // included (permission APIs are typically invoked from the
        // top-level page), and no domainType restriction at all (null) —
        // see buildTldAllowRules()'s own header for why thirdParty-only
        // would leave a familiar-TLD site's own first-party permissions
        // incorrectly blocked.
        ...buildTldAllowRules(tlds, WORRY_FREE_SCP_TLD_ALLOW_RULES_BASE_ID, WORRY_FREE_SCP_TLD_ALLOW_PRIORITY, [ 'main_frame', 'sub_frame' ], null),
        // 1.2.0 -- FOURTH purpose: exemption for the "advanced" third-party
        // block (ruleset-manager.js's ADVANCED_THIRD_PARTY_BLOCK_RULE_ID).
        // Must use EXACTLY the resource types that block covers (same
        // helper, called by both) and the same thirdParty scope, at a
        // priority just above it. The two 'advanced' header rules need no
        // band of their own -- the SCP band above already exempts them.
        ...buildTldAllowRules(tlds, ADVANCED_3P_TLD_ALLOW_RULES_BASE_ID, ADVANCED_3P_TLD_ALLOW_PRIORITY, getAdvancedThirdPartyBlockedResourceTypes(), 'thirdParty'),
    ];

    try {
        // Single atomic call (C14) — a partial apply (rules removed but
        // not yet re-added, or vice versa) would leave a window where
        // either every familiar TLD is blocked or every third-party
        // request is allowed, depending on which half landed first.
        await dnr.updateDynamicRules({ removeRuleIds, addRules });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-familiar-tld-manager/applyFamiliarTldRules(updateDynamicRules):', reason);
    }
    // BRAVE VARIANT — blockScpFingerprint's own content-script
    // registration computes its excludeMatches from this same TLD list
    // (see compiled-filters.js's SECURITY_SCRIPTLETS entry), so it needs
    // re-registering whenever this list changes too — deliberately NOT
    // done here (would create scripting-manager.js -> compiled-
    // filters.js -> worry-free-familiar-tld-manager.js -> scripting-
    // manager.js, a real circular import) — see ruleset-routes.js's
    // handleSetWorryFreeFamiliarTlds/handleRestoreWorryFreeFamiliarTlds,
    // which call registerSecurityContentScripts() right after this
    // function returns instead.
}

/******************************************************************************/
// Public interface
/******************************************************************************/

export async function setFamiliarTlds(text) {
    const tlds = parseFamiliarTlds(text);
    const normalizedText = tlds.join(', ');
    await localWrite(STORAGE_KEY, normalizedText);
    await applyFamiliarTldRules(tlds);
    return normalizedText;
}

export async function restoreFamiliarTldsToDefault() {
    const defaultText = await getDefaultFamiliarTlds();
    return setFamiliarTlds(defaultText);
}

// Called once at SW startup (background.js) — dynamic rules DO persist
// across service-worker/browser restarts (unlike session rules), but a
// fresh install or an update from a version predating this feature has
// none yet, so this ensures they exist and match whatever's stored
// (or the computed default) every time the SW starts, cheaply (one
// getDynamicRules() read to check, same cost either way).
export async function ensureFamiliarTldRules() {
    const text = await getFamiliarTlds();
    await applyFamiliarTldRules(parseFamiliarTlds(text));
}
