#!/usr/bin/env node
// check-scripting-site-mode-gating-semgrep.mjs — an AST-based parallel
// cross-check for the same bug class check-scripting-site-mode-
// gating.mjs guards (see ARCHITECTURE.md's HARD CONSTRAINT of the same
// name), using semgrep instead of a line-based regex scan.
//
// WHY THIS EXISTS ALONGSIDE, NOT INSTEAD OF, THE ORIGINAL CHECK:
// the original script's enclosingFunctionName() finds the nearest
// PRECEDING TEXT LINE matching `function name(`, walking backward —
// simple, fast (near-instant), and correct for every real call site in
// this codebase today (verified: 23/23 match). But it is fundamentally
// blind to any other JS function-declaration shape: an arrow function
// assigned to a const, a function expression, or (in principle) a
// method shorthand — none of these match `function name(`, so the
// regex silently returns `func: null` ("no enclosing function found —
// check by hand") for any of them. This gap is currently DORMANT (no
// live call site uses one of these shapes — confirmed by scanning all
// 23 real call sites), not live, but it is real: injecting a synthetic
// arrow-function-based call site (`const handleX = async (req, sender)
// => { ...browser.scripting.executeScript... }`) and running the
// original script against it reproduces `func: null` exactly as
// predicted; running THIS script's semgrep rule against the same
// synthetic file correctly resolves `handleX` (verified once, then
// reverted — not a permanent test fixture in this codebase).
//
// This script:
//   - runs tools/check-scripting-site-mode-gating.semgrep.yml (real AST
//     matching via semgrep, across 8 function-declaration shapes: named
//     declaration, function expression, arrow-const, all four ×
//     async/non-async, plus the `$OBJ.$PROP = async function $FUNC()`
//     namespace-assignment idiom this codebase's own scripting-
//     manager.js actually uses)
//   - extracts the resolved $FUNC name from each match (embedded in the
//     rule's own message text — this semgrep version doesn't expose
//     pattern-inside-bound metavariables in --json's top-level metavars
//     field, so the message-text route is used instead; verified this
//     resolves correctly against all 23 real call sites and the
//     synthetic arrow-function test)
//   - looks up EACH result against the SAME CLASSIFIED map imported
//     from check-scripting-site-mode-gating.mjs (B15 — one source of
//     domain knowledge, not two independently-maintained copies that
//     could drift)
//
// Hard check, same failure semantics as the original: an unclassified
// call site fails the run. Running BOTH this and the original gives
// double coverage from two structurally different detection mechanisms
// — a real bug that somehow evaded one approach's blind spot is very
// unlikely to also evade the other's.
//
// Usage: node tools/check-scripting-site-mode-gating-semgrep.mjs
import { execFileSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { EXIT_DID_NOT_RUN } from './_check-constants.mjs';
import { CLASSIFIED, enclosingFunctionName } from './check-scripting-site-mode-gating.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const RULE_FILE = 'tools/check-scripting-site-mode-gating.semgrep.yml';

// KNOWN, INVESTIGATED SEMGREP QUIRK: for the `registerContentScripts.
// register = async function register() {...}` namespace-property-
// assignment idiom (js/core/scripting-manager.js), semgrep matches the
// call correctly but its own message-string metavariable interpolation
// deterministically fails to substitute $FUNC (reproduced 3x, not
// flaky — literal "$FUNC" appears unresolved in extra.message). The
// underlying MATCH location is correct; only the message-text
// convenience substitution fails for this one specific nested-function-
// via-property-assignment shape.
//
// Rather than hardcode the (file, line) this affects — which broke
// silently the first time an unrelated edit shifted this exact call
// site from line 916 to line 924, turning a known-benign quirk into a
// false "unclassified" failure — this dynamically re-derives what the
// ORIGINAL regex-based script (enclosingFunctionName(), imported above)
// resolves for the exact same file/line semgrep just matched. If the
// regex script independently resolves a real function name there, that
// resolution is trusted as the fallback (the two mechanisms agreeing
// via a DIFFERENT code path is exactly the cross-check's own point);
// only semgrep's own message-formatting step failed, not the
// underlying match. This is NOT a blanket "trust original on any
// failure" escape hatch — it only fires when func is unresolved AND the
// regex script independently confirms a real answer for that specific
// location; any other unresolved case still fails the run.

console.log('=== Semgrep cross-check: browser.scripting call-site classification (AST-based) ===\n');

let semgrepJson;
try {
    const out = execFileSync(
        'semgrep',
        [ '--config', RULE_FILE, 'js/', '--exclude', 'generated', '--json' ],
        { cwd: ROOT, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 }
    );
    semgrepJson = JSON.parse(out);
} catch (err) {
    // semgrep isn't guaranteed to be on PATH in every environment (it's
    // a pip package, not an npm devDependency this repo's own package
    // manager tracks) — treat "semgrep not installed/runnable" as a
    // skip, not a hard failure, so this check doesn't block a session
    // that genuinely doesn't have it available. A real classification
    // MISMATCH (below) still hard-fails when semgrep did run.
    console.log(`semgrep did not run: ${err.message}`);
    console.log('SKIPPED (not a hard failure — semgrep is an external tool, not an npm devDependency; install separately: pip install semgrep).');
    process.exit(EXIT_DID_NOT_RUN);
}

if ( semgrepJson.errors && semgrepJson.errors.length > 0 ) {
    console.log('FAIL: semgrep reported parse/rule errors:');
    console.log(JSON.stringify(semgrepJson.errors, null, 2));
    process.exit(1);
}

const FUNC_FROM_MESSAGE_RE = /inside function (\w+)/;

let failures = 0;
const seen = new Set();

console.log(`Semgrep found ${semgrepJson.results.length} browser.scripting call site(s).\n`);

for ( const result of semgrepJson.results ) {
    const relPath = result.path.startsWith(ROOT) ? path.relative(ROOT, result.path) : result.path;
    const lineNo = result.start.line;
    const m = FUNC_FROM_MESSAGE_RE.exec(result.extra.message);
    let func = m ? m[1] : null;

    if ( func === null || func === '$FUNC' ) {
        // See the KNOWN, INVESTIGATED SEMGREP QUIRK comment above — try
        // the regex-based script's own independent resolution for this
        // exact (file, line) before giving up on it.
        try {
            const src = fs.readFileSync(path.join(ROOT, relPath), 'utf8');
            const lines = src.split('\n');
            const regexResolution = enclosingFunctionName(lines, lineNo - 1);
            if ( regexResolution !== null ) {
                func = regexResolution;
                console.log(`  (${relPath}:${lineNo}: semgrep message-interpolation quirk — using regex-script's own independent resolution "${regexResolution}")`);
            }
        } catch {
            // file read failed — fall through, func stays unresolved,
            // handled as a real failure below same as any other case
        }
    }

    const key = `${relPath}::${func}`;
    if ( seen.has(key) ) { continue; }
    seen.add(key);

    const fileMap = CLASSIFIED.get(relPath);
    const entry = func !== null ? fileMap?.get(func) : undefined;

    if ( entry === undefined ) {
        failures++;
        console.log(`✗ UNCLASSIFIED: ${relPath}:${lineNo} — inside ${func ? `function "${func}"` : '(semgrep could not resolve an enclosing function — check by hand)'}`);
        continue;
    }
    console.log(`✓ ${entry.status.padEnd(10)} ${relPath}::${func}`);
}

console.log('');
if ( failures > 0 ) {
    console.log(`${failures} unclassified browser.scripting call site(s) (semgrep cross-check) — do not zip until triaged.`);
    process.exit(1);
}
console.log('All browser.scripting call sites are classified (semgrep cross-check).');
