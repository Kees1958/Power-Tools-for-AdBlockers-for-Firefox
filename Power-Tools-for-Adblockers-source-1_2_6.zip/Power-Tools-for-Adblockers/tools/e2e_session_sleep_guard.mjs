// tools/e2e_session_sleep_guard.mjs -- behavioral proof for the 1.2.6 sleep safeguard.
//
// Firefox may put the background (an event page) to sleep. A sleeping page's timers do
// not run, so nothing would end a Privacy Inspector / Matrix session at its 5-minute
// deadline. Policy (explicit request): a session still running when the background goes
// to sleep is ended like a TIMED ending -- same stop path, same reason.
//
// Two layers, both proven here against the REAL modules:
//   1. endPrivacyInspectorAfterSleep() / endMatrixAfterSleep(), called from
//      runtime.onSuspend (registered in background.js -- checked by reading its source);
//   2. the WAKE-UP BACKSTOP: a session restored from storage when the module loads (the
//      page slept while it ran; its timers are gone) is ended at once. Needed because
//      Firefox does not guarantee async work started inside onSuspend completes.
// The panel is told through the same BroadcastChannel message a timeout uses, with the
// same reason, so it shows its usual "time is up" message.
import fs from 'fs';
import path from 'path';
import { store, registeredScripts } from './_mock-browser-env.mjs';

/******************************************************************************/
// CONFIGURATION -- declared once
/******************************************************************************/

const ROOT = path.resolve(import.meta.dirname, '..');
const PI_STORAGE_KEY = 'privacyInspectorState';     // = STORAGE_KEY in core/privacy-inspector.js
const MATRIX_STORAGE_KEY = 'matrixPanelState';      // = STORAGE_KEY in core/matrix-panel.js
const TAB_ID = 1;
const HOST = 'example.com';
const BROADCAST_SETTLE_MS = 60;                     // BroadcastChannel delivery is asynchronous
const CHANNEL_NAME = 'uBOL';                        // = broadcast.js

/******************************************************************************/
// Harness
/******************************************************************************/

let failures = 0;
function check(name, cond, detail = '') {
    if ( cond ) { console.log(`  PASS: ${name}`); }
    else { failures++; console.log(`  FAIL: ${name}${detail ? ` -- ${detail}` : ''}`); }
}
function modUrl(rel, query = '') { return `file://${path.join(ROOT, rel)}${query}`; }
function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

const { MSG_PRIVACY_INSPECTOR_CLOSED, MSG_MATRIX_CLOSED } = await import(modUrl('js/data/message-types.js'));
const { SESSION_SLEEP_END_REASON } = await import(modUrl('js/data/timing-constants.js'));

const received = [];
const channel = new globalThis.BroadcastChannel(CHANNEL_NAME);
channel.onmessage = event => { received.push(event.data); };
async function closedMessages(what) {
    await wait(BROADCAST_SETTLE_MS);
    return received.filter(m => m?.what === what);
}
function runningSession(extra = {}) {
    return { tabId: TAB_ID, host: HOST, phase: 'running', startTime: Date.now(), timeElapsed: 0, ...extra };
}

console.log('=== e2e: Privacy Inspector / Matrix sleep safeguard ===\n');

/******************************************************************************/
console.log('Wiring');
{
    const bg = fs.readFileSync(path.join(ROOT, 'js/workflow/background.js'), 'utf8')
        .replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
    const at = bg.indexOf('browser.runtime.onSuspend?.addListener(');
    check('background.js registers runtime.onSuspend at TOP LEVEL (an event page only wakes for listeners registered at load)',
        at !== -1 && /^browser\.runtime\.onSuspend\?\.addListener\(/m.test(bg));
    const body = bg.slice(at, bg.indexOf('});', at));
    check('...and it ends BOTH a Privacy Inspector and a Matrix session',
        body.includes('endPrivacyInspectorAfterSleep()') && body.includes('endMatrixAfterSleep()'));
    check('the sleep ending uses the SAME reason as a timed ending', SESSION_SLEEP_END_REASON === 'timeout');
    const pi = fs.readFileSync(path.join(ROOT, 'js/core/privacy-inspector.js'), 'utf8');
    const mx = fs.readFileSync(path.join(ROOT, 'js/core/matrix-panel.js'), 'utf8');
    check("...which is the literal the modules' own timeout paths pass to their stop functions",
        pi.includes("stopPrivacyInspector('timeout')") && mx.includes("stopMatrix('timeout')"));
}

/******************************************************************************/
const pi = await import(modUrl('js/core/privacy-inspector.js'));
const mx = await import(modUrl('js/core/matrix-panel.js'));

console.log('\nPrivacy Inspector: ended when the background goes to sleep');
{
    check('precondition: nothing to end -> false, and nothing broadcast', await pi.endPrivacyInspectorAfterSleep() === false &&
        (await closedMessages(MSG_PRIVACY_INSPECTOR_CLOSED)).length === 0);
    await pi.startPrivacyInspector(TAB_ID, HOST);
    check('a session is running', (await pi.getPrivacyInspectorData())?.session?.host === HOST);
    check('its probe content script is registered', [ ...registeredScripts.keys() ].length > 0);
    const ended = await pi.endPrivacyInspectorAfterSleep();
    check('endPrivacyInspectorAfterSleep() reports that it ended a session', ended === true);
    check('the session is gone', await pi.getPrivacyInspectorData() === null);
    check('its stored state no longer holds a session', store.session[PI_STORAGE_KEY]?.session === null);
    check('its probe content script is unregistered', [ ...registeredScripts.keys() ].length === 0);
    const closed = await closedMessages(MSG_PRIVACY_INSPECTOR_CLOSED);
    check('the panel was told, ONCE, with the timeout reason (so it shows its usual "time is up" message)',
        closed.length === 1 && closed[0].reason === 'timeout');
    check('a second call is a no-op: false, no second broadcast', await pi.endPrivacyInspectorAfterSleep() === false &&
        (await closedMessages(MSG_PRIVACY_INSPECTOR_CLOSED)).length === 1);
}

console.log('\nMatrix panel: ended when the background goes to sleep');
{
    check('precondition: nothing to end -> false', await mx.endMatrixAfterSleep() === false);
    await mx.startMatrix(TAB_ID, HOST);
    check('a session is running', (await mx.getMatrixData())?.session?.host === HOST);
    check('endMatrixAfterSleep() reports that it ended a session', await mx.endMatrixAfterSleep() === true);
    check('the session is gone', await mx.getMatrixData() === null);
    check('its stored state no longer holds a session', store.session[MATRIX_STORAGE_KEY]?.session === null);
    const closed = await closedMessages(MSG_MATRIX_CLOSED);
    check('the panel was told, ONCE, with the timeout reason', closed.length === 1 && closed[0].reason === 'timeout');
    check('a second call is a no-op: false, no second broadcast', await mx.endMatrixAfterSleep() === false &&
        (await closedMessages(MSG_MATRIX_CLOSED)).length === 1);
}

/******************************************************************************/
console.log('\nWake-up backstop: a session restored from storage means the page slept while it ran');
{
    received.length = 0;
    // The page slept while an Inspector session ran: storage.session still holds it,
    // but every timer is gone. A fresh copy of the module is what a woken page loads.
    store.session[PI_STORAGE_KEY] = { session: runningSession(), entries: [] };
    const woken = await import(modUrl('js/core/privacy-inspector.js', '?wake=running'));
    await wait(BROADCAST_SETTLE_MS);
    check('a RUNNING Inspector session found at load is ended', await woken.getPrivacyInspectorData() === null &&
        store.session[PI_STORAGE_KEY]?.session === null);
    const closed = await closedMessages(MSG_PRIVACY_INSPECTOR_CLOSED);
    check('...and the panel is told with the timeout reason', closed.length === 1 && closed[0].reason === 'timeout');

    received.length = 0;
    store.session[PI_STORAGE_KEY] = { session: runningSession({ phase: 'paused', startTime: null, timeElapsed: 1000 }), entries: [] };
    const wokenPaused = await import(modUrl('js/core/privacy-inspector.js', '?wake=paused'));
    await wait(BROADCAST_SETTLE_MS);
    check('a PAUSED Inspector session found at load is ended too', await wokenPaused.getPrivacyInspectorData() === null);

    received.length = 0;
    store.session[PI_STORAGE_KEY] = { session: null, entries: [] };
    await import(modUrl('js/core/privacy-inspector.js', '?wake=empty'));
    await wait(BROADCAST_SETTLE_MS);
    check('nothing stored -> nothing ended, nothing broadcast (a normal browser start)',
        received.filter(m => m?.what === MSG_PRIVACY_INSPECTOR_CLOSED).length === 0);

    store.session[PI_STORAGE_KEY] = { session: runningSession(), entries: [] };
    const wokenThenStart = await import(modUrl('js/core/privacy-inspector.js', '?wake=then-start'));
    await wokenThenStart.startPrivacyInspector(TAB_ID, 'new.example.com');
    await wait(BROADCAST_SETTLE_MS);      // long enough for a LATE backstop to (wrongly) fire
    check('a NEW session started right after the wake-up is NOT ended by the backstop',
        (await wokenThenStart.getPrivacyInspectorData())?.session?.host === 'new.example.com');
    await wokenThenStart.stopPrivacyInspector('user');

    received.length = 0;
    store.session[MATRIX_STORAGE_KEY] = { session: runningSession(), entriesByDomain: {} };
    const wokenMx = await import(modUrl('js/core/matrix-panel.js', '?wake=running'));
    await wait(BROADCAST_SETTLE_MS);
    check('a RUNNING Matrix session found at load is ended', await wokenMx.getMatrixData() === null &&
        store.session[MATRIX_STORAGE_KEY]?.session === null);
    const mxClosed = await closedMessages(MSG_MATRIX_CLOSED);
    check('...and the panel is told with the timeout reason', mxClosed.length === 1 && mxClosed[0].reason === 'timeout');

    received.length = 0;
    store.session[MATRIX_STORAGE_KEY] = { session: null, entriesByDomain: {} };
    await import(modUrl('js/core/matrix-panel.js', '?wake=empty'));
    await wait(BROADCAST_SETTLE_MS);
    check('Matrix: nothing stored -> nothing ended, nothing broadcast',
        received.filter(m => m?.what === MSG_MATRIX_CLOSED).length === 0);
}

channel.close();

console.log('');
if ( failures > 0 ) {
    console.log(`FAIL: e2e session sleep guard (${failures} failure(s))`);
    process.exitCode = 1;
} else {
    console.log('PASS: e2e session sleep guard (0 failure(s))');
}

// The real session modules leave timers/listeners alive; exit explicitly so the suite's
// per-script timeout is never what ends this script.
process.exit(process.exitCode ?? 0);
