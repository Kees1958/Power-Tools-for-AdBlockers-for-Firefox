// check-high-risk-sites-sync.mjs
//
// Two independent things must stay in sync with this codebase's real
// source of truth or the high-risk-sites header protections silently
// drift from what the fingerprint/3P-block protections already cover:
//
//   1. worry-free-strict-3p-manager.js's HIGH_RISK_HOSTNAMES (24 bare
//      hostnames) must be the exact same site set as compiled-filters.js's
//      ADULT_SITE_MATCHES (24 hostnames, wildcard match-pattern form,
//      '*://host/*' + '*://*.host/*' per site) — both are deliberately
//      independent copies (see HIGH_RISK_HOSTNAMES's own header for why),
//      but "independent" must not mean "allowed to drift".
//   2. worry-free-high-risk-headers-manager.js's own Permissions-Policy
//      header value strings must match js/core/ruleset-manager.js's
//      SCP_PRIVACY_BLOCK_RULE_ID/SCP_SECURITY_BLOCK_RULE_ID values
//      exactly — the high-risk-sites headers are supposed to be the SAME
//      protection as the Low-tier SCP items, just scoped to a fixed site
//      list instead of "outside familiar TLDs".

import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
function read(p) { return fs.readFileSync(path.join(ROOT, p), 'utf8'); }

console.log('=== check-high-risk-sites-sync ===');
let ok = true;

/******************************************************************************/
// 1. Hostname list sync
/******************************************************************************/

const strict3pSrc = read('js/core/worry-free-strict-3p-manager.js');
const compiledFiltersSrc = read('js/core/compiled-filters.js');

const hostnamesMatch = strict3pSrc.match(/export const HIGH_RISK_HOSTNAMES = \[([\s\S]*?)\];/);
if ( !hostnamesMatch ) {
    ok = false;
    console.log('FAIL: could not find HIGH_RISK_HOSTNAMES in worry-free-strict-3p-manager.js — did it get renamed or restructured?');
} else {
    const hostnames = [ ...hostnamesMatch[1].matchAll(/'([^']+)'/g) ].map(m => m[1]);

    const adultMatchesMatch = compiledFiltersSrc.match(/const ADULT_SITE_MATCHES = \[([\s\S]*?)\];/);
    if ( !adultMatchesMatch ) {
        ok = false;
        console.log('FAIL: could not find ADULT_SITE_MATCHES in compiled-filters.js — did it get renamed or restructured?');
    } else {
        // Match only quoted strings that look like an actual match
        // pattern ('*://host/*') — safer than trying to strip //
        // comments line-by-line, since the patterns THEMSELVES contain
        // "//" (the URL scheme separator), which would make a naive
        // comment-stripper truncate every real entry at its own "://".
        const patterns = [ ...adultMatchesMatch[1].matchAll(/'(\*:\/\/[^']*)'/g) ].map(m => m[1]);
        // Each site appears as two patterns: '*://host/*' and '*://*.host/*'.
        // Extract the bare host from each and dedupe.
        const adultHostnames = [ ...new Set(patterns.map(p => {
            const m = p.match(/^\*:\/\/(?:\*\.)?([^/]+)\/\*$/);
            return m ? m[1] : null;
        }).filter(Boolean)) ];

        const missingFromAdult = hostnames.filter(h => !adultHostnames.includes(h));
        const missingFromHighRisk = adultHostnames.filter(h => !hostnames.includes(h));

        console.log(`Checked ${hostnames.length} HIGH_RISK_HOSTNAMES entries against ${adultHostnames.length} ADULT_SITE_MATCHES hosts.`);
        if ( missingFromAdult.length > 0 ) {
            ok = false;
            console.log(`FAIL: in HIGH_RISK_HOSTNAMES but missing from ADULT_SITE_MATCHES: ${missingFromAdult.join(', ')}`);
        }
        if ( missingFromHighRisk.length > 0 ) {
            ok = false;
            console.log(`FAIL: in ADULT_SITE_MATCHES but missing from HIGH_RISK_HOSTNAMES: ${missingFromHighRisk.join(', ')}`);
        }
        if ( missingFromAdult.length === 0 && missingFromHighRisk.length === 0 ) {
            console.log('PASS: HIGH_RISK_HOSTNAMES and ADULT_SITE_MATCHES cover the exact same site set.');
        }
    }
}

/******************************************************************************/
// 2. Permissions-Policy header value sync
/******************************************************************************/

const rulesetManagerSrc = read('js/core/ruleset-manager.js');
const highRiskHeadersSrc = read('js/core/worry-free-high-risk-headers-manager.js');

function extractHeaderValue(src, idConstName) {
    // Finds "id: <idConstName>," then the next "value: '...'," after it —
    // good enough for this file's own consistent formatting, not a full
    // JS parse.
    const idIdx = src.indexOf(`id: ${idConstName}`);
    if ( idIdx === -1 ) { return null; }
    const valueMatch = src.slice(idIdx).match(/value:\s*'([^']*)'/);
    return valueMatch ? valueMatch[1] : null;
}

const scpPrivacyValue = extractHeaderValue(rulesetManagerSrc, 'SCP_PRIVACY_BLOCK_RULE_ID');
const scpSecurityValue = extractHeaderValue(rulesetManagerSrc, 'SCP_SECURITY_BLOCK_RULE_ID');

const highRiskPrivacyMatch = highRiskHeadersSrc.match(/HIGH_RISK_PRIVACY_HEADER_VALUE = '([^']*)'/);
const highRiskSecurityMatch = highRiskHeadersSrc.match(/HIGH_RISK_SECURITY_HEADER_VALUE = '([^']*)'/);
const highRiskPrivacyValue = highRiskPrivacyMatch ? highRiskPrivacyMatch[1] : null;
const highRiskSecurityValue = highRiskSecurityMatch ? highRiskSecurityMatch[1] : null;

if ( scpPrivacyValue === null || scpSecurityValue === null || highRiskPrivacyValue === null || highRiskSecurityValue === null ) {
    ok = false;
    console.log('FAIL: could not extract one or more Permissions-Policy header values — did a constant name or formatting change?');
} else {
    if ( scpPrivacyValue !== highRiskPrivacyValue ) {
        ok = false;
        console.log(`FAIL: privacy header value diverged.\n  ruleset-manager.js (SCP_PRIVACY_BLOCK_RULE_ID): ${JSON.stringify(scpPrivacyValue)}\n  worry-free-high-risk-headers-manager.js:        ${JSON.stringify(highRiskPrivacyValue)}`);
    }
    if ( scpSecurityValue !== highRiskSecurityValue ) {
        ok = false;
        console.log(`FAIL: security header value diverged.\n  ruleset-manager.js (SCP_SECURITY_BLOCK_RULE_ID): ${JSON.stringify(scpSecurityValue)}\n  worry-free-high-risk-headers-manager.js:         ${JSON.stringify(highRiskSecurityValue)}`);
    }
    if ( scpPrivacyValue === highRiskPrivacyValue && scpSecurityValue === highRiskSecurityValue ) {
        console.log('PASS: high-risk-sites header values match the SCP privacy/security rules exactly.');
    }
}

console.log('');
process.exitCode = ok ? 0 : 1;
