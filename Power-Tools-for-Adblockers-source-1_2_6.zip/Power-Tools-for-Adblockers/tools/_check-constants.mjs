// tools/_check-constants.mjs — constants shared by the check scripts and
// complete-check.mjs. Declared ONCE here (single-place convention), so a
// wrapper and the orchestrator can never disagree about what a value means.
//
// EXIT_DID_NOT_RUN
//   Exit code an INFORMATIONAL check script returns when the underlying
//   tool could not run at all (missing binary, missing config file,
//   stale path). Distinct from 0 ("ran, nothing to report") and from
//   findings-present. complete-check.mjs collects every informational
//   check that exits with this code and lists them in its SUMMARY, so an
//   informational check that silently does nothing can no longer read as
//   a green tick. It never changes the overall pass/fail exit code —
//   informational checks stay informational.
export const EXIT_DID_NOT_RUN = 3;
