// tools/check-scp-fingerprint-tier.mjs -- keeps js/security/sec-scp-fingerprint.js
// (Privacy & Security, Low group: "Enforce low-risk fingerprinting protections in
// third-party frames outside safe regions.") doing EXACTLY what its label says.
//
// History: until 1.2.5 that file was a verbatim copy of sec-adult-fingerprint.js
// (canvas, WebGL, timezone, audio, plugins, battery, WebRTC) and the old
// check-scp-fingerprint-copy-sync.mjs guarded THAT copy. The label said "low-risk",
// the code blocked Medium and High signals too. 1.2.6 made the code match the label;
// this check replaces the old one and enforces the new contract:
//
//   1. its `covers:` lines are exactly the Privacy Inspector's LOW-tier arguments
//      (js/data/scriptlet-rule-labels.js RULE_INFO) -- no Low entry missing, no
//      Medium/High one claimed;
//   2. no Medium/High signal appears in its code;
//   3. its Low-tier block is byte-identical to the one in sec-medium-fingerprint.js
//      (a MAIN-world script cannot import, so it is a marked copy);
//   4. it still has its third-party-frame guard (this row is about THIRD-PARTY
//      frames; the medium row is the one that covers the page itself).
//
// HARD FAILURE on any mismatch. Proven by deliberate breakage -- see CHANGELOG 1.2.6.
import fs from 'fs';
import path from 'path';
import {
    stripComments, readRuleInfoTiers, readCovers, readSharedLowBlock, tokensFoundIn,
} from './_rule-info-tiers.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const SCP = 'js/security/sec-scp-fingerprint.js';
const MEDIUM = 'js/security/sec-medium-fingerprint.js';
const GUARD_MARKERS = Object.freeze([ 'window === window.top', 'ancestorOrigins' ]);

let failures = 0;
function fail(msg) { failures++; console.log(`FAIL: ${msg}`); }
function pass(msg) { console.log(`PASS: ${msg}`); }
function expect(cond, ok, bad) { if ( cond ) { pass(ok); } else { fail(bad ?? ok); } }
function read(rel) { return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }

console.log('=== SCP fingerprint scriptlet = the Inspector\'s LOW tier only ===');

const tiers = readRuleInfoTiers(ROOT);
if ( tiers === null ) {
    fail('could not locate RULE_INFO in scriptlet-rule-labels.js (the table moved -- update tools/_rule-info-tiers.mjs)');
} else {
    const scpSrc = read(SCP);
    const covers = readCovers(scpSrc);
    const missing = [ ...tiers.low ].filter(a => covers.has(a) === false);
    const extra = [ ...covers ].filter(a => tiers.low.has(a) === false);
    expect(tiers.low.size > 0, `RULE_INFO yields ${tiers.low.size} Low-tier argument(s)`, 'parsed zero Low-tier arguments -- parser out of date');
    expect(missing.length === 0, 'every Low-tier argument is covered', `Low-tier signal(s) not covered: ${missing.join(', ')}`);
    expect(extra.length === 0, 'nothing beyond the Low tier is claimed', `non-Low argument(s) claimed in covers: ${extra.join(', ')}`);

    const code = stripComments(scpSrc);
    const denied = new Set([ ...tiers.tokens.medium, ...tiers.tokens.high ]);
    const leaked = tokensFoundIn(code, denied);
    expect(leaked.length === 0, 'no Medium/High signal appears in the code', `Medium/High token(s) in the code: ${leaked.join(', ')}`);

    const scpBlock = readSharedLowBlock(scpSrc);
    const medBlock = readSharedLowBlock(read(MEDIUM));
    expect(scpBlock !== null && medBlock !== null, 'both scriptlets carry the marked Low-tier block', 'the marked Low-tier block is missing from one of the scriptlets');
    expect(scpBlock !== null && scpBlock === medBlock, 'the Low-tier block is byte-identical in sec-scp-fingerprint.js and sec-medium-fingerprint.js',
        'the Low-tier block differs between sec-scp-fingerprint.js and sec-medium-fingerprint.js');

    const missingGuard = GUARD_MARKERS.filter(m => code.includes(m) === false);
    expect(missingGuard.length === 0, 'the third-party-frame guard is still there', `guard part(s) missing: ${missingGuard.join(', ')}`);
}

console.log('');
if ( failures > 0 ) {
    console.log(`${failures} SCP fingerprint tier check(s) FAILED.`);
    process.exitCode = 1;
} else {
    console.log('PASS: SCP fingerprint scriptlet matches the Low tier.');
}
