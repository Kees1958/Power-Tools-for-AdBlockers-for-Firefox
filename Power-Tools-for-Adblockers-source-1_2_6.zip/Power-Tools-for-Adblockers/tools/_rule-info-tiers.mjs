// tools/_rule-info-tiers.mjs -- shared helpers for the checks that tie a MAIN-world
// fingerprint scriptlet to the Privacy Inspector's risk tiers.
//
// js/data/scriptlet-rule-labels.js's RULE_INFO table is the single source of truth
// for which signal is Low / Medium / High risk. A MAIN-world scriptlet cannot import
// it, so each scriptlet carries `// covers: <argument>` lines and the checks compare
// them with the table parsed here (a regex parse of the table's source text: it needs
// no browser and no module import).
//
// Used by: check-advanced-protections.mjs (section E), check-scp-fingerprint-tier.mjs.
import fs from 'fs';
import path from 'path';

const LABELS_FILE = 'js/data/scriptlet-rule-labels.js';
const RULE_INFO_START = 'const RULE_INFO = [';
const RULE_INFO_END = '\n];';
// Tokens to look for in a scriptlet's CODE that mean a signal it must not touch:
// the one High entry that has no argument string to extract.
const EXTRA_HIGH_TOKENS = Object.freeze([ 'RTCPeerConnection' ]);

export function stripComments(src) {
    return src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
}

// Returns { low, medium, high: Set<argument string>, tokens: { medium, high: Set<string> } }
// or null when the table cannot be located (the table moved -- update this helper).
export function readRuleInfoTiers(root) {
    const labels = fs.readFileSync(path.join(root, LABELS_FILE), 'utf8');
    const start = labels.indexOf(RULE_INFO_START);
    const end = labels.indexOf(RULE_INFO_END, start);
    if ( start === -1 || end === -1 ) { return null; }
    const tiers = {
        low: new Set(), medium: new Set(), high: new Set(),
        tokens: { medium: new Set(), high: new Set(EXTRA_HIGH_TOKENS) },
    };
    for ( const entry of labels.slice(start, end).split(/\n\s*\{ name: '/).slice(1) ) {
        const risk = entry.match(/risk:\s*RISK_(LOW|MEDIUM|HIGH)/)?.[1]?.toLowerCase();
        const matchExpr = entry.slice(entry.indexOf('match:'), entry.indexOf('label:'));
        const strings = [ ...matchExpr.matchAll(/'([^']+)'/g) ].map(m => m[1]);
        if ( risk === undefined ) { continue; }
        for ( const s of strings ) {
            tiers[risk].add(s);
            if ( risk !== 'low' ) { tiers.tokens[risk].add(s.split('.').filter(Boolean).pop()); }
        }
    }
    return tiers;
}

// The set of `// covers: X` arguments a scriptlet declares.
export function readCovers(src) {
    return new Set([ ...src.matchAll(/^\s*\/\/ covers: (\S+)\s*$/gm) ].map(m => m[1]));
}

// The marked Low-tier block shared verbatim between the scriptlets (null if absent).
export function readSharedLowBlock(src) {
    const begin = src.indexOf('    // >>> LOW-TIER MITIGATIONS');
    const endMarker = '    // <<< END LOW-TIER MITIGATIONS';
    const end = src.indexOf(endMarker);
    if ( begin === -1 || end === -1 || end < begin ) { return null; }
    return src.slice(begin, end + endMarker.length);
}

// Tokens from `set` that appear as whole words in `code` (comments already stripped).
export function tokensFoundIn(code, tokens) {
    return [ ...tokens ].filter(t => t && new RegExp(`\\b${t}\\b`).test(code));
}
