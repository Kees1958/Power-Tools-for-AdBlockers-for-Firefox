// Behavioral proof for v9.4.9 porting item 8 (bulk rule-import doing a
// full read-modify-write per item — cosmetic-filter import specifically,
// including the "second, nested single-item call inside the helper" gap
// the porting guide warns is easy to miss). Exercises the real exported
// functions from filter-manager.js:
//   - importCosmeticFiltersBulk() must produce an IDENTICAL end state
//     (which selectors land under which hostname) to calling
//     addCustomFilters() sequentially per hostname, for the same input.
//     Deliberately does NOT compare the cosmeticRuleDates map here —
//     addCustomFilters() alone has no createdAt concept at all (that
//     correction only ever lived in the now-removed
//     importCosmeticFilters() wrapper), so a fair sequential baseline
//     for THIS comparison can only be the add/dedup/cap mechanics.
//     createdAt preservation for importCosmeticFiltersBulk() is already
//     covered by tools/test-core-modules-dry-run.mjs's own dedicated
//     check.
//   - importCosmeticFiltersBulk() must do meaningfully fewer
//     storage.local.get/set calls than N sequential addCustomFilters()
//     calls — this is the count that would have caught the nested-write
//     gap: addCustomFilters() alone (the old per-hostname path)
//     independently re-reads the full corpus for its cap check AND
//     triggers a full index rebuild on EVERY call via writeToStorage().
//
// Same lesson as e2e_site_mode_bulk.mjs: keep ONE mock object reference
// for the whole process — js/data/ext.js captures browser/chrome once at
// first import, so swapping in a SECOND mock object mid-process silently
// doesn't take effect. This test resets one mock's internal store
// between scenarios instead of ever reassigning global.browser.
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');

console.log('=== e2e: filter-manager.js importCosmeticFiltersBulk() vs sequential addCustomFilters() ===\n');

let failures = 0;
function check(name, cond) {
    if ( cond ) { console.log(`  PASS: ${name}`); }
    else { failures++; console.log(`  FAIL: ${name}`); }
}

// ── One mock, resettable — same browser/chrome object reference for the
//    entire process (see header comment for why this matters).
const store = {};
let localGetCalls = 0;
let localSetCalls = 0;
function resetStore() {
    for ( const k of Object.keys(store) ) { delete store[k]; }
    localGetCalls = 0;
    localSetCalls = 0;
}
// Seeds M pre-existing site.* hostnames unrelated to the batch under
// test, so the corpus-scan cost (getAllCustomFilters() reads every
// site.* key via Promise.all — see filter-manager.js) is nonzero and
// the exact invariant below is actually testable: bulk's read count
// must be M+1 (M corpus entries + 1 dates-map read) REGARDLESS of how
// many hostnames are in the batch (N), while sequential's must grow
// with N. Bypasses the real write path (direct store mutation) since
// this is fixture setup, not part of what's under test.
const EXISTING_CORPUS_SIZE = 5;
function seedExistingCorpus() {
    for ( let i = 0; i < EXISTING_CORPUS_SIZE; i++ ) {
        store[`site.pre-existing-${i}.example`] = [ `.pre-existing-selector-${i}` ];
    }
}
global.browser = {
    storage: {
        local: {
            get: (key) => {
                localGetCalls++;
                if ( key === null || key === undefined ) { return Promise.resolve({ ...store }); }
                if ( typeof key === 'string' ) { return Promise.resolve({ [key]: store[key] }); }
                const out = {};
                for ( const k of Object.keys(key) ) { out[k] = store[k] ?? key[k]; }
                return Promise.resolve(out);
            },
            getKeys: () => Promise.resolve(Object.keys(store)),
            set: (obj) => { localSetCalls++; Object.assign(store, obj); return Promise.resolve(); },
            remove: (keys) => { for ( const k of [].concat(keys) ) { delete store[k]; } return Promise.resolve(); },
        },
    },
    runtime: { getURL: p => `chrome-extension://test/${p}`, id: 'test' },
};
global.chrome = global.browser;
global.self = global;

function snapshotRelevantState() {
    // Only site.* entries — which selectors actually landed under which
    // hostname. NOT the dates map: addCustomFilters() alone (used as the
    // "naive sequential" reference below) has no createdAt concept at
    // all — that correction only ever lived in the now-removed
    // importCosmeticFilters() wrapper, and createdAt-preservation is
    // already covered by test-core-modules-dry-run.mjs's own dedicated
    // check for importCosmeticFiltersBulk(). This test's job is the
    // add/dedup/cap MECHANICS: does batching change which selectors end
    // up landing, not what date they're stamped with.
    const siteKeys = Object.keys(store).filter(k => k.startsWith('site.')).sort();
    const sites = {};
    for ( const k of siteKeys ) { sites[k] = [ ...store[k] ].sort(); }
    return { sites };
}

const testInput = new Map([
    [ 'alpha.example', [ { selector: '.a1', createdAt: '2020-01-01' }, { selector: '.a2', createdAt: undefined } ] ],
    [ 'beta.example',  [ { selector: '.b1', createdAt: '2021-06-15' } ] ],
    [ 'gamma.example', [ { selector: '.g1', createdAt: undefined }, { selector: '.g2', createdAt: undefined } ] ],
]);

// ── Scenario A: sequential addCustomFilters() calls, one per hostname —
//    mirrors exactly what the old, now-removed importCosmeticFilters()
//    did internally, once per hostname in the outer handler's loop.
resetStore();
seedExistingCorpus();
{
    const modUrl = `file://${path.join(ROOT, 'js/core/filter-manager.js')}?t=${Date.now()}-seq`;
    const { addCustomFilters } = await import(modUrl);
    for ( const [ hostname, entries ] of testInput ) {
        await addCustomFilters(hostname, entries.map(e => e.selector));
    }
}
const sequentialState = snapshotRelevantState();
const sequentialCounts = { localGetCalls, localSetCalls };

// ── Scenario B: one importCosmeticFiltersBulk() call for the same input.
resetStore();
seedExistingCorpus();
{
    const modUrl = `file://${path.join(ROOT, 'js/core/filter-manager.js')}?t=${Date.now()}-bulk`;
    const { importCosmeticFiltersBulk } = await import(modUrl);
    await importCosmeticFiltersBulk(testInput);
}
const bulkState = snapshotRelevantState();
const bulkCounts = { localGetCalls, localSetCalls };

console.log(`    sequential storage.local calls: ${JSON.stringify(sequentialCounts)}`);
console.log(`    bulk storage.local calls:       ${JSON.stringify(bulkCounts)}`);
console.log(`    sequential state: ${JSON.stringify(sequentialState)}`);
console.log(`    bulk state:       ${JSON.stringify(bulkState)}`);

// The actual equivalence check the porting guide recommends.
check(
    'importCosmeticFiltersBulk() produces an IDENTICAL end state (which selectors land under which hostname) to sequential addCustomFilters() calls for the same input',
    JSON.stringify(sequentialState) === JSON.stringify(bulkState)
);

check(
    'sequential calls (3 hostnames) issued more storage.local.get calls than the bulk call — each addCustomFilters() call independently re-reads the full corpus for its cap check',
    sequentialCounts.localGetCalls > bulkCounts.localGetCalls
);
check(
    'bulk call did meaningfully fewer storage.local.set calls than the 3 independent sequential calls (no per-hostname re-write of the shared dates map)',
    bulkCounts.localSetCalls < sequentialCounts.localSetCalls
);

// Exact invariant, not just "fewer than sequential" — matches the
// rigor of uBS's own equivalent check for this item (their write-up:
// "exactly 2 full-corpus reads for a 4-hostname batch"). Our corpus
// read shape differs (getAllCustomFilters() does one Promise.all of
// per-key reads, not one bulk read — see this test's header), so the
// exact NUMBER isn't portable, but the underlying claim is testable
// precisely: bulk does ONE cap-check corpus scan (M reads, M = existing
// corpus size) + ONE dates read (1) + ONE post-write index rebuild
// (M+N reads, since writeManyToStorage()'s refreshCustomFilterIndex()
// necessarily re-scans the corpus AFTER writing, which now includes the
// N newly-touched hostnames — an unavoidable, correct "+N", not a bug)
// = 2M+N+1 total, growing by exactly 1 read per hostname in the batch.
// Sequential grows far more steeply: each of its N calls independently
// re-scans the GROWING corpus twice (once for its own cap check, once
// for its own post-write index rebuild), so its total is quadratic in N
// (verified below against the same closed-form sum), not linear.
const M = EXISTING_CORPUS_SIZE;
const N = testInput.size;
const expectedBulkReads = 2 * M + N + 1;
let expectedSequentialReads = 0;
for ( let i = 0; i < N; i++ ) { expectedSequentialReads += 2 * M + 2 * i + 3; }
check(
    `bulk call's read count is exactly 2*M+N+1 (${expectedBulkReads}) — grows by 1 per hostname, not by a full corpus rescan per hostname`,
    bulkCounts.localGetCalls === expectedBulkReads
);
check(
    `sequential calls' read count matches the closed-form quadratic-in-N sum (${expectedSequentialReads}) — confirms the ${sequentialCounts.localGetCalls / bulkCounts.localGetCalls}x-plus gap is structural, not incidental`,
    sequentialCounts.localGetCalls === expectedSequentialReads
);

console.log(`\n${failures === 0 ? 'PASS' : 'FAIL'}: e2e cosmetic-import bulk check (${failures} failure(s))`);
process.exit(failures === 0 ? 0 : 1);
