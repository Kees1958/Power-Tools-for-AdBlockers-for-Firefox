// tools/e2e_scp_fingerprint_scriptlet.mjs -- executes the REAL
// js/security/sec-scp-fingerprint.js in JSDOM (1.2.6). The Privacy & Security row it
// serves says "Enforce LOW-RISK fingerprinting protections in THIRD-PARTY frames
// outside safe regions", so this asserts exactly that, in both directions:
//   - it applies the Privacy Inspector's LOW-tier mitigations (IdleDetector,
//     NDEFReader, plugins/mimeTypes, getBattery, window.name) in a third-party frame;
//   - it does NOT touch anything Medium or High: 2D canvas, WebGL, permissions.query,
//     Web Audio, visibilitychange listeners, WebRTC, timezone (until 1.2.5 it did --
//     that was the "error" this release fixes);
//   - it does nothing at all in the top-level page or a same-origin frame;
//   - one already-locked-down property never stops the others.
import fs from 'fs';
import path from 'path';
import { JSDOM } from 'jsdom';
import { HOST_HTML, installFakeApis, makeFrame } from './_jsdom-fingerprint-harness.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const SCRIPTLET = 'js/security/sec-scp-fingerprint.js';
const OTHER_ORIGIN = 'https://third-party.example';

let failures = 0;
function check(name, cond, detail = '') {
    if ( cond ) { console.log(`  PASS: ${name}`); }
    else { failures++; console.log(`  FAIL: ${name}${detail ? ` -- ${detail}` : ''}`); }
}
const code = fs.readFileSync(path.join(ROOT, SCRIPTLET), 'utf8');

// A frame that reports a DIFFERENT top origin, i.e. a genuine third-party frame.
function makeThirdPartyFrame() {
    const made = makeFrame();
    Object.defineProperty(made.frame.location, 'ancestorOrigins', { configurable: true, value: [ OTHER_ORIGIN ] });
    return made;
}

console.log('=== e2e: sec-scp-fingerprint.js (LOW tier only, third-party frames) executed in JSDOM ===\n');

console.log('Third-party frame: LOW-tier mitigations apply');
{
    const { dom, frame } = makeThirdPartyFrame();
    frame.eval(code);
    check('IdleDetector reads as absent', frame.IdleDetector === undefined);
    check('NDEFReader reads as absent', frame.NDEFReader === undefined);
    check('navigator.plugins is empty', frame.navigator.plugins.length === 0);
    check('navigator.mimeTypes is empty', frame.navigator.mimeTypes.length === 0);
    let rejected = false;
    try { await frame.navigator.getBattery(); } catch { rejected = true; }
    check('navigator.getBattery rejects', rejected);
    check("window.name reads as ''", frame.name === '');
    frame.name = 'attempted-identifier';
    check('window.name ignores writes', frame.name === '');
    dom.window.close();
}

console.log('\nThird-party frame: NOTHING Medium or High is touched (the 1.2.6 fix)');
{
    const { dom, frame } = makeThirdPartyFrame();
    const before = {
        resolvedOptions: frame.Intl.DateTimeFormat.prototype.resolvedOptions,
        addEventListener: frame.EventTarget.prototype.addEventListener,
        query: frame.Permissions.prototype.query,
        audio: frame.AudioContext,
        offline: frame.OfflineAudioContext,
        getContext: frame.HTMLCanvasElement.prototype.getContext,
        rtc: frame.RTCPeerConnection,
    };
    frame.eval(code);
    const canvas = frame.document.createElement('canvas');
    check("canvas.getContext('2d') is UNTOUCHED (Medium tier)", canvas.getContext('2d')?.real === '2d');
    check("canvas.getContext('webgl') is UNTOUCHED (High tier)", canvas.getContext('webgl')?.real === 'webgl');
    check('canvas prototype getContext is the very same function', frame.HTMLCanvasElement.prototype.getContext === before.getContext);
    let queryWorks = false;
    try { queryWorks = (await new frame.Permissions().query({ name: 'geolocation' })).state === 'granted'; } catch { queryWorks = false; }
    check('permissions.query still works (Medium tier)', queryWorks && frame.Permissions.prototype.query === before.query);
    check('AudioContext is the real one (Medium tier)', frame.AudioContext === before.audio && new frame.AudioContext().real === true);
    check('OfflineAudioContext is the real one (Medium tier)', frame.OfflineAudioContext === before.offline);
    let visibilityCalls = 0;
    frame.document.addEventListener('visibilitychange', () => { visibilityCalls++; });
    frame.document.dispatchEvent(new frame.Event('visibilitychange'));
    check('visibilitychange listeners still work (Medium tier)', visibilityCalls === 1 && frame.EventTarget.prototype.addEventListener === before.addEventListener);
    check('RTCPeerConnection is the real one (High tier)', frame.RTCPeerConnection === before.rtc && new frame.RTCPeerConnection().real === true);
    check('timezone API (Intl resolvedOptions) is untouched (High tier)', frame.Intl.DateTimeFormat.prototype.resolvedOptions === before.resolvedOptions);
    dom.window.close();
}

console.log('\nScope: only THIRD-PARTY frames');
{
    const dom = new JSDOM(HOST_HTML, { runScripts: 'outside-only' });
    installFakeApis(dom.window);
    dom.window.eval(code);
    check('top-level page: IdleDetector still present', typeof dom.window.IdleDetector === 'function');
    check('top-level page: plugins still real', dom.window.navigator.plugins[0] === 'real-plugin');
    dom.window.close();
}
{
    const { dom, frame } = makeFrame();
    Object.defineProperty(frame.location, 'ancestorOrigins', { configurable: true, value: [ frame.location.origin ] });
    frame.eval(code);
    check('same-origin frame: IdleDetector still present', typeof frame.IdleDetector === 'function');
    check('same-origin frame: plugins still real', frame.navigator.plugins[0] === 'real-plugin');
    dom.window.close();
}
{
    const { dom, frame } = makeFrame();    // JSDOM has no location.ancestorOrigins at all
    frame.eval(code);
    check('ancestorOrigins unsupported: FAILS CLOSED (applies to the frame)', frame.IdleDetector === undefined && frame.navigator.plugins.length === 0);
    dom.window.close();
}

console.log('\nResilience: one locked-down property must not stop the others');
{
    const { dom, frame } = makeThirdPartyFrame();
    Object.defineProperty(Object.getPrototypeOf(frame.navigator), 'plugins',
        { configurable: false, get() { return [ 'locked' ]; } });
    let threw = false;
    try { frame.eval(code); } catch { threw = true; }
    check('scriptlet does not throw', threw === false);
    check('the locked property is left as it was', frame.navigator.plugins[0] === 'locked');
    check('other Low mitigations still applied (IdleDetector, window.name)', frame.IdleDetector === undefined && frame.name === '');
    dom.window.close();
}

console.log('');
if ( failures > 0 ) {
    console.log(`FAIL: e2e scp fingerprint scriptlet (${failures} failure(s))`);
    process.exitCode = 1;
} else {
    console.log('PASS: e2e scp fingerprint scriptlet (0 failure(s))');
}
