// tools/_jsdom-fingerprint-harness.mjs -- shared JSDOM harness for the fingerprint
// scriptlet tests (e2e_medium_fingerprint_scriptlet.mjs, e2e_scp_fingerprint_scriptlet.mjs).
//
// JSDOM lacks the real-browser APIs the mitigations replace, so installFakeApis()
// gives a window fake ones. EVERY fake reports "the real thing" (a `.real` marker or a
// distinctive value), so a test can tell whether a scriptlet changed it.
import { JSDOM } from 'jsdom';

export const HOST_HTML = '<!doctype html><html><body><iframe id="f"></iframe></body></html>';

// Gives a window the real-browser APIs JSDOM lacks, so the mitigations have
// something to replace. Every fake reports "the real thing" so a test can
// tell whether the scriptlet changed it.
export function installFakeApis(w) {
    w.HTMLCanvasElement.prototype.getContext = function(type) { return { real: type }; };
    class FakePermissions { query() { return Promise.resolve({ state: 'granted' }); } }
    w.Permissions = FakePermissions;
    w.AudioContext = function RealAudioContext() { this.real = true; };
    w.OfflineAudioContext = function RealOfflineAudioContext() { this.real = true; };
    w.IdleDetector = class RealIdleDetector {};
    w.NDEFReader = class RealNDEFReader {};
    w.RTCPeerConnection = function RealRTC() { this.real = true; };
    const navProto = Object.getPrototypeOf(w.navigator);
    navProto.getBattery = function() { return Promise.resolve({ real: true }); };
    Object.defineProperty(navProto, 'plugins', { configurable: true, get() { return [ 'real-plugin' ]; } });
    Object.defineProperty(navProto, 'mimeTypes', { configurable: true, get() { return [ 'real-mime' ]; } });
}

export function makeFrame() {
    const dom = new JSDOM(HOST_HTML, { runScripts: 'outside-only' });
    const frame = dom.window.document.getElementById('f').contentWindow;
    installFakeApis(frame);
    return { dom, frame };
}
