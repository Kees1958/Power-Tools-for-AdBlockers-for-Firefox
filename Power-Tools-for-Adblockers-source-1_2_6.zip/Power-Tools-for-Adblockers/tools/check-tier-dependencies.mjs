// tools/check-tier-dependencies.mjs — enforces ARCHITECTURE.md's five-tier
// dependency rule mechanically. Until this check existed the rule was
// prose only: the circular-dependency check (madge) catches cycles, but
// a downward-only rule can be broken without any cycle at all (a `util/`
// file importing from `data/` creates no loop and nothing flagged it).
//
//   ui/       →  workflow/, core/, util/, data/
//   workflow/ →  core/, data/, util/
//   core/     →  util/, data/
//   util/     →  (nothing inside the extension)
//   data/     →  (nothing inside the extension)
//
// Scope: every .js/.mjs file directly under js/{ui,workflow,core,util,data}/.
// js/scripting/ and js/security/ are separate execution contexts (see
// ARCHITECTURE.md) and are not scanned as SOURCES — but a tier file
// importing FROM them is still a violation, because scripting-manager
// is documented as only knowing their paths, never importing their code.
//
// HARD FAILURE on:
//   1. any import that breaks the rule and is not in KNOWN_EXCEPTIONS;
//   2. any KNOWN_EXCEPTIONS entry that no longer matches a real import
//      (a stale exception is a silent hole — when a debt is fixed, its
//      entry must be deleted in the same change, not left to rot);
//   3. a scan that found no files at all (a wrong ROOT/path would
//      otherwise read as a clean pass).
//
// Proven by deliberately breaking it — see CHANGELOG entry for tools 1.1.12.
import fs from 'fs';
import path from 'path';

/******************************************************************************/
// CONFIGURATION — every rule, path and exception is declared here, once.
/******************************************************************************/

const ROOT = path.resolve(import.meta.dirname, '..');
const JS_DIR = 'js';

// Source-file extensions scanned inside each tier folder.
const SOURCE_FILE_PATTERN = /\.m?js$/;

// Which tiers each tier may import from. A tier may always import from
// itself (same folder). Matches ARCHITECTURE.md's diagram exactly.
const ALLOWED_TARGET_TIERS = Object.freeze({
    ui:       [ 'ui', 'workflow', 'core', 'util', 'data' ],
    workflow: [ 'workflow', 'core', 'data', 'util' ],
    core:     [ 'core', 'util', 'data' ],
    util:     [ 'util' ],
    data:     [ 'data' ],
});

// Import targets outside the five tiers that are legitimately reachable
// from tier files. Vendored libraries and build-generated modules are not
// tiers and never import back into the extension.
const ALLOWED_EXTERNAL_TARGET_PREFIXES = Object.freeze([
    'lib/',
    'js/generated/',
]);

// Known, documented exceptions: "<source> -> <target>" (repo-relative,
// forward slashes). Each carries the reason it exists. Anything not
// listed here fails the check. (Two known-debt entries -- data/ext-compat.js
// -> util/deep-compare.js and util/panel-window.js -> data/ext.js -- were
// fixed in 1.1.1 by relocating those modules, and their entries deleted, as
// this check's stale-entry rule requires.)
const KNOWN_EXCEPTIONS = Object.freeze({
    // Documented exception (see the header of that file): the filter
    // compiler predates its move into core/ and reuses the UI-side
    // parsers rather than duplicating them.
    'js/core/filter-compiler/compile-filters.js -> js/ui/static-filtering-parser.js':
        'documented parser reuse (compile-filters.js header)',
    'js/core/filter-compiler/compile-filters.js -> js/ui/ubo-parser.js':
        'documented parser reuse (compile-filters.js header)',
});

/******************************************************************************/
// IMPLEMENTATION
/******************************************************************************/

function toPosix(p) { return p.split(path.sep).join('/'); }

// Removes block comments and whole-line // comments so prose that merely
// mentions "import ... from" cannot produce a phantom dependency.
function stripComments(src) {
    return src
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/^\s*\/\/.*$/gm, '');
}

// Static imports, re-exports, side-effect imports and dynamic import().
const IMPORT_PATTERN =
    /\b(?:import|export)\b[^'";]*?\bfrom\s*['"]([^'"]+)['"]|\bimport\s*['"]([^'"]+)['"]|\bimport\(\s*['"]([^'"]+)['"]\s*\)/g;

function collectSourceFiles(dirAbs) {
    const found = [];
    for ( const entry of fs.readdirSync(dirAbs, { withFileTypes: true }) ) {
        const abs = path.join(dirAbs, entry.name);
        if ( entry.isDirectory() ) { found.push(...collectSourceFiles(abs)); }
        else if ( SOURCE_FILE_PATTERN.test(entry.name) ) { found.push(abs); }
    }
    return found;
}

// 'js/core/x.js' -> 'core'; anything not directly under a known tier -> null.
function tierOf(repoRelPosix) {
    const parts = repoRelPosix.split('/');
    if ( parts[0] !== JS_DIR ) { return null; }
    return Object.hasOwn(ALLOWED_TARGET_TIERS, parts[1]) ? parts[1] : null;
}

function scan() {
    const jsAbs = path.join(ROOT, JS_DIR);
    if ( !fs.existsSync(jsAbs) ) { throw new Error(`${JS_DIR}/ not found under ${ROOT}`); }

    const violations = [];
    const seenExceptions = new Set();
    let filesScanned = 0;
    let importsChecked = 0;

    for ( const tier of Object.keys(ALLOWED_TARGET_TIERS) ) {
        const tierAbs = path.join(jsAbs, tier);
        if ( !fs.existsSync(tierAbs) ) { continue; }
        for ( const fileAbs of collectSourceFiles(tierAbs) ) {
            filesScanned += 1;
            const fileRel = toPosix(path.relative(ROOT, fileAbs));
            const src = stripComments(fs.readFileSync(fileAbs, 'utf8'));
            for ( const m of src.matchAll(IMPORT_PATTERN) ) {
                const spec = m[1] ?? m[2] ?? m[3];
                if ( typeof spec !== 'string' || !spec.startsWith('.') ) { continue; }
                importsChecked += 1;
                const targetRel = toPosix(path.relative(ROOT, path.resolve(path.dirname(fileAbs), spec)));
                const targetTier = tierOf(targetRel);
                const pair = `${fileRel} -> ${targetRel}`;

                let bad = null;
                if ( targetTier === null ) {
                    if ( !ALLOWED_EXTERNAL_TARGET_PREFIXES.some(p => targetRel.startsWith(p)) ) {
                        bad = `outside the five tiers (${tier} -> ${targetRel.split('/').slice(0, 2).join('/')})`;
                    }
                } else if ( !ALLOWED_TARGET_TIERS[tier].includes(targetTier) ) {
                    bad = `${tier}/ may not import from ${targetTier}/`;
                }
                if ( bad === null ) { continue; }

                if ( Object.hasOwn(KNOWN_EXCEPTIONS, pair) ) { seenExceptions.add(pair); continue; }
                violations.push({ pair, reason: bad });
            }
        }
    }

    const staleExceptions = Object.keys(KNOWN_EXCEPTIONS).filter(k => !seenExceptions.has(k));
    return { violations, staleExceptions, filesScanned, importsChecked };
}

console.log('=== Tier-dependency check (ARCHITECTURE.md five-tier model) ===');

let failed = false;
try {
    const { violations, staleExceptions, filesScanned, importsChecked } = scan();

    if ( filesScanned === 0 ) {
        console.log('FAIL: scanned 0 files — the check would pass vacuously. Wrong ROOT or folder layout?');
        failed = true;
    }
    console.log(`Scanned ${filesScanned} file(s), ${importsChecked} relative import(s).`);

    for ( const v of violations ) {
        console.log(`FAIL: ${v.pair}  [${v.reason}]`);
        failed = true;
    }
    for ( const k of staleExceptions ) {
        console.log(`FAIL: stale KNOWN_EXCEPTIONS entry (import no longer exists — delete it): ${k}`);
        failed = true;
    }
    if ( !failed ) {
        console.log(`PASS: no unlisted tier violations (${Object.keys(KNOWN_EXCEPTIONS).length} known exception(s) still accurate).`);
    }
} catch (err) {
    console.log(`FAIL: tier check could not run: ${err.message}`);
    failed = true;
}

process.exitCode = failed ? 1 : 0;
