// tools/e2e_advanced_protections.mjs -- behavioral proof for the 1.2.0
// "advanced" (Medium website breakage risk) Worry-free protections.
//
// Runs the REAL, exported updateSecurityRules() (ruleset-manager.js),
// setFamiliarTlds() (worry-free-familiar-tld-manager.js) and
// setSaferegionsDomains() (saferegions-manager.js) against an in-memory DNR
// that reproduces the two real-API failure modes that matter here:
//   - an updateDynamicRules() call containing a DUPLICATE id fails as a whole
//     (so a band that is not swept before being re-added would break rules);
//   - a rule naming a resource type the browser's own enum lacks fails as a
//     whole (so hard-coding a type list would be a latent whole-call failure).
// "It didn't throw" is not the proof -- each scenario asserts the resulting
// dynamic-rule table.
import path from 'path';
import {
    MOCK_RESOURCE_TYPES, dynamicRules, sessionRules, registeredScripts,
} from './_mock-browser-env.mjs';

/******************************************************************************/
// CONFIGURATION -- declared once
/******************************************************************************/

const ROOT = path.resolve(import.meta.dirname, '..');
const TEST_TLDS = 'nl, be, uk';
const TEST_SAFEREGION_DOMAINS = [ 'example.org' ];


/******************************************************************************/
// Harness
/******************************************************************************/

let failures = 0;
function check(name, cond, detail = '') {
    if ( cond ) { console.log(`  PASS: ${name}`); }
    else { failures++; console.log(`  FAIL: ${name}${detail ? ` -- ${detail}` : ''}`); }
}

function modUrl(rel) { return `file://${path.join(ROOT, rel)}`; }
const cfgMod = await import(modUrl('js/data/config.js'));
const budgets = await import(modUrl('js/core/dnr-budgets.js'));
const adv = await import(modUrl('js/core/worry-free-advanced.js'));
const { updateSecurityRules } = await import(modUrl('js/core/ruleset-manager.js'));
const { handleSetSecurityConfig, handleGetSecurityConfig } = await import(modUrl('js/workflow/security-routes.js'));
const { startAutoDeny, cancelAutoDeny, getAutoDenyState } = await import(modUrl('js/core/cookie-clicker-autodeny-manager.js'));
const tiers = await import(modUrl('js/core/worry-free-tiers.js'));
const { setFamiliarTlds } = await import(modUrl('js/core/worry-free-familiar-tld-manager.js'));
const { setSaferegionsDomains } = await import(modUrl('js/core/saferegions-manager.js'));
const { securityConfig } = cfgMod;

const ids = {
    download: budgets.ADVANCED_FIRST_PARTY_DOWNLOAD_BLOCK_RULE_ID,
    sandbox: budgets.ADVANCED_SANDBOX_SAFE_SCRIPTS_RULE_ID,
    thirdParty: budgets.ADVANCED_THIRD_PARTY_BLOCK_RULE_ID,
};
function advancedPresent() { return [ ids.download, ids.sandbox, ids.thirdParty ].filter(id => dynamicRules.has(id)); }
function inBand(base, end) { return [ ...dynamicRules.keys() ].filter(id => id >= base && id < end); }

// Drives the REAL Worry-free session (start/cancel keep the stored state and the
// manager's in-memory cache consistent -- writing storage by hand would not).
async function setSession(active) {
    const current = (await getAutoDenyState()).active === true;
    if ( active && current === false ) { await startAutoDeny(null); }
    else if ( active === false && current ) { await cancelAutoDeny(); }
}

async function setState({ worryFree, advanced, items = {} }) {
    await setSession(worryFree);
    securityConfig.worryFreeSecurityProtectionsEnabled = true;
    securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
    securityConfig[adv.ADVANCED_SETTING_KEY] = advanced;
    for ( const key of Object.values(adv.ADVANCED_ITEM_KEYS) ) { securityConfig[key] = items[key] ?? true; }
    await updateSecurityRules();
}

console.log('=== e2e: advanced (Medium-risk) Worry-free protections ===\n');

/******************************************************************************/
console.log('Defaults');
{
    const pristine = await import(`${modUrl('js/data/config.js')}?fresh=${Date.now()}`);
    check("'advanced' switch defaults OFF", pristine.securityConfig[adv.ADVANCED_SETTING_KEY] === false);
    check('all four rows default ON (opt-out semantics)',
        Object.values(adv.ADVANCED_ITEM_KEYS).every(k => pristine.securityConfig[k] === true));
}

/******************************************************************************/
console.log('\nGating of the three DNR slots');
await setState({ worryFree: false, advanced: true });
check('Worry-free NOT active -> no advanced rules, even with the switch on', advancedPresent().length === 0);

await setState({ worryFree: true, advanced: false });
check("Worry-free active but 'advanced' OFF -> no advanced rules", advancedPresent().length === 0);

await setState({ worryFree: true, advanced: true });
check("Worry-free active + 'advanced' ON -> all three rules present", advancedPresent().length === 3);

const dl = dynamicRules.get(ids.download);
const sb = dynamicRules.get(ids.sandbox);
const tp = dynamicRules.get(ids.thirdParty);

console.log('\nRule shapes');
check('item 1 is a CSP append header rule on main_frame + sub_frame, not third-party-restricted',
    dl?.action.type === 'modifyHeaders' &&
    dl.action.responseHeaders[0].header === 'Content-Security-Policy' &&
    dl.action.responseHeaders[0].operation === 'append' &&
    JSON.stringify(dl.condition.resourceTypes) === JSON.stringify([ 'main_frame', 'sub_frame' ]) &&
    dl.condition.domainType === undefined);
check('item 1 sandbox value omits allow-downloads',
    dl?.action.responseHeaders[0].value.startsWith('sandbox ') &&
    dl.action.responseHeaders[0].value.split(/\s+/).includes('allow-downloads') === false);
check('item 1 sandbox value ALSO omits allow-popups-to-escape-sandbox (a popup inherits the no-downloads sandbox) but keeps allow-popups',
    dl?.action.responseHeaders[0].value.split(/\s+/).includes(adv.ADVANCED_ESCAPE_POPUPS_FLAG) === false &&
    dl.action.responseHeaders[0].value.split(/\s+/).includes('allow-popups'));
check('item 2 is a CSP append header rule on main_frame + sub_frame',
    sb?.action.type === 'modifyHeaders' &&
    sb.action.responseHeaders[0].header === 'Content-Security-Policy' &&
    JSON.stringify(sb.condition.resourceTypes) === JSON.stringify([ 'main_frame', 'sub_frame' ]));
{
    const value = sb?.action.responseHeaders[0].value ?? '';
    const [ sandboxPart, scriptPart ] = value.split(';').map(v => v.trim());
    check('item 2 keeps scripts, same-origin, forms and downloads allowed',
        [ 'allow-scripts', 'allow-same-origin', 'allow-forms', 'allow-downloads' ].every(f => sandboxPart.split(/\s+/).includes(f)));
    check('item 2 drops top-navigation, popup-escape and modals',
        sandboxPart.split(/\s+/).every(f => !f.startsWith('allow-top-navigation') && f !== 'allow-popups-to-escape-sandbox' && f !== 'allow-modals'));
    check("item 2 script-src forbids eval ('unsafe-eval' absent) but keeps inline + WebAssembly",
        scriptPart.startsWith('script-src') && !scriptPart.includes("'unsafe-eval'") &&
        scriptPart.includes("'unsafe-inline'") && scriptPart.includes("'wasm-unsafe-eval'"));
}
check('item 3 is a third-party BLOCK rule',
    tp?.action.type === 'block' && tp.condition.domainType === 'thirdParty');
check('item 3 blocks stylesheets and fonts (and scripts, xhr, websocket, other)',
    [ 'stylesheet', 'font', 'script', 'xmlhttprequest', 'websocket', 'other' ].every(t => tp?.condition.resourceTypes.includes(t)));
check('item 3 spares HTML documents, images and media',
    [ 'main_frame', 'sub_frame', 'image', 'media' ].every(t => !tp?.condition.resourceTypes.includes(t)));
check('item 3 covers exactly the enum minus the four exempt types',
    JSON.stringify([ ...tp.condition.resourceTypes ].sort()) ===
    JSON.stringify(Object.values(MOCK_RESOURCE_TYPES).filter(t => ![ 'main_frame', 'sub_frame', 'image', 'media' ].includes(t)).sort()));
check('header rules sit at the SCP tier, strictly below the SCP allow priority (so the SCP band exempts them)',
    dl.priority === budgets.WORRY_FREE_SCP_BLOCK_PRIORITY && dl.priority < budgets.WORRY_FREE_SCP_TLD_ALLOW_PRIORITY);

console.log('\nPer-row opt-out (worryFreeGatedOptOut)');
await setState({ worryFree: true, advanced: true, items: { [adv.ADVANCED_ITEM_KEYS.THIRD_PARTY_BLOCK]: false } });
check('unchecking the third-party row removes only that rule',
    dynamicRules.has(ids.thirdParty) === false && dynamicRules.has(ids.download) && dynamicRules.has(ids.sandbox));
await setState({ worryFree: true, advanced: true, items: { [adv.ADVANCED_ITEM_KEYS.FIRST_PARTY_DOWNLOADS]: false } });
check('unchecking the download row removes only that rule',
    dynamicRules.has(ids.download) === false && dynamicRules.has(ids.sandbox) && dynamicRules.has(ids.thirdParty));

console.log('\nTurning things off removes the rules again');
await setState({ worryFree: true, advanced: true });
check('re-enabled', advancedPresent().length === 3);
await setState({ worryFree: false, advanced: true });
check('Worry-free ends -> all three removed', advancedPresent().length === 0);

console.log('\nIdempotence (a second identical apply must not hit a duplicate id)');
let threw = false;
try { await setState({ worryFree: true, advanced: true }); await setState({ worryFree: true, advanced: true }); }
catch { threw = true; }
check('two consecutive applies succeed', threw === false && advancedPresent().length === 3);

/******************************************************************************/
console.log('\nSafe-region exemption bands');
await setFamiliarTlds(TEST_TLDS);
const tldCount = TEST_TLDS.split(',').length;
const advBand = inBand(budgets.ADVANCED_3P_TLD_ALLOW_RULES_BASE_ID, budgets.ADVANCED_3P_TLD_ALLOW_RULES_END_ID).map(id => dynamicRules.get(id));
check(`familiar-TLD manager wrote one advanced-3P exemption per TLD (${tldCount})`, advBand.length === tldCount, `got ${advBand.length}`);
check('exemption is an allow rule, thirdParty, same resource types as the block, priority above it',
    advBand.every(r => r.action.type === 'allow' && r.condition.domainType === 'thirdParty' &&
        JSON.stringify(r.condition.resourceTypes) === JSON.stringify(tp.condition.resourceTypes) &&
        r.priority === budgets.ADVANCED_3P_TLD_ALLOW_PRIORITY && r.priority > tp.priority));
check('exemption is host-anchored on the TLD', advBand.every(r => /^\|\|/.test(r.condition.urlFilter)));
check('the SCP band the header rules rely on is present too',
    inBand(budgets.WORRY_FREE_SCP_TLD_ALLOW_RULES_BASE_ID, budgets.WORRY_FREE_SCP_TLD_ALLOW_RULES_END_ID).length === tldCount);

await setFamiliarTlds(TEST_TLDS);
check('re-applying the TLD list does not duplicate or leak advanced exemptions',
    inBand(budgets.ADVANCED_3P_TLD_ALLOW_RULES_BASE_ID, budgets.ADVANCED_3P_TLD_ALLOW_RULES_END_ID).length === tldCount);

await setFamiliarTlds('nl');
check('shrinking the TLD list shrinks the advanced band (old rules swept)',
    inBand(budgets.ADVANCED_3P_TLD_ALLOW_RULES_BASE_ID, budgets.ADVANCED_3P_TLD_ALLOW_RULES_END_ID).length === 1);

await setSaferegionsDomains(TEST_SAFEREGION_DOMAINS);
const srBand = inBand(budgets.SAFEREGIONS_ADVANCED_3P_ALLOW_RULES_BASE_ID, budgets.SAFEREGIONS_RULES_END_ID).map(id => dynamicRules.get(id));
check('$saferegions wrote one advanced-3P exemption per person-added domain', srBand.length === TEST_SAFEREGION_DOMAINS.length, `got ${srBand.length}`);
check('$saferegions exemption has the same shape as the TLD one',
    srBand.every(r => r.action.type === 'allow' && r.condition.domainType === 'thirdParty' &&
        JSON.stringify(r.condition.resourceTypes) === JSON.stringify(tp.condition.resourceTypes) &&
        r.priority === budgets.ADVANCED_3P_TLD_ALLOW_PRIORITY));
await setSaferegionsDomains([]);
check('clearing $saferegions sweeps its advanced band',
    inBand(budgets.SAFEREGIONS_ADVANCED_3P_ALLOW_RULES_BASE_ID, budgets.SAFEREGIONS_RULES_END_ID).length === 0);
check('familiar-TLD advanced band survives a $saferegions change (bands do not overlap)',
    inBand(budgets.ADVANCED_3P_TLD_ALLOW_RULES_BASE_ID, budgets.ADVANCED_3P_TLD_ALLOW_RULES_END_ID).length === 1);

/******************************************************************************/
console.log('\nThe Filter-tab checkbox as a gate, end to end (the dashboard\'s own setSecurityConfig path)');
{
    const FINGERPRINT_SCRIPT_ID = 'sec-medium-fingerprint';
    function scriptRegistered() { return registeredScripts.has(FINGERPRINT_SCRIPT_ID); }
    // Start clean: Worry-free session active, master OFF, rows at their defaults.
    await setSession(true);
    securityConfig.worryFreeSecurityProtectionsEnabled = true;
    securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
    for ( const key of Object.values(adv.ADVANCED_ITEM_KEYS) ) { securityConfig[key] = true; }
    await handleSetSecurityConfig({ key: adv.ADVANCED_SETTING_KEY, value: false });
    check("master OFF (via the route) -> no advanced DNR rules", advancedPresent().length === 0);
    check('master OFF (via the route) -> no advanced fingerprint script registered', scriptRegistered() === false);

    await handleSetSecurityConfig({ key: adv.ADVANCED_SETTING_KEY, value: true });
    check("ticking 'advanced' (via the route) turns ON all three DNR rules", advancedPresent().length === 3);
    check("ticking 'advanced' (via the route) ALSO registers the fingerprint scriptlet", scriptRegistered());
    const dir = registeredScripts.get(FINGERPRINT_SCRIPT_ID);
    check('the scriptlet directive is MAIN world, all frames, document_start',
        dir?.world === 'MAIN' && dir.allFrames === true && dir.runAt === 'document_start');
    check('the scriptlet directive points at the new file',
        JSON.stringify(dir?.js) === JSON.stringify([ '/js/security/sec-medium-fingerprint.js' ]));

    await handleSetSecurityConfig({ key: adv.ADVANCED_ITEM_KEYS.FINGERPRINT, value: false });
    check('unchecking the fingerprint ROW unregisters only the scriptlet, DNR rules stay',
        scriptRegistered() === false && advancedPresent().length === 3);
    await handleSetSecurityConfig({ key: adv.ADVANCED_ITEM_KEYS.FINGERPRINT, value: true });
    check('re-checking the row registers it again', scriptRegistered());

    await handleSetSecurityConfig({ key: adv.ADVANCED_ITEM_KEYS.THIRD_PARTY_BLOCK, value: false });
    check('unchecking a DNR ROW removes only that rule, scriptlet stays',
        dynamicRules.has(ids.thirdParty) === false && advancedPresent().length === 2 && scriptRegistered());
    await handleSetSecurityConfig({ key: adv.ADVANCED_ITEM_KEYS.THIRD_PARTY_BLOCK, value: true });

    await handleSetSecurityConfig({ key: adv.ADVANCED_SETTING_KEY, value: false });
    check("un-ticking 'advanced' removes ALL of it again: three DNR rules and the scriptlet",
        advancedPresent().length === 0 && scriptRegistered() === false);

    // Same gate, different Worry-free state: the group needs a live session too.
    await setSession(false);
    await handleSetSecurityConfig({ key: adv.ADVANCED_SETTING_KEY, value: true });
    check("'advanced' ticked but NO Worry-free session -> nothing applied (same as every other Worry-free-gated group)",
        advancedPresent().length === 0 && scriptRegistered() === false);
    await setSession(true);
    await handleSetSecurityConfig({ key: adv.ADVANCED_SETTING_KEY, value: false });
}

/******************************************************************************/
console.log('\nThree-tier hierarchy: the checkboxes (ticking up / unticking down)');
{
    const K = tiers.WORRY_FREE_TIER_SETTING_KEYS;
    const EXTRA = K[tiers.WORRY_FREE_TIER.EXTRA];
    const SAFE = K[tiers.WORRY_FREE_TIER.SAFE_REGIONS];
    const ADV = K[tiers.WORRY_FREE_TIER.ADVANCED];
    async function setBoxes(extra, safe, advanced) {
        securityConfig[EXTRA] = extra; securityConfig[SAFE] = safe; securityConfig[ADV] = advanced;
    }
    function boxes() { return [ securityConfig[EXTRA], securityConfig[SAFE], securityConfig[ADV] ]; }

    await setBoxes(false, false, false);
    let result = await handleSetSecurityConfig({ key: SAFE, value: true });
    check("ticking 'safe regions' also ticks 'extra' (advanced stays off)", JSON.stringify(boxes()) === '[true,true,false]');
    check('the route returns the resulting config so the UI can redraw all boxes', result?.[EXTRA] === true && result?.[SAFE] === true);

    await setBoxes(false, false, false);
    await handleSetSecurityConfig({ key: ADV, value: true });
    check("ticking 'advanced' also ticks 'extra' AND 'safe regions'", JSON.stringify(boxes()) === '[true,true,true]');

    await setBoxes(true, true, true);
    await handleSetSecurityConfig({ key: EXTRA, value: false });
    check("unticking 'extra' also unticks 'safe regions' and 'advanced'", JSON.stringify(boxes()) === '[false,false,false]');

    await setBoxes(true, true, true);
    await handleSetSecurityConfig({ key: SAFE, value: false });
    check("unticking 'safe regions' also unticks 'advanced' (extra stays on)", JSON.stringify(boxes()) === '[true,false,false]');

    await setBoxes(true, true, true);
    await handleSetSecurityConfig({ key: ADV, value: false });
    check("unticking 'advanced' leaves the two lower boxes alone", JSON.stringify(boxes()) === '[true,true,false]');

    await setBoxes(true, false, false);
    await handleSetSecurityConfig({ key: EXTRA, value: true });
    check('ticking an already-satisfied lower box changes nothing else', JSON.stringify(boxes()) === '[true,false,false]');

    // A stored state that breaks the hierarchy is repaired when the dashboard reads it.
    await setBoxes(false, true, true);
    const repaired = await handleGetSecurityConfig();
    check("a stored 'safe regions'/'advanced' ticked without 'extra' is repaired on read",
        repaired[EXTRA] === false && repaired[SAFE] === false && repaired[ADV] === false);
    await setBoxes(true, false, true);
    const repaired2 = await handleGetSecurityConfig();
    check("a stored 'advanced' ticked without 'safe regions' is repaired on read",
        repaired2[EXTRA] === true && repaired2[SAFE] === false && repaired2[ADV] === false);
}

/******************************************************************************/
console.log('\nThree-tier hierarchy: what is actually applied (real Worry-free session)');
{
    const K = tiers.WORRY_FREE_TIER_SETTING_KEYS;
    const EXTRA = K[tiers.WORRY_FREE_TIER.EXTRA];
    const SAFE = K[tiers.WORRY_FREE_TIER.SAFE_REGIONS];
    const ADV = K[tiers.WORRY_FREE_TIER.ADVANCED];
    const VERY_LOW_RULE = budgets.SECURITY_RULES_BASE_ID + 7;       // blockSuspicious3pLinks (Very low group)
    const LOW_RULES = [ budgets.SCP_PRIVACY_BLOCK_RULE_ID, budgets.SCP_SECURITY_BLOCK_RULE_ID ];
    const STATIC_SUPPRESSION_IDS = [
        budgets.WORRY_FREE_3PBLOCK_RULES_BASE_ID, budgets.WORRY_FREE_TLDALLOW_RULES_BASE_ID,
        budgets.WORRY_FREE_DOWNLOADBLOCK_RULES_BASE_ID, budgets.WORRY_FREE_DOWNLOAD_TLDALLOW_RULES_BASE_ID,
    ];
    // Applies an arbitrary STORED state (bypassing the checkbox cascade, as an old
    // install or a hand-edited backup could) and re-applies everything, then reports
    // which group each observable effect belongs to.
    async function observe(extra, safe, advanced) {
        securityConfig[EXTRA] = extra; securityConfig[SAFE] = safe; securityConfig[ADV] = advanced;
        for ( const key of Object.values(adv.ADVANCED_ITEM_KEYS) ) { securityConfig[key] = true; }
        securityConfig.blockScpPrivacy = securityConfig.blockScpSecurity = securityConfig.blockScpFingerprint = true;
        securityConfig.blockSuspicious3pLinks = true;
        await handleSetSecurityConfig({ key: 'blockPings', value: securityConfig.blockPings });   // any non-tier save path
        await updateSecurityRules();
        const { registerSecurityContentScripts } = await import(modUrl('js/core/scripting-manager.js'));
        const { reconcileWorryFreeExtraSuppressionRule } = await import(modUrl('js/core/worry-free-extra-manager.js'));
        await registerSecurityContentScripts();
        await reconcileWorryFreeExtraSuppressionRule(true);
        return {
            veryLow: dynamicRules.has(VERY_LOW_RULE),
            lowDnr: LOW_RULES.every(id => dynamicRules.has(id)),
            lowDnrAny: LOW_RULES.some(id => dynamicRules.has(id)),
            lowScript: registeredScripts.has('sec-scp-fingerprint'),
            // suppression rules PRESENT means the static 'safe regions' rules are switched OFF
            lowStaticLive: STATIC_SUPPRESSION_IDS.every(id => sessionRules.has(id) === false),
            mediumDnr: advancedPresent().length === 3,
            mediumDnrAny: advancedPresent().length > 0,
            mediumScript: registeredScripts.has('sec-medium-fingerprint'),
        };
    }
    await setSession(true);

    let o = await observe(true, true, true);
    check("all three ticked -> every group applies (Very low, Low incl. static rules, Medium)",
        o.veryLow && o.lowDnr && o.lowScript && o.lowStaticLive && o.mediumDnr && o.mediumScript);

    o = await observe(true, true, false);
    check("'advanced' off -> Very low + Low apply, Medium does not",
        o.veryLow && o.lowDnr && o.lowScript && o.lowStaticLive && !o.mediumDnrAny && !o.mediumScript);

    o = await observe(true, false, false);
    check("'safe regions' off -> only the Very low group applies (the Low group is gated by 'safe regions')",
        o.veryLow && !o.lowDnrAny && !o.lowScript && !o.lowStaticLive && !o.mediumDnrAny && !o.mediumScript);

    o = await observe(false, false, false);
    check("'extra' off -> nothing from any group applies",
        !o.veryLow && !o.lowDnrAny && !o.lowScript && !o.lowStaticLive && !o.mediumDnrAny && !o.mediumScript);

    // Broken stored states must be ineffective, not partially effective.
    o = await observe(false, true, true);
    check("STORED 'safe regions'+'advanced' on but 'extra' off -> NOTHING applies (Low and Medium need 'extra')",
        !o.veryLow && !o.lowDnrAny && !o.lowScript && !o.lowStaticLive && !o.mediumDnrAny && !o.mediumScript);
    o = await observe(true, false, true);
    check("STORED 'advanced' on but 'safe regions' off -> Medium does NOT apply (needs BOTH lower tiers)",
        o.veryLow && !o.lowDnrAny && !o.lowScript && !o.lowStaticLive && !o.mediumDnrAny && !o.mediumScript);
    o = await observe(false, true, false);
    check("STORED 'safe regions' on but 'extra' off -> the Low group does NOT apply",
        !o.veryLow && !o.lowDnrAny && !o.lowScript && !o.lowStaticLive);

    // Mid-session checkbox changes take effect immediately, through the real route.
    await setBoxesForSession();
    async function setBoxesForSession() {
        securityConfig[EXTRA] = true; securityConfig[SAFE] = true; securityConfig[ADV] = true;
        await handleSetSecurityConfig({ key: ADV, value: true });
    }
    check("mid-session: everything on after ticking 'advanced' (route re-applies scripts, DNR and static rules)",
        dynamicRules.has(VERY_LOW_RULE) && LOW_RULES.every(id => dynamicRules.has(id)) && advancedPresent().length === 3 &&
        registeredScripts.has('sec-scp-fingerprint') && registeredScripts.has('sec-medium-fingerprint') &&
        STATIC_SUPPRESSION_IDS.every(id => sessionRules.has(id) === false));
    await handleSetSecurityConfig({ key: SAFE, value: false });
    check("mid-session: unticking 'safe regions' immediately drops Low AND Medium, keeps Very low",
        dynamicRules.has(VERY_LOW_RULE) && LOW_RULES.every(id => !dynamicRules.has(id)) && advancedPresent().length === 0 &&
        !registeredScripts.has('sec-scp-fingerprint') && !registeredScripts.has('sec-medium-fingerprint') &&
        STATIC_SUPPRESSION_IDS.every(id => sessionRules.has(id)));
    await handleSetSecurityConfig({ key: ADV, value: true });
    check("mid-session: ticking 'advanced' again brings Low and Medium back (it re-ticked 'safe regions')",
        securityConfig[SAFE] === true && LOW_RULES.every(id => dynamicRules.has(id)) && advancedPresent().length === 3 &&
        STATIC_SUPPRESSION_IDS.every(id => sessionRules.has(id) === false));
    await handleSetSecurityConfig({ key: EXTRA, value: false });
    check("mid-session: unticking 'extra' immediately drops every group",
        !dynamicRules.has(VERY_LOW_RULE) && LOW_RULES.every(id => !dynamicRules.has(id)) && advancedPresent().length === 0 &&
        !registeredScripts.has('sec-scp-fingerprint') && !registeredScripts.has('sec-medium-fingerprint') &&
        STATIC_SUPPRESSION_IDS.every(id => sessionRules.has(id)));

    // Session end still removes everything, whatever the checkboxes say.
    await handleSetSecurityConfig({ key: ADV, value: true });
    await setSession(false);
    check("ending the Worry-free session removes every group",
        !dynamicRules.has(VERY_LOW_RULE) && LOW_RULES.every(id => !dynamicRules.has(id)) && advancedPresent().length === 0 &&
        !registeredScripts.has('sec-scp-fingerprint') && !registeredScripts.has('sec-medium-fingerprint') &&
        STATIC_SUPPRESSION_IDS.every(id => sessionRules.has(id)));
    await handleSetSecurityConfig({ key: ADV, value: false });
}

console.log('\nBand / id sanity');
check('no advanced rule id falls inside the saferegions sweep range (18M vs 17M)',
    [ ids.download, ids.sandbox, ids.thirdParty ].every(id => id >= budgets.SAFEREGIONS_RULES_END_ID));
check('advanced TLD band does not overlap the three rule ids',
    [ ids.download, ids.sandbox, ids.thirdParty ].every(id => id < budgets.ADVANCED_3P_TLD_ALLOW_RULES_BASE_ID));

console.log('');
if ( failures > 0 ) {
    console.log(`FAIL: e2e advanced protections (${failures} failure(s))`);
    process.exitCode = 1;
} else {
    console.log('PASS: e2e advanced protections (0 failure(s))');
}

// The real Worry-free session modules (startAutoDeny etc.) leave timers/listeners
// alive that would keep this process running after the assertions are done;
// exit explicitly so the check suite's per-script timeout is never what ends it.
process.exit(process.exitCode ?? 0);
