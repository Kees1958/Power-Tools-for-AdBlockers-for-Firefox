// C20a — message-type routing cross-reference. Every exported MSG_*
// constant is either request/response (needs a route AND a handler) or
// broadcast-only (needs at least one .onmessage reader, not a route).
// See Xplainer_Programming_principles_audit.md's C20a for the full
// rationale — this is a straight port of that section's check to fit
// this project's own tools/ + npm test convention, not a new design.
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
function read(p) { return fs.readFileSync(path.join(ROOT, p), 'utf8'); }

// Maintain this set explicitly — broadcast-only types are expected to be
// absent from the route/dispatch tables; everything else is not. Verified
// against the actual broadcastMessage()/.onmessage call sites in this
// codebase, not assumed or copied from another project's version of this
// same check.
const BROADCAST_ONLY = new Set([
    'MSG_MATRIX_ENTRY', 'MSG_MATRIX_CLOSED',
    'MSG_PRIVACY_INSPECTOR_ENTRY', 'MSG_PRIVACY_INSPECTOR_CLOSED',
    // Cookie/consent-clicker: SW -> content-script broadcast (via
    // browser.tabs.sendMessage() with no frameId — see cookie-clicker-
    // routes.js's broadcastPickerStop()), NOT a BroadcastChannel message
    // like the four above. Its reader lives in js/scripting/cookie-
    // clicker-picker.js's onRuntimeMessage() (chrome.runtime.onMessage),
    // which is why it needs its own entry in broadcastReaderFiles below
    // rather than reusing matrix-panel.js/privacy-inspector.js's list.
    'MSG_COOKIE_CLICKER_PICKER_STOP',
]);

const typesSrc  = read('js/data/message-types.js');
const routesSrc = read('js/workflow/message-routes.js');
const bgSrc     = read('js/workflow/background.js');

const msgConstEntries = [ ...typesSrc.matchAll(/export const (MSG_\w+)\s*=\s*'([^']+)'/g) ]
    .map(m => ({ name: m[1], value: m[2] }));
const msgConsts = msgConstEntries.map(e => e.name);

const missingRoute = [];
const missingHandler = [];
for ( const name of msgConsts ) {
    if ( BROADCAST_ONLY.has(name) ) { continue; }
    if ( !routesSrc.includes(`[${name}]`) ) { missingRoute.push(name); }
    if ( !bgSrc.includes(`[${name}]`) ) { missingHandler.push(name); }
}

// Broadcast-only types: confirm at least one .onmessage reader exists
// somewhere that checks for this exact constant name, across every file
// with a BroadcastChannel 'uBOL' handler.
const broadcastReaderFiles = [
    'matrix/matrix-panel.js',
    'privacy/privacy-inspector.js',
];
const readerSrcCombined = broadcastReaderFiles.map(f => {
    try { return read(f); } catch { return ''; }
}).join('\n');

// Reader files that are injected as PLAIN content scripts (via
// chrome.scripting.executeScript's `files` array), not loaded as ES
// modules — such files structurally CANNOT `import` message-types.js's
// constants (no module scope to import into), so their reader code
// necessarily compares against the message's literal STRING VALUE
// instead of the constant's NAME. Kept as its own small map (rather than
// folding into broadcastReaderFiles/readerSrcCombined above) so the
// distinction — "matched by name" vs "matched by value, because this
// reader can't import" — stays visible here instead of silently
// papered over by string-matching both the same way.
const VALUE_MATCHED_READERS = new Map([
    [ 'MSG_COOKIE_CLICKER_PICKER_STOP', 'js/scripting/cookie-clicker-picker.js' ],
]);

const missingReader = [ ...BROADCAST_ONLY ].filter(name => {
    // Must actually be declared (skip if this project's broadcast-only
    // set drifted out of sync with message-types.js itself).
    if ( !msgConsts.includes(name) ) { return false; }
    const valueReaderFile = VALUE_MATCHED_READERS.get(name);
    if ( valueReaderFile !== undefined ) {
        const value = msgConstEntries.find(e => e.name === name)?.value;
        let src = '';
        try { src = read(valueReaderFile); } catch { /* handled by the .includes() below returning false */ }
        return !(value !== undefined && src.includes(`'${value}'`));
    }
    return !readerSrcCombined.includes(name);
});

console.log('=== C20a: message-type routing cross-reference ===');
console.log(`Checked ${msgConsts.length} declared MSG_* constants (${BROADCAST_ONLY.size} broadcast-only, ${msgConsts.length - BROADCAST_ONLY.size} request/response).`);

let ok = true;
if ( missingRoute.length > 0 ) {
    ok = false;
    console.log(`FAIL: missing route entry: ${missingRoute.join(', ')}`);
}
if ( missingHandler.length > 0 ) {
    ok = false;
    console.log(`FAIL: missing dispatch handler: ${missingHandler.join(', ')}`);
}
if ( missingReader.length > 0 ) {
    ok = false;
    console.log(`FAIL: broadcast-only type with no .onmessage reader found: ${missingReader.join(', ')}`);
}
// Also flag any constant in BROADCAST_ONLY that no longer exists in
// message-types.js — the maintained set itself can drift stale after a
// rename, same failure mode the doc's own checklist calls out.
const staleBroadcastEntries = [ ...BROADCAST_ONLY ].filter(name => !msgConsts.includes(name));
if ( staleBroadcastEntries.length > 0 ) {
    ok = false;
    console.log(`FAIL: BROADCAST_ONLY set references constants no longer in message-types.js: ${staleBroadcastEntries.join(', ')}`);
}

if ( ok ) { console.log('PASS: every MSG_* constant is fully wired.'); }
console.log('');

/******************************************************************************/
// C20b — plain-identifier route cross-reference. C20a above only sees
// `[MSG_WHATEVER]`-shaped keys (computed from message-types.js's
// constants); a raw string-literal key like `siteModeGetAll:` in
// ROUTE_HANDLERS or MESSAGE_ROUTES is a different declaration shape its
// regex cannot see at all. This is exactly the shape $saferegions's own
// two routes take (and siteModeGetAll/SetAll before them) — ported from
// the same porting notes' own account of how $saferegions shipped
// completely broken the first time: a route declared in one table but not
// the other rejects every call before it reaches the handler,
// sendMessage() resolves to undefined, and the caller silently discards
// what the person typed. Every plain-identifier key in either table must
// appear in the other.
/******************************************************************************/

function extractBetween(src, startMarker, endMarker) {
    const start = src.indexOf(startMarker);
    if ( start === -1 ) { return ''; }
    const end = src.indexOf(endMarker, start + startMarker.length);
    if ( end === -1 ) { return ''; }
    return src.slice(start + startMarker.length, end);
}

// Bounded to the object bodies themselves — not the whole file — so a
// plain-identifier-shaped string elsewhere in either file (a comment, an
// unrelated object) can't produce a false hit.
const routeHandlersBody = extractBetween(bgSrc, 'const ROUTE_HANDLERS = {', '\n};');
const messageRoutesBody = extractBetween(routesSrc, 'export const MESSAGE_ROUTES = Object.freeze({', '\n});');

// Matches a top-level `identifier:` key — exactly 4-space indentation
// (this codebase's own consistent formatting for both tables' top-level
// entries; a nested key like `requiresInit:`/`allowedSenders:` inside a
// route's own Object.freeze({...}) value sits at 8 spaces and is
// deliberately excluded) — and excludes `[MSG_X]:` computed keys
// (already covered by C20a above) by requiring the key to start with a
// letter, not `[`.
const PLAIN_KEY_RE = /^ {4}([A-Za-z_$][\w$]*):/gm;

function plainKeysOf(body) {
    return new Set([ ...body.matchAll(PLAIN_KEY_RE) ].map(m => m[1]));
}

const routeHandlerKeys = plainKeysOf(routeHandlersBody);
const messageRouteKeys = plainKeysOf(messageRoutesBody);

const missingFromMessageRoutes = [ ...routeHandlerKeys ].filter(k => !messageRouteKeys.has(k));
const missingFromRouteHandlers = [ ...messageRouteKeys ].filter(k => !routeHandlerKeys.has(k));

console.log('=== C20b: plain-identifier route cross-reference ===');
console.log(`Checked ${routeHandlerKeys.size} ROUTE_HANDLERS key(s) and ${messageRouteKeys.size} MESSAGE_ROUTES key(s).`);

let ok2 = true;
if ( missingFromMessageRoutes.length > 0 ) {
    ok2 = false;
    console.log(`FAIL: in ROUTE_HANDLERS but missing from MESSAGE_ROUTES (every call will be rejected before it reaches the handler): ${missingFromMessageRoutes.join(', ')}`);
}
if ( missingFromRouteHandlers.length > 0 ) {
    ok2 = false;
    console.log(`FAIL: in MESSAGE_ROUTES but missing from ROUTE_HANDLERS (policy allows the call through, but nothing handles it): ${missingFromRouteHandlers.join(', ')}`);
}
if ( ok2 ) { console.log('PASS: every plain-identifier route is declared in both tables.'); }
console.log('');

ok = ok && ok2;
process.exitCode = ok ? 0 : 1;
