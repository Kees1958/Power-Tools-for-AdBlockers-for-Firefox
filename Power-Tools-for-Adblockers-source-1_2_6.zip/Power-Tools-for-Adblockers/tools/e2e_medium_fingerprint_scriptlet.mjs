// tools/e2e_medium_fingerprint_scriptlet.mjs -- executes the REAL
// js/security/sec-medium-fingerprint.js source inside a JSDOM window and
// asserts what it does (not merely that it parses):
//   - it applies EVERYWHERE it is injected -- the top-level page and every frame,
//     first- or third-party (1.2.3: scope is "websites outside safe regions", and
//     which sites those are is decided by the directive's excludeMatches, not by
//     the script) -- there is no top-level / same-origin guard;
//   - it applies every Low + Medium mitigation (2D canvas -> null,
//     permissions.query rejects, Web Audio stubbed, visibilitychange listeners
//     ignored, window.name empty, IdleDetector / NDEFReader absent,
//     plugins/mimeTypes empty, getBattery rejects), while leaving the HIGH-tier
//     signals it must not touch (WebGL context, WebRTC, timezone) as they were;
//   - one already-locked-down property never stops the others.
import fs from 'fs';
import path from 'path';
import { JSDOM } from 'jsdom';
import { HOST_HTML, installFakeApis, makeFrame } from './_jsdom-fingerprint-harness.mjs';

/******************************************************************************/
// CONFIGURATION -- declared once
/******************************************************************************/

const ROOT = path.resolve(import.meta.dirname, '..');
const SCRIPTLET = 'js/security/sec-medium-fingerprint.js';

/******************************************************************************/
// Harness
/******************************************************************************/

let failures = 0;
function check(name, cond, detail = '') {
    if ( cond ) { console.log(`  PASS: ${name}`); }
    else { failures++; console.log(`  FAIL: ${name}${detail ? ` -- ${detail}` : ''}`); }
}
const code = fs.readFileSync(path.join(ROOT, SCRIPTLET), 'utf8');


console.log('=== e2e: sec-medium-fingerprint.js executed in JSDOM ===\n');

/******************************************************************************/
console.log('Top-level page: the mitigations apply (scope = the website itself, not only its frames)');
{
    const dom = new JSDOM(HOST_HTML, { runScripts: 'outside-only' });
    const w = dom.window;
    installFakeApis(w);
    w.eval(code);
    check("top-level canvas.getContext('2d') returns null", w.document.createElement('canvas').getContext('2d') === null);
    check("top-level canvas.getContext('webgl') is UNTOUCHED (High tier)", w.document.createElement('canvas').getContext('webgl')?.real === 'webgl');
    check('top-level IdleDetector reads as absent', w.IdleDetector === undefined);
    check('top-level navigator.plugins is empty', w.navigator.plugins.length === 0);
    check("top-level window.name reads as ''", w.name === '');
    check('top-level AudioContext is stubbed', new w.AudioContext().real === undefined);
    let calls = 0;
    w.document.addEventListener('visibilitychange', () => { calls++; });
    w.document.dispatchEvent(new w.Event('visibilitychange'));
    check('top-level visibilitychange listener is ignored', calls === 0);
    check('top-level RTCPeerConnection untouched (High tier)', new w.RTCPeerConnection().real === true);
    dom.window.close();
}

/******************************************************************************/
console.log('\nThird-party frame: Low + Medium mitigations apply');
{
    const { dom, frame } = makeFrame();
    check('the frame is not the top window (test precondition)', frame !== frame.top);
    frame.eval(code);

    // Medium
    const canvas = frame.document.createElement('canvas');
    check("canvas.getContext('2d') returns null", canvas.getContext('2d') === null);
    check("canvas.getContext('webgl') is UNTOUCHED (High tier, not this item)", canvas.getContext('webgl')?.real === 'webgl');
    let queryRejected = false;
    try { await new frame.Permissions().query({ name: 'geolocation' }); } catch { queryRejected = true; }
    check('permissions.query rejects', queryRejected);
    const audio = new frame.AudioContext();
    check('AudioContext is replaced by an inert stub (no .real marker)', audio.real === undefined);
    check('stub AudioContext supports resume() -> resolves', (await audio.resume(), true));
    check('stub AudioContext hands out inert nodes', typeof audio.createGain().connect === 'function');
    const offline = new frame.OfflineAudioContext();
    check('OfflineAudioContext is replaced too', offline.real === undefined);
    check('stub OfflineAudioContext renders an empty buffer',
        (await offline.startRendering()).getChannelData(0).length === 0);
    let visibilityCalls = 0;
    let clickCalls = 0;
    frame.document.addEventListener('visibilitychange', () => { visibilityCalls++; });
    frame.document.addEventListener('click', () => { clickCalls++; });
    frame.document.dispatchEvent(new frame.Event('visibilitychange'));
    frame.document.dispatchEvent(new frame.Event('click'));
    check('visibilitychange listener is ignored', visibilityCalls === 0);
    check('other event listeners still work', clickCalls === 1);

    // Low
    check('IdleDetector reads as absent', frame.IdleDetector === undefined);
    check('NDEFReader reads as absent', frame.NDEFReader === undefined);
    check('navigator.plugins is empty', frame.navigator.plugins.length === 0);
    check('navigator.mimeTypes is empty', frame.navigator.mimeTypes.length === 0);
    let batteryRejected = false;
    try { await frame.navigator.getBattery(); } catch { batteryRejected = true; }
    check('navigator.getBattery rejects', batteryRejected);
    check("window.name reads as ''", frame.name === '');
    frame.name = 'attempted-identifier';
    check('window.name ignores writes', frame.name === '');

    // High tier: must be exactly as it was
    check('RTCPeerConnection untouched (High tier)', new frame.RTCPeerConnection().real === true);
    dom.window.close();
}

/******************************************************************************/
console.log('\nResilience: one locked-down property must not stop the others');
{
    const { dom, frame } = makeFrame();
    // Another wrapper already made 'plugins' non-configurable -- defineProperty
    // in the scriptlet will throw for it.
    Object.defineProperty(Object.getPrototypeOf(frame.navigator), 'plugins',
        { configurable: false, get() { return [ 'locked' ]; } });
    let threw = false;
    try { frame.eval(code); } catch { threw = true; }
    check('scriptlet does not throw', threw === false);
    check('the locked property is left as it was', frame.navigator.plugins[0] === 'locked');
    check('other mitigations still applied (2D canvas)', frame.document.createElement('canvas').getContext('2d') === null);
    check('other mitigations still applied (visibilitychange)', (() => {
        let calls = 0;
        frame.document.addEventListener('visibilitychange', () => { calls++; });
        frame.document.dispatchEvent(new frame.Event('visibilitychange'));
        return calls === 0;
    })());
    dom.window.close();
}

/******************************************************************************/
console.log('\nNo guard: same-origin and cross-origin frames are treated alike');
{
    const { dom, frame } = makeFrame();
    Object.defineProperty(frame.location, 'ancestorOrigins', { configurable: true, value: [ frame.location.origin ] });
    frame.eval(code);
    check('same-origin frame: 2D canvas blocked too', frame.document.createElement('canvas').getContext('2d') === null);
    dom.window.close();
}
{
    const { dom, frame } = makeFrame();
    Object.defineProperty(frame.location, 'ancestorOrigins', { configurable: true, value: [ 'https://other.example' ] });
    frame.eval(code);
    check('cross-origin frame: 2D canvas blocked', frame.document.createElement('canvas').getContext('2d') === null);
    dom.window.close();
}

console.log('');
if ( failures > 0 ) {
    console.log(`FAIL: e2e medium fingerprint scriptlet (${failures} failure(s))`);
    process.exitCode = 1;
} else {
    console.log('PASS: e2e medium fingerprint scriptlet (0 failure(s))');
}
