// e2e_saferegions_parser.mjs
//
// Regression test for a real, silent-data-loss bug found in production
// use: entering "@@bbc.com$saferegions" in the Allow list editor (the
// required ABP/uBlock exception-rule prefix — $saferegions is
// conceptually an exception, same as any other @@-prefixed allow rule in
// this filter-list ecosystem, and it's exactly what the reference
// screenshot's own example showed) silently collapsed to the domain "@".
// punycode.js's mapDomain() splits on every '@' in the string and only
// keeps the SECOND '@'-delimited segment (meant for user@domain email-
// address input); with two '@'s, that segment is the EMPTY string
// between them, not the real domain. No error, no warning — the
// person's entered exemption just silently became garbage.
//
// The "@@" prefix is REQUIRED, not optional — a bare
// "example.com$saferegions" (no @@) is NOT a valid $saferegions
// directive at all and must NOT be extracted as one.
//
// site-mode-parser.js's extractSaferegionsFromText()/textFromSaferegions()
// are pure functions (no state, no side effects — see that file's own
// header) — no browser/storage/DNR mocking needed, unlike the heavier
// subprocess-scenario e2e tests in this directory.

import { extractSaferegionsFromText, textFromSaferegions } from '../js/util/site-mode-parser.js';

console.log('=== e2e: site-mode-parser.js $saferegions @@-prefix handling ===\n');

let failures = 0;
function check(name, cond) {
    if ( cond ) { console.log(`  PASS: ${name}`); }
    else { failures++; console.log(`  FAIL: ${name}`); }
}

// The exact reported case, with the required prefix — must extract the
// real domain, not '@'.
{
    const { saferegionsDomains } = extractSaferegionsFromText('@@bbc.com$saferegions');
    check('"@@bbc.com$saferegions" extracts ["bbc.com"], not ["@"]', JSON.stringify(saferegionsDomains) === JSON.stringify([ 'bbc.com' ]));
}

// A bare domain (no @@ at all) must NOT be recognized as a $saferegions
// directive — the prefix is required, not optional.
{
    const { saferegionsDomains, remainingText } = extractSaferegionsFromText('bbc.com$saferegions');
    check('"bbc.com$saferegions" (no @@) is NOT extracted as a $saferegions domain', saferegionsDomains.length === 0);
    check('"bbc.com$saferegions" (no @@) falls through to remainingText untouched', remainingText === 'bbc.com$saferegions');
}

// A single '@' (not the required double) must also NOT be recognized.
{
    const { saferegionsDomains, remainingText } = extractSaferegionsFromText('@bbc.com$saferegions');
    check('"@bbc.com$saferegions" (single @) is NOT extracted as a $saferegions domain', saferegionsDomains.length === 0);
    check('"@bbc.com$saferegions" (single @) falls through to remainingText untouched', remainingText === '@bbc.com$saferegions');
}

// A third, stray leading '@' beyond the required two must still resolve
// to the real domain, not collapse via the same punycode.js quirk.
{
    const { saferegionsDomains } = extractSaferegionsFromText('@@@bbc.com$saferegions');
    check('"@@@bbc.com$saferegions" (stray extra @) still extracts ["bbc.com"]', JSON.stringify(saferegionsDomains) === JSON.stringify([ 'bbc.com' ]));
}

// Multiple lines: a correctly-prefixed $saferegions line, an un-prefixed
// line that looks similar but must NOT be treated as one, an ordinary
// no-filtering domain, and a comment.
{
    const text = [
        'example.org',
        '@@bbc.com$saferegions',
        'other.example$saferegions',
        '# a comment line',
        '',
    ].join('\n');
    const { saferegionsDomains, remainingText } = extractSaferegionsFromText(text);
    check(
        'mixed input extracts only the @@-prefixed line',
        JSON.stringify(saferegionsDomains) === JSON.stringify([ 'bbc.com' ])
    );
    check(
        'mixed input leaves the plain domain, the un-prefixed look-alike, and the comment in remainingText',
        remainingText.includes('example.org') &&
        remainingText.includes('other.example$saferegions') &&
        remainingText.includes('# a comment line') &&
        remainingText.includes('bbc.com') === false
    );
}

// Round-trip stability: extract, then re-serialize — must always
// reproduce the required @@-prefixed canonical form.
{
    const { saferegionsDomains } = extractSaferegionsFromText('@@bbc.com$saferegions');
    const serialized = textFromSaferegions(saferegionsDomains);
    check('round-trip serializes back to "@@bbc.com$saferegions"', serialized === '@@bbc.com$saferegions\n');
}

console.log(failures === 0 ? '\nPASS: e2e saferegions-parser check (0 failure(s))' : `\n${failures} FAILURE(S)`);
process.exitCode = failures === 0 ? 0 : 1;
