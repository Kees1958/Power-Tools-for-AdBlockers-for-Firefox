// tools/check-advanced-protections.mjs -- drift guard for the 1.2.0 "advanced"
// (Medium website breakage risk) Worry-free protections.
//
// Several values in this feature MUST exist in two places that cannot import
// each other (data/ cannot import core/; a MAIN-world scriptlet cannot import
// anything; a shipped static ruleset is plain JSON). Each such pair is a
// silent-drift risk, so this check compares them mechanically (same reasoning
// as check-scp-fingerprint-tier.mjs, C25):
//
//   A. config.js keys/defaults        <-> js/core/worry-free-advanced.js
//   B. item-1 sandbox header value    <-> rulesets/ruleset_worryfree_downloadblock.json
//   C. item-2 header: what it keeps, drops and forbids
//   D. item-3 resource-type sets (exempt vs fallback, and the derived list)
//   E. sec-medium-fingerprint.js `covers:` <-> the Privacy Inspector's
//      RULE_INFO table (Low + Medium in, High out) -- the tier table is the
//      single source of truth, this file must follow it
//   F. scope of the medium fingerprint scriptlet: "on websites outside safe
//      regions" (page + every frame) -- it must carry NO top-level / same-origin /
//      third-party guard (1.2.3; it was third-party frames only before)
//   G. priority / id-band relations the design depends on
//   H. dashboard wiring, ORDER of the two Filter-tab rows, and the exact
//      captions the person specified; the master checkbox lives ONLY on the
//      Filter (block) lists tab (a mirrored copy in Privacy & Security was
//      removed as redundant in 1.2.1)
//   I. default state of the Filter (block) lists tab: 'Enable Worry-free at
//      startup' and 'advanced' OFF, every other checkbox there ON
//   J. the three-tier hierarchy (worry-free-tiers.js): tier order/keys/defaults
//      vs config.js, and that each group's gating actually names its tier
//   K. the row-1 download watcher (1.2.4, notification added 1.2.6): `downloads` and
//      `notifications` are OPTIONAL permissions only, requested together in ONE
//      prompt, the guard is registered at top level, it uses the same gate as the
//      DNR rule, nothing else touches the downloads/notifications APIs, and the
//      dashboard asks for the permissions from a click and shows the notice
//
// HARD FAILURE on any mismatch. Proven by deliberate breakage -- see CHANGELOG.
import fs from 'fs';
import path from 'path';
import {
    stripComments, readRuleInfoTiers, readCovers, tokensFoundIn,
} from './_rule-info-tiers.mjs';

/******************************************************************************/
// CONFIGURATION -- declared once
/******************************************************************************/

const ROOT = path.resolve(import.meta.dirname, '..');
const FILES = Object.freeze({
    config:      'js/data/config.js',
    budgets:     'js/core/dnr-budgets.js',
    advanced:    'js/core/worry-free-advanced.js',
    labels:      'js/data/scriptlet-rule-labels.js',
    medium:      'js/security/sec-medium-fingerprint.js',
    scp:         'js/security/sec-scp-fingerprint.js',
    downloadRs:  'rulesets/ruleset_worryfree_downloadblock.json',
    dashboard:   'dashboard/dashboard.html',
    manifest:    'manifest.json',
    filterUi:    'dashboard/filter-manager-ui.js',
    tiers:       'js/core/worry-free-tiers.js',
    rulesetMgr:  'js/core/ruleset-manager.js',
    compiled:    'js/core/compiled-filters.js',
    extraMgr:    'js/core/worry-free-extra-manager.js',
    routes:      'js/workflow/security-routes.js',
    guard:       'js/core/download-guard.js',
    background:  'js/workflow/background.js',
    security:    'dashboard/security.js',
    permHelper:  'js/ui/download-guard-permission.js',
});
// Captions the person specified verbatim (Privacy & Security group heading and
// the Filter (block) lists checkbox). A rewording must be a deliberate change.
const SPECIFIED_GROUP_HEADING =
    "Medium website breakage risk enhancements (enabled by default when 'advanced' is enabled in Worry-free)";
const SPECIFIED_FILTER_LABEL =
    "Enable the advanced 'safe regions' protections additionally (see Privacy &amp; Security tab)";
// Tooltip of the Filter (block) lists tab's "extra 'safe regions'" checkbox, in the
// wording the person approved verbatim (1.2.5).
const APPROVED_SAFE_REGIONS_TOOLTIP =
    'Blocks scripts, frames and downloads that a page loads from other websites, unless those sites are on the safe list below. Edit the list to change what counts as safe.';
// In the ORDER the person specified for the Privacy & Security group (1.2.3).
const SPECIFIED_ROW_LABELS = Object.freeze([
    'Block first-party downloads on websites outside the safe-regions.',
    'Enforce Sandbox Content Policy safe scripts on websites outside the safe-regions.',
    'Enforce medium-risk fingerprinting protections on websites outside safe regions.',
    'Block third-party from websites outside safe regions, except text, images and videos.',
]);
const SPECIFIED_ROW_ORDER_IDS = Object.freeze([
    'blockMediumFirstPartyDownloads',
    'enforceMediumSandboxSafeScripts',
    'blockMediumFingerprint',
    'blockMediumThirdParty',
]);
// The person-specified default state of the Filter (block) lists tab's
// Worry-free section (1.2.1): these two OFF, every other checkbox on that tab
// ON. Declared once here; section I compares config.js and the manifest to it.
const FILTER_TAB_OFF_BY_DEFAULT = Object.freeze([
    'startWorryFreeOnBrowserStartup',
    'worryFreeAdvancedTldProtectionsEnabled',
]);
const FILTER_TAB_ON_BY_DEFAULT = Object.freeze([
    'worryFreeSecurityProtectionsEnabled',
    'worryFreeSecurityTldProtectionsEnabled',
]);
// A Firefox-shaped enum used only to exercise getAdvancedThirdPartyBlockedResourceTypes().
const MOCK_ENUM = Object.freeze({
    MAIN_FRAME: 'main_frame', SUB_FRAME: 'sub_frame', STYLESHEET: 'stylesheet', SCRIPT: 'script',
    IMAGE: 'image', FONT: 'font', OBJECT: 'object', XMLHTTPREQUEST: 'xmlhttprequest',
    PING: 'ping', CSP_REPORT: 'csp_report', MEDIA: 'media', WEBSOCKET: 'websocket', OTHER: 'other',
});
const FORBIDDEN_SANDBOX_FLAGS_ITEM2 = Object.freeze([
    'allow-modals', 'allow-popups-to-escape-sandbox',
    'allow-top-navigation', 'allow-top-navigation-by-user-activation',
    'allow-top-navigation-to-custom-protocols',
]);
const REQUIRED_SANDBOX_FLAGS_ITEM2 = Object.freeze([
    'allow-scripts', 'allow-same-origin', 'allow-forms', 'allow-downloads',
]);

/******************************************************************************/
// Harness
/******************************************************************************/

let failures = 0;
function fail(msg) { failures++; console.log(`FAIL: ${msg}`); }
function pass(msg) { console.log(`PASS: ${msg}`); }
function expect(cond, okMsg, failMsg) { if ( cond ) { pass(okMsg); } else { fail(failMsg ?? okMsg); } }
function read(rel) { return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function constNum(src, name) {
    const m = src.match(new RegExp(`export const ${name}\\s*=\\s*([\\d_]+)`));
    return m ? Number(m[1].replace(/_/g, '')) : undefined;
}

console.log('=== Advanced (Medium-risk) protections: drift guard ===');

// Import the real module under a minimal mock so its exported values -- not a
// regex's guess at them -- are what gets compared.
globalThis.self = globalThis;
globalThis.browser = { declarativeNetRequest: { ResourceType: { ...MOCK_ENUM } } };
const adv = await import(`file://${path.join(ROOT, FILES.advanced)}`);
const tiers = await import(`file://${path.join(ROOT, FILES.tiers)}`);

/******************************************************************************/
console.log('\n-- A. config.js <-> worry-free-advanced.js');
{
    const config = read(FILES.config);
    function settingRe(k) { return new RegExp(`^\\s*${k}:\\s*(true|false)\\b`, 'm'); }
    const sm = config.match(settingRe(adv.ADVANCED_SETTING_KEY));
    expect(sm !== null && sm[1] === 'false',
        `config.js declares ${adv.ADVANCED_SETTING_KEY} with default false (opt-in)`,
        `config.js must declare ${adv.ADVANCED_SETTING_KEY}: false`);
    for ( const key of Object.values(adv.ADVANCED_ITEM_KEYS) ) {
        const m = config.match(settingRe(key));
        expect(m !== null && m[1] === 'true',
            `config.js declares ${key} with default true (opt-out semantics)`,
            `config.js must declare ${key}: true (a stored false default could never activate)`);
    }
}

/******************************************************************************/
console.log('\n-- B. item-1 sandbox flags <-> shipped download-block ruleset');
{
    const rules = JSON.parse(read(FILES.downloadRs));
    const shipped = rules[0]?.action?.responseHeaders?.[0]?.value ?? '';
    const shippedFlags = shipped.split(/\s+/).slice(1);
    const ours = [ ...adv.ADVANCED_NO_DOWNLOADS_SANDBOX_FLAGS ];
    const expected = shippedFlags.filter(f => f !== adv.ADVANCED_ESCAPE_POPUPS_FLAG);
    expect(JSON.stringify(ours) === JSON.stringify(expected),
        'row-1 flags = the shipped third-party download-block flags MINUS allow-popups-to-escape-sandbox (and nothing else)',
        `row-1 flags drifted.\n  shipped minus escape: ${expected.join(' ')}\n  module:              ${ours.join(' ')}`);
    expect(adv.ADVANCED_NO_DOWNLOADS_SANDBOX_VALUE === `sandbox ${ours.join(' ')}`,
        'ADVANCED_NO_DOWNLOADS_SANDBOX_VALUE is built from that flag list');
    expect(shippedFlags.includes(adv.ADVANCED_ESCAPE_POPUPS_FLAG),
        'the shipped THIRD-PARTY block still has allow-popups-to-escape-sandbox (only row 1 drops it -- if that changed, revisit this rule)',
        'the shipped download-block ruleset no longer has allow-popups-to-escape-sandbox: row 1 no longer differs from it -- update this check deliberately');
    expect(ours.includes('allow-downloads') === false,
        'row-1 flags omit allow-downloads (that omission IS the feature)',
        'row-1 flags contain allow-downloads -- it would no longer block downloads');
    expect(ours.includes(adv.ADVANCED_ESCAPE_POPUPS_FLAG) === false,
        'row-1 flags omit allow-popups-to-escape-sandbox (a popup inherits the no-downloads sandbox)',
        'row-1 flags contain allow-popups-to-escape-sandbox -- a popup could start the download the page cannot');
    expect(ours.includes('allow-popups'),
        'row-1 flags keep allow-popups (popups still open; they just inherit the sandbox)',
        'row-1 flags lost allow-popups -- popups would no longer open at all');
}

/******************************************************************************/
console.log('\n-- C. item-2 header');
{
    const value = adv.ADVANCED_SAFE_SCRIPTS_HEADER_VALUE;
    const [ sandboxPart, scriptPart ] = value.split(';').map(v => v.trim());
    const flags = sandboxPart.split(/\s+/).slice(1);
    expect(sandboxPart.startsWith('sandbox '), 'item-2 value starts with a sandbox directive');
    for ( const f of REQUIRED_SANDBOX_FLAGS_ITEM2 ) {
        expect(flags.includes(f), `item-2 sandbox keeps ${f}`, `item-2 sandbox is missing ${f}`);
    }
    for ( const f of FORBIDDEN_SANDBOX_FLAGS_ITEM2 ) {
        expect(flags.includes(f) === false, `item-2 sandbox drops ${f}`, `item-2 sandbox still contains ${f}`);
    }
    expect(new Set(flags).size === flags.length, 'item-2 sandbox flag list has no duplicates');
    expect(scriptPart?.startsWith('script-src ') === true &&
           scriptPart.includes("'unsafe-eval'") === false &&
           scriptPart.includes("'unsafe-inline'") &&
           scriptPart.includes("'wasm-unsafe-eval'") &&
           scriptPart.split(/\s+/).includes('*'),
        "item-2 script-src forbids eval (no 'unsafe-eval'), allows any source, inline scripts and WebAssembly",
        `item-2 script-src is wrong: ${scriptPart}`);
}

/******************************************************************************/
console.log('\n-- D. item-3 resource types');
{
    const exempt = [ ...adv.ADVANCED_3P_EXEMPT_RESOURCE_TYPES ].sort();
    expect(JSON.stringify(exempt) === JSON.stringify([ 'image', 'main_frame', 'media', 'sub_frame' ]),
        'exempt types are exactly HTML documents (main_frame, sub_frame), image and media',
        `exempt types changed: ${exempt.join(', ')}`);
    const overlap = adv.ADVANCED_3P_FALLBACK_BLOCKED_RESOURCE_TYPES.filter(t => exempt.includes(t));
    expect(overlap.length === 0, 'fallback block list does not include any exempt type',
        `fallback list contains exempt type(s): ${overlap.join(', ')}`);
    for ( const t of [ 'stylesheet', 'font' ] ) {
        expect(adv.ADVANCED_3P_FALLBACK_BLOCKED_RESOURCE_TYPES.includes(t),
            `fallback list blocks ${t} (specified: stylesheets and fonts ARE blocked)`,
            `fallback list must block ${t}`);
    }
    const derived = adv.getAdvancedThirdPartyBlockedResourceTypes();
    const expected = Object.values(MOCK_ENUM).filter(t => exempt.includes(t) === false).sort();
    expect(JSON.stringify([ ...derived ].sort()) === JSON.stringify(expected),
        'derived block list = browser enum minus the exempt types',
        `derived list wrong: ${derived.join(', ')}`);
}

/******************************************************************************/
console.log('\n-- E. sec-medium-fingerprint.js <-> Privacy Inspector RULE_INFO tiers');
{
    const tiers = readRuleInfoTiers(ROOT);
    if ( tiers === null ) {
        fail('could not locate RULE_INFO in scriptlet-rule-labels.js (the table moved -- update tools/_rule-info-tiers.mjs)');
    } else {
        const lowMedium = new Set([ ...tiers.low, ...tiers.medium ]);
        const mediumSrc = read(FILES.medium);
        const covers = readCovers(mediumSrc);
        const missing = [ ...lowMedium ].filter(a => covers.has(a) === false);
        const extra = [ ...covers ].filter(a => lowMedium.has(a) === false);
        expect(lowMedium.size > 0, `RULE_INFO yields ${lowMedium.size} Low/Medium argument(s) to cover`,
            'parsed zero Low/Medium arguments from RULE_INFO -- parser out of date');
        expect(missing.length === 0,
            'every Low/Medium RULE_INFO argument is covered by sec-medium-fingerprint.js',
            `Low/Medium signal(s) in RULE_INFO but not covered by sec-medium-fingerprint.js: ${missing.join(', ')}`);
        expect(extra.length === 0,
            'sec-medium-fingerprint.js claims nothing beyond the Low/Medium tiers',
            `sec-medium-fingerprint.js claims coverage of non-Low/Medium argument(s): ${extra.join(', ')}`);
        const leaked = tokensFoundIn(stripComments(mediumSrc), tiers.tokens.high);
        expect(leaked.length === 0,
            'no High-tier signal appears in the medium scriptlet\'s code',
            `High-tier token(s) found in sec-medium-fingerprint.js code: ${leaked.join(', ')}`);
        const highCovered = [ ...covers ].filter(c => tiers.high.has(c));
        expect(highCovered.length === 0, 'no `covers:` line names a High-tier argument',
            `High-tier argument(s) in covers: ${highCovered.join(', ')}`);
    }
}

/******************************************************************************/
console.log('\n-- F. scope of the medium fingerprint scriptlet (no guard)');
{
    const code = stripComments(read(FILES.medium));
    expect(/window\s*===?\s*window\.top|window\.top\s*===?\s*window/.test(code) === false,
        'no top-level guard (the script applies to the page itself, not only to frames)',
        'sec-medium-fingerprint.js contains a `window === window.top` guard -- the specified scope is "on websites outside safe regions" (page + every frame)');
    expect(code.includes('ancestorOrigins') === false,
        'no same-origin / third-party frame guard (ancestorOrigins is not consulted)',
        'sec-medium-fingerprint.js consults ancestorOrigins -- it must not restrict itself to third-party frames');
}

/******************************************************************************/
console.log('\n-- G. priority / id relations');
{
    const budgets = read(FILES.budgets);
    function n(name) { return constNum(budgets, name); }
    expect(n('ADVANCED_3P_TLD_ALLOW_PRIORITY') > n('ADVANCED_3P_BLOCK_PRIORITY'),
        'advanced 3P exemption outranks the advanced 3P block',
        'ADVANCED_3P_TLD_ALLOW_PRIORITY must exceed ADVANCED_3P_BLOCK_PRIORITY');
    expect(n('WORRY_FREE_SCP_BLOCK_PRIORITY') < n('WORRY_FREE_SCP_TLD_ALLOW_PRIORITY'),
        'SCP block < SCP allow (the advanced header rules borrow that pair)',
        'WORRY_FREE_SCP_BLOCK_PRIORITY must stay below WORRY_FREE_SCP_TLD_ALLOW_PRIORITY');
    expect(/export const ADVANCED_HEADER_RULES_PRIORITY\s*=\s*WORRY_FREE_SCP_BLOCK_PRIORITY;/.test(budgets),
        'ADVANCED_HEADER_RULES_PRIORITY is still the SCP block priority (so the SCP allow band exempts it)',
        'ADVANCED_HEADER_RULES_PRIORITY no longer equals WORRY_FREE_SCP_BLOCK_PRIORITY -- the header rules would lose their safe-region exemption');
    const ruleIds = [ 'ADVANCED_FIRST_PARTY_DOWNLOAD_BLOCK_RULE_ID', 'ADVANCED_SANDBOX_SAFE_SCRIPTS_RULE_ID', 'ADVANCED_THIRD_PARTY_BLOCK_RULE_ID' ].map(n);
    const bandBase = n('ADVANCED_3P_TLD_ALLOW_RULES_BASE_ID');
    const bandEnd = n('ADVANCED_3P_TLD_ALLOW_RULES_END_ID');
    const srBase = n('SAFEREGIONS_ADVANCED_3P_ALLOW_RULES_BASE_ID');
    const srEnd = n('SAFEREGIONS_RULES_END_ID');
    expect(ruleIds.every(Number.isInteger) && [ bandBase, bandEnd, srBase, srEnd ].every(Number.isInteger),
        'all advanced id constants are present and numeric');
    expect(ruleIds.every(id => id < bandBase) && bandBase < bandEnd,
        'advanced rule ids sit below the advanced TLD exemption band, which is non-empty');
    expect(srBase < srEnd && srEnd <= Math.min(...ruleIds),
        'the saferegions sweep range (incl. its new advanced band) ends before the advanced rule ids begin',
        'SAFEREGIONS_RULES_END_ID overlaps the advanced rule ids');
}

/******************************************************************************/
console.log('\n-- H. dashboard wiring, order and specified captions');
{
    const html = read(FILES.dashboard);
    const keys = [ adv.ADVANCED_SETTING_KEY, ...Object.values(adv.ADVANCED_ITEM_KEYS) ];
    for ( const key of keys ) {
        expect(html.includes(`data-setting="${key}"`), `dashboard.html has a checkbox bound to ${key}`,
            `dashboard.html has no checkbox with data-setting="${key}"`);
    }
    const extraAt = html.indexOf('id="worryFreeSecurityTldProtectionsToggle"');
    const advAt = html.indexOf('id="worryFreeSecurityAdvancedTldProtectionsToggle"');
    const startupAt = html.indexOf('id="startWorryFreeOnBrowserStartupToggle"');
    expect(extraAt !== -1 && advAt > extraAt && advAt < startupAt,
        "Filter tab: the 'advanced' row sits directly BELOW the 'extra safe regions' row",
        "Filter tab: the 'advanced' row must come after the 'extra safe regions' row and before the startup row");
    expect(html.includes(`id="worryFreeSecurityAdvancedTldProtectionsLabel">${SPECIFIED_FILTER_LABEL}</label>`),
        'Filter tab caption matches the specified text',
        'Filter tab caption differs from the specified text');
    expect(html.includes(`>${SPECIFIED_GROUP_HEADING}</h3>`),
        'Privacy & Security group heading matches the specified text',
        'Privacy & Security group heading differs from the specified text');
    for ( const label of SPECIFIED_ROW_LABELS ) {
        expect(html.includes(`>${label}</label>`), `row label present: "${label.slice(0, 48)}..."`,
            `row label missing or reworded: "${label}"`);
    }
    expect(html.includes('worryFreeSecurityAdvancedTldProtectionsToggle2') === false,
        "Privacy & Security has NO mirrored copy of the 'advanced' master checkbox (it lives on the Filter tab only)",
        "a mirrored 'advanced' master checkbox reappeared in Privacy & Security -- it was removed as redundant");
    const positions = SPECIFIED_ROW_ORDER_IDS.map(id => html.indexOf(`<input id="${id}"`));
    expect(positions.every(p => p !== -1) && positions.every((p, i) => i === 0 || p > positions[i - 1]),
        'Privacy & Security Medium group: rows are in the specified order (downloads, sandbox, fingerprint, third-party block)',
        `Medium group row order differs from the specified order; positions: ${positions.join(', ')}`);
    expect(read(FILES.filterUi).includes(`tldLabel.title = '${APPROVED_SAFE_REGIONS_TOOLTIP}';`),
        "Filter tab: the 'extra safe regions' tooltip is the approved wording",
        "Filter tab: the 'extra safe regions' tooltip differs from the approved wording");
    expect(html.includes('worryFreeSecurityTldProtectionsToggle2') === false &&
           (html.match(/data-setting="worryFreeSecurityTldProtectionsEnabled"/g) ?? []).length === 1,
        "the 'safe regions' switch lives ONLY on the Filter tab (its mirrored copy in Privacy & Security stays removed)",
        "a second checkbox for the 'safe regions' setting is back in dashboard.html -- it was removed as redundant in 1.2.6");
    const ui = read(FILES.filterUi);
    expect(ui.includes(`'worryFreeSecurityAdvancedTldProtectionsToggle', '${adv.ADVANCED_SETTING_KEY}'`),
        'filter-manager-ui.js binds the Filter-tab checkbox to the setting',
        'filter-manager-ui.js does not bind the Filter-tab checkbox to the setting');
}

/******************************************************************************/
console.log('\n-- I. default state of the Filter (block) lists tab');
{
    const config = read(FILES.config);
    const html = read(FILES.dashboard);
    const filterPane = html.slice(html.indexOf('<section data-pane="filterlists">'), html.indexOf('<section data-pane="develop">'));
    expect(FILTER_TAB_OFF_BY_DEFAULT.includes(adv.ADVANCED_SETTING_KEY),
        'the module\'s ADVANCED_SETTING_KEY is one of the two OFF-by-default keys');
    for ( const [ keys, wanted ] of [ [ FILTER_TAB_OFF_BY_DEFAULT, 'false' ], [ FILTER_TAB_ON_BY_DEFAULT, 'true' ] ] ) {
        for ( const key of keys ) {
            const m = config.match(new RegExp(`^\\s*${key}:\\s*(true|false)\\b`, 'm'));
            expect(m !== null && m[1] === wanted,
                `config.js default: ${key} = ${wanted}`,
                `config.js default for ${key} must be ${wanted}`);
            expect(filterPane.includes(`data-setting="${key}"`),
                `Filter tab has the checkbox for ${key}`,
                `Filter tab has no checkbox bound to ${key}`);
        }
    }
    const manifest = JSON.parse(read(FILES.manifest));
    const rulesets = manifest.declarative_net_request?.rule_resources ?? [];
    const disabled = rulesets.filter(r => r.enabled !== true).map(r => r.id);
    expect(rulesets.length > 0 && disabled.length === 0,
        `every built-in filter list ruleset defaults ON (${rulesets.length} in the manifest)`,
        `ruleset(s) defaulting OFF in the manifest: ${disabled.join(', ')}`);
}

/******************************************************************************/
console.log('\n-- J. three-tier hierarchy');
{
    const defs = tiers.WORRY_FREE_TIER_DEFS;
    expect(JSON.stringify(defs.map(d => d.tier)) === JSON.stringify([ 'extra', 'safeRegions', 'advanced' ]),
        'hierarchy order is extra -> safeRegions -> advanced (lowest first)',
        `tier order changed: ${defs.map(d => d.tier).join(', ')}`);
    expect(adv.ADVANCED_SETTING_KEY === tiers.WORRY_FREE_TIER_SETTING_KEYS.advanced,
        "the advanced module's master key IS the 'advanced' tier's key (one definition)");
    const config = read(FILES.config);
    for ( const def of defs ) {
        const m = config.match(new RegExp(`^\\s*${def.key}:\\s*(true|false)\\b`, 'm'));
        expect(m !== null && (m[1] === 'true') === def.onWhenUnset,
            `tier '${def.tier}': config.js default (${m?.[1]}) agrees with onWhenUnset (${def.onWhenUnset})`,
            `tier '${def.tier}': config.js default for ${def.key} disagrees with worry-free-tiers.js's onWhenUnset`);
    }
    // Behavior of the pure functions (fast, no browser needed).
    const all = { worryFreeSecurityProtectionsEnabled: true, worryFreeSecurityTldProtectionsEnabled: true, worryFreeAdvancedTldProtectionsEnabled: true };
    const st = tiers.getWorryFreeTierState(all, true);
    expect(st.extra && st.safeRegions && st.advanced, 'all three ticked + session -> all three effective');
    const noSession = tiers.getWorryFreeTierState(all, false);
    expect(!noSession.extra && !noSession.safeRegions && !noSession.advanced, 'no session -> nothing effective');
    const brokenA = tiers.getWorryFreeTierState({ ...all, worryFreeSecurityProtectionsEnabled: false }, true);
    expect(!brokenA.extra && !brokenA.safeRegions && !brokenA.advanced,
        "'extra' off -> 'safe regions' and 'advanced' are NOT effective even though ticked");
    const brokenB = tiers.getWorryFreeTierState({ ...all, worryFreeSecurityTldProtectionsEnabled: false }, true);
    expect(brokenB.extra && !brokenB.safeRegions && !brokenB.advanced,
        "'safe regions' off -> 'advanced' is NOT effective even though ticked");
    // Each group's gating must name ITS tier (the three consumers).
    const rs = read(FILES.rulesetMgr);
    expect(/enabled: tiers\.safeRegions && securityConfig\.blockScpPrivacy !== false/.test(rs) &&
           /enabled: tiers\.safeRegions && securityConfig\.blockScpSecurity !== false/.test(rs),
        "ruleset-manager.js: the Low group's DNR rows are gated by the 'safeRegions' tier",
        "ruleset-manager.js: a Low-group DNR row is no longer gated by tiers.safeRegions");
    expect((rs.match(/isAdvancedItemActive\(securityConfig, ADVANCED_ITEM_KEYS\.[A-Z_]+, tiers\)/g) ?? []).length === 3,
        "ruleset-manager.js: all three Medium DNR rows are gated by the 'advanced' tier state",
        'ruleset-manager.js: a Medium DNR row does not pass the tier state to isAdvancedItemActive()');
    const cf = read(FILES.compiled);
    expect(/key: 'blockScpFingerprint',[\s\S]*?worryFreeTier: WORRY_FREE_TIER\.SAFE_REGIONS/.test(cf),
        "compiled-filters.js: blockScpFingerprint (Low group) declares the 'safeRegions' tier",
        "compiled-filters.js: blockScpFingerprint no longer declares worryFreeTier: SAFE_REGIONS");
    expect(/key: ADVANCED_ITEM_KEYS\.FINGERPRINT,[\s\S]*?worryFreeTier: WORRY_FREE_TIER\.ADVANCED/.test(cf),
        "compiled-filters.js: the medium fingerprint scriptlet declares the 'advanced' tier",
        "compiled-filters.js: the medium fingerprint scriptlet no longer declares worryFreeTier: ADVANCED");
    expect(read(FILES.extraMgr).includes('tiers.safeRegions === false'),
        "worry-free-extra-manager.js: the static third-party/download rules follow the 'safeRegions' tier",
        'worry-free-extra-manager.js no longer derives suppression from tiers.safeRegions');
    const routes = read(FILES.routes);
    expect(routes.includes('isWorryFreeTierSettingKey(key)') && routes.includes('computeTierCascade'),
        'security-routes.js: tier checkboxes go through the cascade path',
        'security-routes.js no longer routes tier keys through computeTierCascade');
}

/******************************************************************************/
console.log('\n-- K. row-1 download watcher (downloads API)');
{
    const manifest = JSON.parse(read(FILES.manifest));
    expect(adv.DOWNLOAD_GUARD_PERMISSION === 'downloads' && adv.DOWNLOAD_GUARD_NOTIFY_PERMISSION === 'notifications' &&
           JSON.stringify([ ...adv.DOWNLOAD_GUARD_PERMISSIONS ]) === JSON.stringify([ 'downloads', 'notifications' ]),
        'the permission constants are "downloads" and "notifications"');
    for ( const perm of adv.DOWNLOAD_GUARD_PERMISSIONS ) {
        expect((manifest.optional_permissions ?? []).includes(perm),
            `manifest: \`${perm}\` is an OPTIONAL permission`,
            `manifest: \`${perm}\` is missing from optional_permissions -- permissions.request() would fail`);
        expect((manifest.permissions ?? []).includes(perm) === false,
            `manifest: \`${perm}\` is NOT a required permission (it would block updates and prompt everyone)`,
            `manifest: \`${perm}\` is in the REQUIRED permissions -- it must stay optional`);
    }
    const helperSrc = stripComments(read(FILES.permHelper));
    expect(/permissions\.request\(\{ permissions: \[ \.\.\.DOWNLOAD_GUARD_PERMISSIONS \] \}\)/.test(helperSrc) &&
           (helperSrc.match(/permissions\.request\(/g) ?? []).length === 1,
        'both permissions are requested together, in ONE prompt (a second request would lose the click\'s user gesture)',
        'js/ui/download-guard-permission.js no longer requests both permissions in a single permissions.request() call');
    const bg = read(FILES.background);
    expect(/import \{ registerDownloadGuard \} from '\.\.\/core\/download-guard\.js';/.test(bg) &&
           /^registerDownloadGuard\(\);$/m.test(bg),
        'background.js registers the guard with a TOP-LEVEL call (an event page only wakes for listeners registered at load)',
        'background.js no longer calls registerDownloadGuard() at top level');
    const guardSrc = read(FILES.guard);
    expect(/isAdvancedItemActive\(securityConfig, ADVANCED_ITEM_KEYS\.FIRST_PARTY_DOWNLOADS, tiers\)/.test(guardSrc),
        'policy A uses the SAME gate as the DNR header rule (isAdvancedItemActive + the row key + the tier state)',
        'download-guard.js does not gate policy A on isAdvancedItemActive(... FIRST_PARTY_DOWNLOADS, tiers)');
    // 1.2.7 -- policy B (the Low group's "...and downloads" clause; Firefox has
    // no equivalent to Chrome's response-header forced-download layer).
    expect(/id: 'safeRegionsThirdParty'/.test(guardSrc) && /tiers\?\.safeRegions === true/.test(guardSrc),
        "policy B is gated on the 'safeRegions' tier (not 'advanced')",
        "download-guard.js's policy B is not gated on tiers.safeRegions");
    expect(/export async function isThirdPartyToTab/.test(guardSrc) &&
           guardSrc.includes("import { etldPlusOne } from './matrix-classifier.js';"),
        "policy B's third-party test reuses matrix-classifier.js's etldPlusOne (not a second reduction)",
        "download-guard.js no longer imports etldPlusOne from matrix-classifier.js -- it must not re-implement eTLD+1 reduction");
    expect(/byExtensionId/.test(guardSrc), 'the guard exempts extension-started downloads (this extension\'s own exports)');
    // Nothing else may touch the downloads API: the permission's whole surface stays in one file.
    const stray = [];
    (function walk(dir) {
        for ( const entry of fs.readdirSync(path.join(ROOT, dir), { withFileTypes: true }) ) {
            const rel = `${dir}/${entry.name}`;
            if ( entry.isDirectory() ) { if ( entry.name !== 'node_modules' ) { walk(rel); } }
            else if ( /\.m?js$/.test(entry.name) && rel !== FILES.guard &&
                      /\b(browser|chrome|webext)\.(downloads|notifications)\b/.test(stripComments(read(rel))) ) { stray.push(rel); }
        }
    })('js');
    expect(stray.length === 0, 'only download-guard.js touches the downloads and notifications APIs',
        `these files use the downloads/notifications API too: ${stray.join(', ')}`);
    const html = read(FILES.dashboard);
    // 1.2.7 -- policy B is deliberately silent by default (its gate, the
    // 'safeRegions' tier, is ON for nearly every install): it must NOT trigger a
    // new permission prompt or a new notice trigger; only 'advanced' and row 1 may.
    expect((stripComments(read(FILES.filterUi)).match(/requestDownloadGuardPermission\(\)/g) ?? []).length === 1,
        "the Filter tab still asks for the download permission from exactly ONE checkbox ('advanced')",
        "the Filter tab now asks for the download permission from more than one place -- policy B must stay silent until the permission is already granted");
    expect(/id="downloadGuardNotice"[^>]*>[^<]*&quot;notifications&quot;/.test(html),
        'the permission notice names BOTH permissions (downloads and notifications)',
        'the permission notice no longer mentions the notifications permission');
    expect(html.includes('id="downloadGuardNotice"') && html.includes('id="downloadGuardGrantButton"'),
        'Privacy & Security has the permission notice and its Grant button',
        'dashboard.html lost the download-guard notice / Grant button');
    expect(/id="blockMediumFirstPartyDownloads"[\s\S]*?title="[^"]*'downloads' permission/.test(html),
        "row 1's tooltip explains the optional 'downloads' permission",
        "row 1's tooltip no longer mentions the optional 'downloads' permission");
    const ui = read(FILES.filterUi);
    const sec = read(FILES.security);
    expect(/settingKey === ADVANCED_SETTING_KEY && cb\.checked/.test(ui) && /requestDownloadGuardPermission\(\)/.test(ui),
        "ticking 'advanced' (Filter tab) asks for the permission",
        "the Filter tab no longer asks for the downloads permission when 'advanced' is ticked");
    expect(/key === ADVANCED_ITEM_KEYS\.FIRST_PARTY_DOWNLOADS && value === true/.test(sec) && /requestDownloadGuardPermission\(\)/.test(sec),
        'ticking row 1 (Privacy & Security) asks for the permission',
        'Privacy & Security no longer asks for the downloads permission when row 1 is ticked');
    // The request must come BEFORE any await inside the handlers (user gesture).
    // From the start of the enclosing handler (`=> {`) up to the permission request there must be
    // NO `await` -- otherwise the prompt loses the click's user gesture.
    function handlerOrder(rawSrc, marker) {
        const src = stripComments(rawSrc);   // a comment saying "before any await" is not an await
        const at = src.indexOf(marker);
        const reqAt = src.indexOf('requestDownloadGuardPermission()', at);
        const handlerStart = src.lastIndexOf('=> {', at);
        return at !== -1 && reqAt !== -1 && handlerStart !== -1 &&
            src.slice(handlerStart, reqAt).includes('await ') === false;
    }
    expect(handlerOrder(ui, 'const permissionRequest ='),
        'Filter tab: no await between the start of the change handler and the permission request',
        'Filter tab: an `await` now precedes the permission request -- the prompt would lose the click\'s user gesture');
    expect(handlerOrder(sec, "const permissionRequest ="),
        'Privacy & Security: no await between the start of the change handler and the permission request',
        'Privacy & Security: an `await` now precedes the permission request -- the prompt would lose the click\'s user gesture');
}

console.log('');
if ( failures > 0 ) {
    console.log(`${failures} advanced-protections check(s) FAILED.`);
    process.exitCode = 1;
} else {
    console.log('PASS: advanced-protections drift guard clean.');
}
