// tools/e2e_download_guard.mjs -- behavioral proof for the 1.2.4 downloads-API
// watcher (js/core/download-guard.js) behind the Privacy & Security row
// "Block first-party downloads on websites outside the safe-regions."
//
// Runs the REAL guard, the REAL Worry-free session (startAutoDeny/cancelAutoDeny),
// the REAL tier gate, the REAL familiar-TLD / $saferegions storage and the REAL
// site filtering modes against the shared in-memory browser
// (tools/_mock-browser-env.mjs) plus a downloads mock that records every
// cancel()/removeFile() call. Each scenario asserts what was (not) cancelled.
import path from 'path';
import {
    permissionAddedListeners, firePermissionsAdded, tabUrls,
} from './_mock-browser-env.mjs';

/******************************************************************************/
// CONFIGURATION -- declared once
/******************************************************************************/

const ROOT = path.resolve(import.meta.dirname, '..');
const OWN_EXTENSION_ID = 'test';        // = browser.runtime.id in the shared mock
const TEST_TLDS = 'com, nl';            // the "safe regions" TLD list used here
const TEST_SAFEREGION_DOMAIN = 'trusted.example';
const LISTENER_SETTLE_MS = 50;          // handler runs un-awaited from the listener
const DOWNLOAD_ID = 7;

/******************************************************************************/
// downloads mock (absent until a test "grants" the permission)
/******************************************************************************/

const downloadListeners = new Set();
let downloadAddListenerCalls = 0;      // a Set would hide a duplicate registration; count the calls
const downloadCalls = [];               // [ 'cancel' | 'removeFile', id ]
let cancelShouldReject = false;         // models "already finished"
let removeFileShouldReject = false;     // models "no file on disk"
const downloadsMock = {
    onCreated: {
        addListener(fn) { downloadAddListenerCalls++; downloadListeners.add(fn); },
        removeListener(fn) { downloadListeners.delete(fn); },
        hasListener(fn) { return downloadListeners.has(fn); },
    },
    async cancel(id) {
        downloadCalls.push([ 'cancel', id ]);
        if ( cancelShouldReject ) { throw new Error('Download not in progress'); }
    },
    async removeFile(id) {
        downloadCalls.push([ 'removeFile', id ]);
        if ( removeFileShouldReject ) { throw new Error('No file'); }
    },
};

// notifications mock (present by default; a test removes it to model "permission absent")
const notificationCalls = [];           // [ id, options ]
let notificationsShouldReject = false;
const notificationsMock = {
    async create(id, options) {
        notificationCalls.push([ id, options ]);
        if ( notificationsShouldReject ) { throw new Error('notifications failed'); }
        return id;
    },
};
global.browser.notifications = notificationsMock;

/******************************************************************************/
// Harness
/******************************************************************************/

let failures = 0;
function check(name, cond, detail = '') {
    if ( cond ) { console.log(`  PASS: ${name}`); }
    else { failures++; console.log(`  FAIL: ${name}${detail ? ` -- ${detail}` : ''}`); }
}
function modUrl(rel) { return `file://${path.join(ROOT, rel)}`; }
function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function resetCalls() { downloadCalls.length = 0; cancelShouldReject = false; removeFileShouldReject = false; }
function cancelled() { return downloadCalls.some(c => c[0] === 'cancel'); }

const { securityConfig } = await import(modUrl('js/data/config.js'));
const guard = await import(modUrl('js/core/download-guard.js'));
const adv = await import(modUrl('js/core/worry-free-advanced.js'));
const tiers = await import(modUrl('js/core/worry-free-tiers.js'));
const { startAutoDeny, cancelAutoDeny, getAutoDenyState } = await import(modUrl('js/core/cookie-clicker-autodeny-manager.js'));
const { setFamiliarTlds } = await import(modUrl('js/core/worry-free-familiar-tld-manager.js'));
const { setSaferegionsDomains } = await import(modUrl('js/core/saferegions-manager.js'));
const { setFilteringMode, MODE_NONE, MODE_BASIC } = await import(modUrl('js/core/mode-manager.js'));

const K = tiers.WORRY_FREE_TIER_SETTING_KEYS;
const ROW = adv.ADVANCED_ITEM_KEYS.FIRST_PARTY_DOWNLOADS;

async function setSession(active) {
    const current = (await getAutoDenyState()).active === true;
    if ( active && current === false ) { await startAutoDeny(null); }
    else if ( active === false && current ) { await cancelAutoDeny(); }
}
async function setLive({ session = true, extra = true, safe = true, advanced = true, row = true } = {}) {
    await setSession(session);
    securityConfig[K[tiers.WORRY_FREE_TIER.EXTRA]] = extra;
    securityConfig[K[tiers.WORRY_FREE_TIER.SAFE_REGIONS]] = safe;
    securityConfig[K[tiers.WORRY_FREE_TIER.ADVANCED]] = advanced;
    securityConfig[ROW] = row;
}
async function decide(item) {
    resetCalls();
    const result = await guard.handleDownloadCreated({ id: DOWNLOAD_ID, ...item });
    return result;
}

console.log('=== e2e: downloads-API watcher (row 1) ===\n');

/******************************************************************************/
console.log('Pure helpers');
{
    check("hostnameOf: https page", guard.hostnameOf('https://Www.Evil.RU/a?b#c') === 'www.evil.ru');
    check('hostnameOf: blob: URL uses the ORIGIN\'s host', guard.hostnameOf('blob:https://evil.ru/1234-uuid') === 'evil.ru');
    check('hostnameOf: data: has no site', guard.hostnameOf('data:text/plain;base64,QQ==') === '');
    check('hostnameOf: file:/about:/garbage/empty/non-string have no site',
        [ 'file:///tmp/x', 'about:blank', 'not a url', '', undefined, null, 42 ].every(u => guard.hostnameOf(u) === ''));
    check('hostnameOf: blob: of a non-web origin has no site', guard.hostnameOf('blob:null/1234') === '');
    check('hostnameOf: an EXTENSION page/blob URL has no site (its "host" is a random UUID, not a website)',
        guard.hostnameOf('moz-extension://0b4c-uuid/dashboard/dashboard.html') === '' &&
        guard.hostnameOf('blob:moz-extension://0b4c-uuid/1234') === '');
    check('hostnameOf: other schemes that carry a host (ftp:, ws:) are not websites here',
        guard.hostnameOf('ftp://evil.ru/a.zip') === '' && guard.hostnameOf('wss://evil.ru/s') === '');

    const tlds = [ 'com', 'nl' ];
    const domains = [ 'trusted.example' ];
    check('safe: the TLD itself and subdomains', guard.isHostInSafeRegions('shop.example.com', tlds, domains) && guard.isHostInSafeRegions('www.bbc.nl', tlds, domains));
    check("NOT safe: 'com' as a leading label (com.evil.ru)", guard.isHostInSafeRegions('com.evil.ru', tlds, domains) === false);
    check("NOT safe: 'com' in the middle (evil.com.ru)", guard.isHostInSafeRegions('evil.com.ru', tlds, domains) === false);
    check("NOT safe: label that merely ends with the letters (evilcom)", guard.isHostInSafeRegions('evilcom', tlds, domains) === false);
    check('safe: a $saferegions domain and its subdomains', guard.isHostInSafeRegions('trusted.example', tlds, domains) && guard.isHostInSafeRegions('cdn.trusted.example', tlds, domains));
    check('NOT safe: a sibling of a $saferegions domain', guard.isHostInSafeRegions('nottrusted.example', tlds, domains) === false);
    check('empty host is never safe', guard.isHostInSafeRegions('', tlds, domains) === false);

    check('pickSiteHost prefers the referrer', JSON.stringify(guard.pickSiteHost({ referrer: 'https://a.ru/p', url: 'https://b.com/f.zip' })) === JSON.stringify({ host: 'a.ru', source: 'referrer' }));
    check('pickSiteHost falls back to finalUrl, then url',
        guard.pickSiteHost({ referrer: '', finalUrl: 'https://c.ru/f', url: 'https://d.ru/f' }).host === 'c.ru' &&
        guard.pickSiteHost({ referrer: '', url: 'https://d.ru/f' }).host === 'd.ru');
    check('pickSiteHost: nothing usable -> none', guard.pickSiteHost({ referrer: 'about:blank', url: 'data:,x' }).source === 'none');
    check('pickSiteHost tolerates a missing item', guard.pickSiteHost(undefined).host === '');
}

/******************************************************************************/
console.log('\nRegistration (init / idempotence / release / permission grant)');
{
    // The permission is not granted yet: browser.downloads does not exist.
    check('precondition: browser.downloads is absent', global.browser.downloads === undefined);
    let threw = false;
    try { guard.registerDownloadGuard(); } catch { threw = true; }
    check('registering without the permission does not throw', threw === false);
    check('...and registers no downloads listener', downloadListeners.size === 0);
    check('...but does listen for the permission being granted', permissionAddedListeners.size === 1);

    guard.registerDownloadGuard();
    check('registering twice keeps ONE permission listener (idempotent)', permissionAddedListeners.size === 1);

    // The person grants the permission: the API appears and onAdded fires.
    global.browser.downloads = downloadsMock;
    firePermissionsAdded({ permissions: [ 'downloads' ], origins: [] });
    check('granting the permission registers the downloads listener', downloadListeners.size === 1);
    firePermissionsAdded({ permissions: [ 'downloads' ], origins: [] });
    guard.registerDownloadGuard();
    check('re-firing / re-registering does not add a second downloads listener', downloadListeners.size === 1 && downloadAddListenerCalls === 1,
        `addListener was called ${downloadAddListenerCalls} time(s)`);

    firePermissionsAdded({ permissions: [ 'tabs' ], origins: [] });
    check('an unrelated permission grant changes nothing', downloadListeners.size === 1);

    guard.releaseDownloadGuard();
    check('release removes the downloads listener', downloadListeners.size === 0);
    check('release removes the permission listener', permissionAddedListeners.size === 0);
    guard.releaseDownloadGuard();
    check('release is safe to call twice', downloadListeners.size === 0 && permissionAddedListeners.size === 0);

    guard.registerDownloadGuard();
    check('register after release works again (state was cleared)', downloadListeners.size === 1 && permissionAddedListeners.size === 1 && downloadAddListenerCalls === 2);
}

/******************************************************************************/
await setFamiliarTlds(TEST_TLDS);
await setSaferegionsDomains([ TEST_SAFEREGION_DOMAIN ]);

console.log('\nGating: the row must be live (same gate as the DNR header rule)');
{
    const item = { referrer: 'https://evil.ru/page', url: 'https://evil.ru/a.zip' };
    await setLive();
    let r = await decide(item);
    check('everything on -> the download is cancelled, and its file removed',
        r.blocked && r.reason === guard.DOWNLOAD_DECISION.BLOCKED &&
        JSON.stringify(downloadCalls) === JSON.stringify([ [ 'cancel', DOWNLOAD_ID ], [ 'removeFile', DOWNLOAD_ID ] ]));

    await setLive({ session: false });
    r = await decide(item);
    check('no Worry-free session -> allowed', r.blocked === false && r.reason === guard.DOWNLOAD_DECISION.NO_POLICY_ACTIVE && !cancelled());
    await setLive({ advanced: false });
    r = await decide(item);
    check("'advanced' box off -> allowed", r.blocked === false && !cancelled());
    await setLive({ safe: false });
    r = await decide(item);
    check("'safe regions' box off (hierarchy) -> allowed", r.blocked === false && !cancelled());
    await setLive({ extra: false });
    r = await decide(item);
    check("'extra' box off (hierarchy) -> allowed", r.blocked === false && !cancelled());
    await setLive({ row: false });
    r = await decide(item);
    check('the row itself unticked -> allowed', r.blocked === false && !cancelled());

    // Stored state that breaks the hierarchy must not activate it either.
    await setLive({ extra: false, safe: true, advanced: true });
    r = await decide(item);
    check("stored 'safe regions'+'advanced' on but 'extra' off -> allowed", r.blocked === false && !cancelled());
    await setLive();
}

/******************************************************************************/
console.log("\nPolicy B: the Low group's third-party download clause (no 'advanced' needed)");
{
    const TAB_ID = 101;
    // Both the tab's own site and the referrer are UNSAFE (.ru), so the ONLY thing
    // that differs between the two items below is whether the download is
    // third-party to its tab -- not whether the site itself is safe.
    tabUrls.set(TAB_ID, 'https://evil.ru/checkout');
    const thirdPartyItem = { tabId: TAB_ID, referrer: 'https://other-evil.ru/embedded-frame', url: 'https://other-evil.ru/a.zip' };
    const firstPartyItem = { tabId: TAB_ID, referrer: 'https://evil.ru/page', url: 'https://evil.ru/a.zip' };

    await setLive({ advanced: false });   // 'advanced' OFF throughout this block -- only policy B can act
    let r = await decide(thirdPartyItem);
    check("a download whose referrer is a DIFFERENT (unsafe) site than the tab's own -> cancelled",
        r.blocked && r.reason === guard.DOWNLOAD_DECISION.BLOCKED && r.host === 'other-evil.ru');
    r = await decide(firstPartyItem);
    check("a download whose referrer IS the tab's own site -> allowed (that is policy A's job, and it's off)",
        r.blocked === false && r.reason === guard.DOWNLOAD_DECISION.NOT_THIRD_PARTY && !cancelled());

    await setLive({ advanced: false, safe: false });
    r = await decide(thirdPartyItem);
    check("'safe regions' box off too -> allowed (policy B needs its own tier)", r.blocked === false && !cancelled());

    await setLive({ advanced: false });
    tabUrls.delete(TAB_ID);
    r = await decide(thirdPartyItem);
    check('the tab no longer exists (closed) -> allowed, not a crash (cannot tell -> fails closed for this policy)',
        r.blocked === false && r.reason === guard.DOWNLOAD_DECISION.NOT_THIRD_PARTY && !cancelled());
    tabUrls.set(TAB_ID, 'https://shop.example.com/checkout');

    r = await decide({ referrer: 'https://evil.ru/embedded-frame', url: 'https://evil.ru/a.zip' });   // no tabId at all
    check('no tabId on the download item -> allowed, not a crash', r.blocked === false && !cancelled());

    r = await decide({ tabId: TAB_ID, referrer: '', url: 'https://evil.ru/a.zip' });
    check('no referrer at all -> policy B does not apply (nothing to compare the tab against); allowed with advanced off',
        r.blocked === false && r.reason === guard.DOWNLOAD_DECISION.NOT_THIRD_PARTY && !cancelled());

    await setLive({ advanced: false, row: false });   // row 1 explicitly off too -- must not matter to policy B
    r = await decide(thirdPartyItem);
    check("policy A's own row checkbox has no effect on policy B", r.blocked && r.reason === guard.DOWNLOAD_DECISION.BLOCKED);

    // Both policies active at once: still exactly one cancellation, not two.
    await setLive();   // advanced back on
    resetCalls();
    r = await decide(thirdPartyItem);
    check('with BOTH policies active, a third-party-to-the-tab download is still cancelled exactly once',
        r.blocked && downloadCalls.filter(c => c[0] === 'cancel').length === 1);

    tabUrls.delete(TAB_ID);
    await setLive();
}

/******************************************************************************/
console.log('\nWhich website: referrer first, file host when there is none');
{
    let r;
    r = await decide({ referrer: 'https://evil.ru/page', url: 'https://evil.ru/a.zip' });
    check('unsafe page, file on the same unsafe host -> cancelled', r.blocked && r.host === 'evil.ru');
    r = await decide({ referrer: 'https://evil.ru/page', url: 'https://cdn.example.com/a.zip' });
    check('unsafe page, file on a SAFE host -> still cancelled (the download belongs to the unsafe page)', r.blocked && r.host === 'evil.ru');
    r = await decide({ referrer: 'https://shop.example.com/page', url: 'https://files.evil.ru/a.zip' });
    check('SAFE page, file on an unsafe host -> allowed (the page is safe)', r.blocked === false && r.reason === guard.DOWNLOAD_DECISION.SAFE_REGION && !cancelled());
    r = await decide({ referrer: '', url: 'https://files.evil.ru/a.zip' });
    check('no referrer (typed URL / bookmark), unsafe file host -> cancelled', r.blocked && r.host === 'files.evil.ru');
    r = await decide({ referrer: '', url: 'https://files.example.com/a.zip' });
    check('no referrer, safe file host -> allowed', r.blocked === false && !cancelled());
    r = await decide({ referrer: '', finalUrl: 'https://final.evil.ru/a.zip', url: 'https://short.example.com/x' });
    check('no referrer: the FINAL url (after a redirect) decides, not the first hop', r.blocked && r.host === 'final.evil.ru');
}

console.log('\nSafe regions are matched by label, not by substring');
{
    let r;
    r = await decide({ referrer: 'https://com.evil.ru/p', url: 'https://com.evil.ru/a.zip' });
    check("com.evil.ru is NOT safe -> cancelled", r.blocked);
    r = await decide({ referrer: 'https://evil.com.ru/p', url: 'https://evil.com.ru/a.zip' });
    check("evil.com.ru is NOT safe -> cancelled", r.blocked);
    r = await decide({ referrer: 'https://www.bbc.nl/p', url: 'https://www.bbc.nl/a.zip' });
    check('a .nl site (in the list) -> allowed', r.blocked === false);
    r = await decide({ referrer: `https://sub.${TEST_SAFEREGION_DOMAIN}/p`, url: `https://sub.${TEST_SAFEREGION_DOMAIN}/a.zip` });
    check('a $saferegions domain (and its subdomains) -> allowed', r.blocked === false && r.reason === guard.DOWNLOAD_DECISION.SAFE_REGION);
}

/******************************************************************************/
console.log('\nWho started it, and URLs we cannot classify');
{
    let r;
    r = await decide({ byExtensionId: OWN_EXTENSION_ID, referrer: '', url: 'blob:moz-extension://x/uuid' });
    check("this extension's OWN download (export/backup) is never touched", r.blocked === false && r.reason === guard.DOWNLOAD_DECISION.BY_EXTENSION && !cancelled());
    r = await decide({ byExtensionId: 'other@example', referrer: 'https://evil.ru/p', url: 'https://evil.ru/a.zip' });
    check("another extension's download is left alone (an extension acting is the person's intent)", r.blocked === false && r.reason === guard.DOWNLOAD_DECISION.BY_EXTENSION && !cancelled());
    r = await decide({ referrer: '', url: 'blob:https://evil.ru/1234-uuid' });
    check('a script-made blob: download from an unsafe page -> cancelled', r.blocked && r.host === 'evil.ru');
    r = await decide({ referrer: '', url: 'blob:https://shop.example.com/1234-uuid' });
    check('a blob: download from a safe page -> allowed', r.blocked === false);
    r = await decide({ referrer: '', url: 'blob:moz-extension://0b4c-uuid/1234-uuid' });
    check("a blob: export made by THIS extension's own dashboard page (no byExtensionId) is never touched",
        r.blocked === false && r.reason === guard.DOWNLOAD_DECISION.NO_HOST && !cancelled());
    r = await decide({ referrer: 'moz-extension://0b4c-uuid/dashboard/dashboard.html', url: 'blob:moz-extension://0b4c-uuid/9' });
    check('...also when the referrer is the extension page itself', r.blocked === false && !cancelled());
    r = await decide({ referrer: '', url: 'data:text/plain;base64,QQ==' });
    check('data: URL with no referrer (cannot tell the site) -> allowed, not deleted', r.blocked === false && r.reason === guard.DOWNLOAD_DECISION.NO_HOST && !cancelled());
    r = await decide({ referrer: '', url: 'not a url' });
    check('garbage URL -> allowed, no throw', r.blocked === false && !cancelled());
    let threw = false;
    try { r = await guard.handleDownloadCreated(undefined); } catch { threw = true; }
    check('a missing download item never throws', threw === false && r.blocked === false);
}

console.log('\nSites the person set to "no filtering"');
{
    await setFilteringMode('evil.ru', MODE_NONE);
    let r = await decide({ referrer: 'https://evil.ru/p', url: 'https://evil.ru/a.zip' });
    check('a site whose filtering is OFF is exempt (same as the DNR header rule)', r.blocked === false && r.reason === guard.DOWNLOAD_DECISION.FILTERING_OFF && !cancelled());
    await setFilteringMode('evil.ru', MODE_BASIC);
    r = await decide({ referrer: 'https://evil.ru/p', url: 'https://evil.ru/a.zip' });
    check('back to normal filtering -> cancelled again', r.blocked);
}

console.log('\nFailure handling');
{
    resetCalls();
    cancelShouldReject = true;
    let r = await guard.handleDownloadCreated({ id: DOWNLOAD_ID, referrer: 'https://evil.ru/p', url: 'https://evil.ru/a.zip' });
    check('a download that already finished (cancel rejects) is still reported blocked and its file removal is attempted',
        r.blocked && downloadCalls.some(c => c[0] === 'removeFile'));
    resetCalls();
    removeFileShouldReject = true;
    r = await guard.handleDownloadCreated({ id: DOWNLOAD_ID, referrer: 'https://evil.ru/p', url: 'https://evil.ru/a.zip' });
    check('removeFile failing (no file yet) is swallowed', r.blocked && downloadCalls.some(c => c[0] === 'cancel'));
    resetCalls();
}

console.log('\nNotification: tell the person a download was blocked, and why');
{
    // Start from a clean slate: earlier sections may already have announced these sites.
    guard.releaseDownloadGuard();
    guard.registerDownloadGuard();
    const COOLDOWN = guard.NOTIFICATION_COOLDOWN_MS;
    await setLive();
    notificationCalls.length = 0;

    let r = await decide({ referrer: 'https://evil.ru/p', url: 'https://evil.ru/a.zip' });
    check('a cancelled download shows exactly ONE notification', r.blocked && notificationCalls.length === 1);
    const [ id, options ] = notificationCalls[0] ?? [];
    check('...it is a basic notification titled "Download blocked"', options?.type === 'basic' && options?.title === 'Download blocked');
    check('...the message names the site and says why', typeof options?.message === 'string' && options.message.includes('evil.ru') && options.message.includes('outside your safe regions'));
    check("...it uses the extension's own icon", typeof options?.iconUrl === 'string' && options.iconUrl.endsWith('img/icon_128.png'));
    check('...its id is per site, so a repeat REPLACES it in the notification list', id === 'uBol-download-blocked:evil.ru');

    r = await decide({ referrer: 'https://evil.ru/p', url: 'https://evil.ru/b.zip' });
    check('a second download from the SAME site inside the cooldown is cancelled but NOT announced again', r.blocked && notificationCalls.length === 1);
    r = await decide({ referrer: 'https://other.ru/p', url: 'https://other.ru/a.zip' });
    check('a DIFFERENT site is announced', r.blocked && notificationCalls.length === 2);

    const realNow = Date.now;
    Date.now = () => realNow() + COOLDOWN + 1;
    try { r = await decide({ referrer: 'https://evil.ru/p', url: 'https://evil.ru/c.zip' }); } finally { Date.now = realNow; }
    check('after the cooldown the same site is announced again', r.blocked && notificationCalls.length === 3);

    notificationCalls.length = 0;
    await decide({ referrer: 'https://shop.example.com/p', url: 'https://shop.example.com/a.zip' });
    await decide({ byExtensionId: 'other@example', referrer: 'https://evil.ru/p', url: 'https://evil.ru/a.zip' });
    await setLive({ row: false });
    await decide({ referrer: 'https://evil2.ru/p', url: 'https://evil2.ru/a.zip' });
    check('allowed downloads (safe site, extension-started, row off) produce NO notification', notificationCalls.length === 0);
    await setLive();

    guard.releaseDownloadGuard();
    guard.registerDownloadGuard();
    notificationCalls.length = 0;
    r = await decide({ referrer: 'https://evil.ru/p', url: 'https://evil.ru/d.zip' });
    check('release clears the per-site cooldown (the same site is announced at once after a release)', r.blocked && notificationCalls.length === 1);

    global.browser.notifications = undefined;
    notificationCalls.length = 0;
    let threw = false;
    try { r = await decide({ referrer: 'https://quiet.ru/p', url: 'https://quiet.ru/a.zip' }); } catch { threw = true; }
    check('WITHOUT the notifications permission the download is still cancelled, silently, no throw', threw === false && r.blocked && notificationCalls.length === 0 && downloadCalls.some(c => c[0] === 'cancel'));

    global.browser.notifications = notificationsMock;
    notificationCalls.length = 0;
    r = await decide({ referrer: 'https://quiet.ru/p', url: 'https://quiet.ru/b.zip' });
    check('...and the missing permission did NOT use up the cooldown: once it is granted the site is announced at once',
        r.blocked && notificationCalls.length === 1);
    notificationsShouldReject = true;
    threw = false;
    try { r = await decide({ referrer: 'https://noisy.ru/p', url: 'https://noisy.ru/a.zip' }); } catch { threw = true; }
    check('a FAILING notifications API changes nothing: still cancelled, no throw', threw === false && r.blocked && downloadCalls.some(c => c[0] === 'cancel'));
    notificationsShouldReject = false;
}

console.log('\nThrough the REAL registered listener');
{
    check('a listener is registered (from the Registration section)', downloadListeners.size === 1);
    const [ listener ] = [ ...downloadListeners ];
    await setLive();
    resetCalls();
    listener({ id: 11, referrer: 'https://evil.ru/p', url: 'https://evil.ru/a.zip' });
    await wait(LISTENER_SETTLE_MS);
    check('the listener cancels an unsafe-site download', downloadCalls.some(c => c[0] === 'cancel' && c[1] === 11));
    resetCalls();
    listener({ id: 12, referrer: 'https://shop.example.com/p', url: 'https://shop.example.com/a.zip' });
    await wait(LISTENER_SETTLE_MS);
    check('the listener leaves a safe-site download alone', downloadCalls.length === 0);
}

await setSession(false);
guard.releaseDownloadGuard();

console.log('');
if ( failures > 0 ) {
    console.log(`FAIL: e2e download guard (${failures} failure(s))`);
    process.exitCode = 1;
} else {
    console.log('PASS: e2e download guard (0 failure(s))');
}

// The real Worry-free session modules leave timers alive; exit explicitly so the
// suite's per-script timeout is never what ends this script.
process.exit(process.exitCode ?? 0);
