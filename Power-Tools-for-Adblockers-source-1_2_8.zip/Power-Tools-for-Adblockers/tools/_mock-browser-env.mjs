// tools/_mock-browser-env.mjs -- shared in-memory browser for the e2e tests.
//
// IMPORTING THIS MODULE INSTALLS THE GLOBALS (`self`, `browser`, `chrome`) --
// import it BEFORE dynamically importing any js/ module. It reproduces the
// browser behaviours the tests need to be honest about:
//   - DNR: an updateDynamicRules()/updateSessionRules() call containing a
//     DUPLICATE id fails as a whole; a rule naming a resource type absent from
//     the enum fails as a whole (dynamic rules);
//   - a content-script registry where a duplicate/unknown id throws;
//   - storage areas, alarms, tabs, runtime, i18n, and a permissions object whose
//     onAdded listeners are captured so a test can "grant" a permission.
// Tests that need `browser.downloads` add it themselves (it must be ABSENT to
// model "permission not granted").
//
// Used by: e2e_advanced_protections.mjs, e2e_download_guard.mjs.

// A Firefox-shaped resource-type enum, deliberately including types the
// derived third-party block must NOT skip and ones it must.
export const MOCK_RESOURCE_TYPES = Object.freeze({
    MAIN_FRAME: 'main_frame', SUB_FRAME: 'sub_frame', STYLESHEET: 'stylesheet',
    SCRIPT: 'script', IMAGE: 'image', FONT: 'font', OBJECT: 'object',
    XMLHTTPREQUEST: 'xmlhttprequest', PING: 'ping', CSP_REPORT: 'csp_report',
    MEDIA: 'media', WEBSOCKET: 'websocket', WEBTRANSPORT: 'webtransport',
    WEBBUNDLE: 'webbundle', OTHER: 'other',
});

// Listeners registered through browser.permissions.onAdded; a test calls
// firePermissionsAdded() to simulate the person granting a permission.
export const permissionAddedListeners = new Set();
export function firePermissionsAdded(details) {
    for ( const fn of [ ...permissionAddedListeners ] ) { fn(details); }
}

// See tabs.get() above.
export const tabUrls = new Map();

export const store = { local: {}, session: {} };
function makeStorageArea(area) {
    return {
        get: (key) => {
            if ( key === undefined || key === null ) { return Promise.resolve({ ...store[area] }); }
            if ( typeof key === 'string' ) { return Promise.resolve({ [key]: store[area][key] }); }
            if ( Array.isArray(key) ) {
                const out = {};
                for ( const k of key ) { out[k] = store[area][k]; }
                return Promise.resolve(out);
            }
            const out = {};
            for ( const k of Object.keys(key) ) { out[k] = store[area][k] ?? key[k]; }
            return Promise.resolve(out);
        },
        set: (obj) => { Object.assign(store[area], obj); return Promise.resolve(); },
        remove: (keys) => { for ( const k of [].concat(keys) ) { delete store[area][k]; } return Promise.resolve(); },
    };
}

export const dynamicRules = new Map();
export const sessionRules = new Map();
export function clone(value) { return JSON.parse(JSON.stringify(value)); }
const validTypes = new Set(Object.values(MOCK_RESOURCE_TYPES));
const dnrMock = {
    ResourceType: MOCK_RESOURCE_TYPES,
    async getDynamicRules(filter) {
        const all = [ ...dynamicRules.values() ].map(r => clone(r));
        return filter && Array.isArray(filter.ruleIds) ? all.filter(r => filter.ruleIds.includes(r.id)) : all;
    },
    async updateDynamicRules({ removeRuleIds = [], addRules = [] } = {}) {
        const next = new Map(dynamicRules);
        for ( const id of removeRuleIds ) { next.delete(id); }
        for ( const rule of addRules ) {
            if ( next.has(rule.id) ) { throw new Error(`Rule with id ${rule.id} does not have a unique ID`); }
            for ( const type of rule.condition?.resourceTypes ?? [] ) {
                if ( validTypes.has(type) === false ) { throw new Error(`Invalid resource type '${type}' in rule ${rule.id}`); }
            }
            next.set(rule.id, clone(rule));
        }
        dynamicRules.clear();
        for ( const [ k, v ] of next ) { dynamicRules.set(k, v); }
    },
    async getSessionRules(filter) {
        const all = [ ...sessionRules.values() ].map(r => clone(r));
        return filter && Array.isArray(filter.ruleIds) ? all.filter(r => filter.ruleIds.includes(r.id)) : all;
    },
    async updateSessionRules({ removeRuleIds = [], addRules = [] } = {}) {
        const next = new Map(sessionRules);
        for ( const id of removeRuleIds ) { next.delete(id); }
        for ( const rule of addRules ) {
            if ( next.has(rule.id) ) { throw new Error(`Session rule with id ${rule.id} does not have a unique ID`); }
            next.set(rule.id, clone(rule));
        }
        sessionRules.clear();
        for ( const [ k, v ] of next ) { sessionRules.set(k, v); }
    },
    async getEnabledRulesets() { return []; },
    async updateEnabledRulesets() {},
};

// In-memory content-script registry (same shape as the other e2e mocks): an
// id "exists" iff it is in the Map, duplicates/unknown ids throw like the real API.
export const registeredScripts = new Map();
const scriptingMock = {
    async getRegisteredContentScripts(filter) {
        const all = [ ...registeredScripts.values() ];
        return filter && Array.isArray(filter.ids) ? all.filter(d => filter.ids.includes(d.id)) : all;
    },
    async registerContentScripts(directives) {
        for ( const d of directives ) {
            if ( registeredScripts.has(d.id) ) { throw new Error(`Duplicate script ID '${d.id}'`); }
            registeredScripts.set(d.id, clone(d));
        }
    },
    async updateContentScripts(directives) {
        for ( const d of directives ) {
            if ( registeredScripts.has(d.id) === false ) { throw new Error(`Script with ID '${d.id}' does not exist`); }
            registeredScripts.set(d.id, clone(d));
        }
    },
    async unregisterContentScripts(filter) {
        if ( filter === undefined ) { registeredScripts.clear(); return; }
        for ( const id of filter.ids ) { registeredScripts.delete(id); }
    },
};

global.self = global;
global.browser = {
    scripting: scriptingMock,
    permissions: {
        getAll: () => Promise.resolve({ origins: [ '<all_urls>' ], permissions: [] }),
        onAdded: {
            addListener(fn) { permissionAddedListeners.add(fn); },
            removeListener(fn) { permissionAddedListeners.delete(fn); },
        },
        onRemoved: { addListener(){} },
    },
    // tabId -> url; a test sets this to control what browser.tabs.get() reports.
    // Deliberately NOT reset between test files, so an accidental reuse is caught
    // rather than silently passing on stale state, mirroring the real API's own
    // persistence across calls within a session.
    tabs: {
        query: () => Promise.resolve([]),
        reload: () => Promise.resolve(),
        get(tabId) {
            const url = tabUrls.get(tabId);
            if ( url === undefined ) { return Promise.reject(new Error(`No tab with id: ${tabId}`)); }
            return Promise.resolve({ id: tabId, url });
        },
    },
    // webRequest: matrix-panel.js registers a listener at import time. Nothing fires it here.
    webRequest: { onBeforeRequest: { addListener(){}, removeListener(){}, hasListener() { return false; } } },
    alarms: { create: () => {}, clear: () => Promise.resolve(true), onAlarm: { addListener(){} } },
    storage: {
        local: makeStorageArea('local'),
        session: makeStorageArea('session'),
        onChanged: { addListener(){} },
    },
    runtime: { getURL: p => `chrome-extension://test/${p}`, id: 'test', getManifest: () => ({ manifest_version: 3, name: 'test', version: '0' }), sendMessage: () => Promise.resolve(), onMessage: { addListener(){} } },
    i18n: { getUILanguage: () => 'en-US', getAcceptLanguages: () => Promise.resolve([ 'en-US' ]) },
    declarativeNetRequest: dnrMock,
};
global.chrome = global.browser;
