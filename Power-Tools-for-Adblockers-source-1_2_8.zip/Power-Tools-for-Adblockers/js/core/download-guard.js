/*
 * download-guard.js -- the downloads-API watcher behind the Privacy & Security
 * row "Block first-party downloads on websites outside the safe-regions."
 * (1.2.4).
 *
 * WHY A WATCHER. Row 1's main mechanism is a CSP `sandbox` response header
 * WITHOUT allow-downloads (see worry-free-advanced.js). A sandbox only blocks
 * downloads a sandboxed PAGE starts. Downloads the BROWSER starts have no page
 * behind them and slip through: right-click "Save link as...", a typed URL or
 * bookmark that points at a file, the PDF viewer's Save button, dragging a link
 * to the desktop. `browser.downloads.onCreated` sees every one of those, so
 * this module cancels the ones that belong to a website outside the safe
 * regions.
 *
 * TWO POLICIES, either one is enough to block a download (DOWNLOAD_POLICIES below
 * -- one array, so a third policy is added in one place, not scattered through
 * this file):
 *   A. 'advanced' row 1 ("Block first-party downloads..."): the 'advanced' tier is
 *      effective (isAdvancedItemActive(), the SAME gate its DNR header rule uses)
 *      and the row is not opted out. Scope: every download on an unsafe site,
 *      first- or third-party.
 *   B. (1.2.7) the Low group's "...and downloads" clause: the 'safeRegions' tier
 *      is effective (no separate row -- this mechanism has never had one; the
 *      static third-party block/sandbox it complements is switched by the tier
 *      itself). Scope: ONLY downloads that are THIRD-PARTY to the tab they
 *      happened in (the referrer's site differs from the tab's own top-level
 *      site -- isThirdPartyToTab()), matching the static rule's own
 *      domainType:'thirdParty' scope. Exists because that static rule is a
 *      response-header CSP sandbox, which (like row 1's header) cannot see a
 *      download the BROWSER starts rather than the page -- Chrome 128+ has a
 *      second, response-header-based layer for this that Firefox has no
 *      equivalent for (confirmed for DNR's responseHeaders condition); this
 *      watcher is Firefox's substitute for that layer, not a copy of it.
 *
 * WHEN IT BLOCKS (all must hold, on top of whichever policy above is active):
 *   1. at least one policy above is active for this download (policy A always
 *      applies once active; policy B only to a third-party-to-the-tab download);
 *   2. the download was NOT started by an extension (byExtensionId is empty).
 *      That deliberately spares this extension's own exports/backups and other
 *      extensions' downloads -- an extension acting is the person's own intent;
 *   3. the download belongs to a website OUTSIDE the safe regions. Which website:
 *      the page that started it (the referrer's host); when there is no referrer
 *      (typed URL, bookmark, Referrer-Policy: no-referrer) the host of the file
 *      itself. "Outside" is decided exactly like the DNR exemptions -- a host is
 *      safe when it IS, or is a subdomain of, a familiar TLD or a `$saferegions`
 *      domain (host-label anchored; `com.evil.ru` is NOT under `com`);
 *   4. that site's filtering mode is not "off" (an allowAllRequests site is
 *      exempt from the header rule, so it is exempt here too).
 *   Anything it cannot classify (no http(s)/blob host at all, an unparsable URL,
 *   or -- for policy B -- no browser.tabs.get() answer for the tab) is ALLOWED --
 *   a guard that cannot tell must not delete a person's download.
 *
 * NOT changed in 1.2.7: which permissions are requested from which dashboard
 * click (still tied to 'advanced' and row 1 only -- see js/ui/download-guard-
 * permission.js). Policy B's default-on tier would otherwise prompt nearly
 * every user for `downloads`/`notifications` the moment they open the
 * dashboard; deliberately left silent (a no-op) until the permission is
 * granted through one of the existing prompts.
 *
 * WHAT IT DOES. It cancels the download and asks the browser to delete any file
 * it already wrote, but leaves the entry in the downloads list ("canceled"), and
 * (1.2.6) shows a short notification -- "Download blocked: Cancelled a download from
 * <site> (outside your safe regions)." -- so the person is told WHY. The notification
 * needs the optional `notifications` permission; without it the guard works
 * silently. At most one message per site per NOTIFICATION_COOLDOWN_MS, so a page
 * that fires several downloads does not bury the person in messages. The download
 * starts before it is cancelled, so a few bytes may be fetched.
 *
 * THE PERMISSION. `downloads` is an OPTIONAL permission (manifest
 * optional_permissions), requested from a click on the checkbox. Without it
 * `browser.downloads` does not exist and this module does nothing; when it is
 * granted, permissions.onAdded registers the listener at once, and on the next
 * browser start the listener is registered synchronously at load (an event page
 * must register its listeners at top level to be woken by them).
 *
 * State: two booleans (listener registered / permission listener registered) and a
 * small map "site -> time of its last message" (pruned as it is written), all
 * cleared by releaseDownloadGuard(). Nothing else is kept.
 * Public interface: registerDownloadGuard(), releaseDownloadGuard(),
 *   handleDownloadCreated(item), plus the pure helpers hostnameOf(),
 *   isHostInSafeRegions(), pickSiteHost(), isThirdPartyToTab() (exported for
 *   tests). Whether the permission is held is asked by the dashboard itself
 *   (permissions.contains with DOWNLOAD_GUARD_PERMISSION from worry-free-
 *   advanced.js) -- importing this module into a page would drag the whole
 *   background graph in with it.
 * Dependencies: ../data/ext.js (browser), ../data/config.js (securityConfig),
 *   ./worry-free-tiers.js, ./worry-free-advanced.js,
 *   ./worry-free-familiar-tld-manager.js, ./saferegions-manager.js,
 *   ./mode-manager.js, ./cookie-clicker-autodeny-manager.js (session state),
 *   ./matrix-classifier.js (etldPlusOne -- the SAME reduction the Matrix panel
 *   uses, not a second implementation)
 */

import { browser } from '../data/ext.js';
import { securityConfig } from '../data/config.js';
import { getWorryFreeTierState } from './worry-free-tiers.js';
import {
    ADVANCED_ITEM_KEYS,
    DOWNLOAD_GUARD_PERMISSION,
    isAdvancedItemActive,
} from './worry-free-advanced.js';
import { getFamiliarTlds, parseFamiliarTlds } from './worry-free-familiar-tld-manager.js';
import { getSaferegionsDomains } from './saferegions-manager.js';
import { getFilteringMode, MODE_NONE } from './mode-manager.js';
import { etldPlusOne } from './matrix-classifier.js';
import { getAutoDenyState } from './cookie-clicker-autodeny-manager.js';

/******************************************************************************/
// CONFIGURATION -- declared once (B1)
/******************************************************************************/

// Decision reasons. Returned by handleDownloadCreated() and asserted by the
// tests, so a change here is a visible, deliberate change.
export const DOWNLOAD_DECISION = Object.freeze({
    BLOCKED:            'blocked',
    NO_POLICY_ACTIVE:   'no-policy-active',   // neither policy A nor B is on right now
    BY_EXTENSION:       'started-by-extension',
    NO_HOST:            'no-host',
    SAFE_REGION:        'safe-region',
    FILTERING_OFF:      'site-filtering-off',
    NOT_THIRD_PARTY:    'not-third-party',    // only policy B is on, and this download isn't third-party to its tab
    ERROR:              'error',
});

// Only these URL schemes name a website. `blob:` is included because a page's
// script-generated download is a blob: URL whose ORIGIN is the page's.
const WEB_SCHEMES = Object.freeze([ 'http:', 'https:' ]);

// The message shown when a download is cancelled (optional `notifications` permission).
export const NOTIFICATION_COOLDOWN_MS = 10_000;   // one message per site per 10 s
const NOTIFICATION_ICON_PATH = 'img/icon_128.png';
const NOTIFICATION_ID_PREFIX = 'uBol-download-blocked:';
const NOTIFICATION_TITLE = 'Download blocked';

/******************************************************************************/
// STATE -- cleared by releaseDownloadGuard()
/******************************************************************************/

let downloadListenerRegistered = false;
let permissionListenerRegistered = false;
const lastNotifiedAt = new Map();   // site -> Date.now() of its last message

/******************************************************************************/
// PURE HELPERS (exported for tests)
/******************************************************************************/

// The website a URL belongs to: its lowercase hostname for http(s), the origin's
// hostname for blob:, '' for anything else (data:, file:, about:, garbage).
export function hostnameOf(rawUrl) {
    if ( typeof rawUrl !== 'string' || rawUrl === '' ) { return ''; }
    try {
        const url = new URL(rawUrl);
        if ( url.protocol === 'blob:' ) {
            // new URL('blob:https://a.example/uuid').origin === 'https://a.example'
            const origin = new URL(url.origin);
            return WEB_SCHEMES.includes(origin.protocol) ? origin.hostname.toLowerCase() : '';
        }
        return WEB_SCHEMES.includes(url.protocol) ? url.hostname.toLowerCase() : '';
    } catch {
        return '';
    }
}

// Same rule the DNR exemptions use (`||label^`): a host is under `entry` when it
// IS `entry` or ends with `.entry` -- never a mere substring, so `com.evil.ru`
// and `evil.com.ru` are not under `com`.
function isUnder(host, entry) {
    return host === entry || host.endsWith(`.${entry}`);
}

export function isHostInSafeRegions(host, tlds, saferegionsDomains) {
    if ( host === '' ) { return false; }
    return tlds.some(tld => isUnder(host, tld)) ||
        saferegionsDomains.some(domain => isUnder(host, domain));
}

// Which website a download belongs to, and how we know: the page that started it
// when the browser tells us (referrer), otherwise the file's own host.
export function pickSiteHost(item) {
    const fromReferrer = hostnameOf(item?.referrer);
    if ( fromReferrer !== '' ) { return { host: fromReferrer, source: 'referrer' }; }
    const fromFile = hostnameOf(item?.finalUrl) || hostnameOf(item?.url);
    if ( fromFile !== '' ) { return { host: fromFile, source: 'file' }; }
    return { host: '', source: 'none' };
}

// Policy B's scope test: is this download THIRD-PARTY to the tab it happened in?
// Needs a referrer (no referrer means no "other site" is involved at all -- that
// case is policy A's job, not this one) whose site differs from the TAB's own
// top-level site, by the same eTLD+1 reduction the Matrix panel uses. A tab
// lookup failure (closed tab, no tabId, API error) is treated as "cannot tell",
// which fails CLOSED for this policy -- it simply does not apply; policy A, if
// active, still can.
export async function isThirdPartyToTab(item) {
    const referrerHost = hostnameOf(item?.referrer);
    if ( referrerHost === '' ) { return false; }
    if ( typeof item?.tabId !== 'number' || item.tabId < 0 ) { return false; }
    let tab;
    try { tab = await browser.tabs.get(item.tabId); } catch { return false; }
    const referrerSite = etldPlusOne(item.referrer);
    const tabSite = etldPlusOne(tab?.url ?? '');
    if ( referrerSite === '' || tabSite === '' ) { return false; }
    return referrerSite !== tabSite;
}

/******************************************************************************/
// DECISION + ACTION
/******************************************************************************/

async function currentTiers() {
    const session = await getAutoDenyState();
    return getWorryFreeTierState(securityConfig, session?.active === true);
}

// One array: every download policy this guard enforces, and how to tell whether
// each is switched on and whether it covers a given download. Adding a third
// policy means one more entry here -- nothing else in this file changes shape.
// `scopeApplies` runs only once the download is already known to be unsafe (§3
// in this file's header), so it never needs to repeat that check itself.
const DOWNLOAD_POLICIES = Object.freeze([
    {
        id: 'advancedFirstParty',
        isActive: tiers => isAdvancedItemActive(securityConfig, ADVANCED_ITEM_KEYS.FIRST_PARTY_DOWNLOADS, tiers),
        scopeApplies: () => Promise.resolve(true),   // every download on an unsafe site
    },
    {
        id: 'safeRegionsThirdParty',
        isActive: tiers => tiers?.safeRegions === true,
        scopeApplies: item => isThirdPartyToTab(item),
    },
]);

// Cancel, then ask the browser to delete any bytes already written. The list
// entry is kept on purpose (the person sees "canceled"). Both calls are
// best-effort: a download that already finished cannot be cancelled, and a
// download with no file has none to remove.
async function cancelDownload(id) {
    try { await browser.downloads.cancel(id); } catch { /* already finished */ }
    try { await browser.downloads.removeFile(id); } catch { /* no file to remove */ }
}

// Tell the person a download was cancelled and why. A courtesy, never a dependency:
// no permission, the rate limit, or a failing notifications API must not change what
// the guard decided or did. At most one message per site per NOTIFICATION_COOLDOWN_MS.
async function notifyBlocked(host) {
    if ( typeof browser.notifications?.create !== 'function' ) { return; }
    const now = Date.now();
    for ( const [ site, at ] of lastNotifiedAt ) {
        if ( now - at >= NOTIFICATION_COOLDOWN_MS ) { lastNotifiedAt.delete(site); }
    }
    if ( lastNotifiedAt.has(host) ) { return; }
    lastNotifiedAt.set(host, now);
    try {
        await browser.notifications.create(`${NOTIFICATION_ID_PREFIX}${host}`, {
            type: 'basic',
            iconUrl: browser.runtime.getURL(NOTIFICATION_ICON_PATH),
            title: NOTIFICATION_TITLE,
            message: `Cancelled a download from ${host} (outside your safe regions).`,
        });
    } catch { /* the message is a courtesy */ }
}

// Returns { blocked, reason, host } so callers and tests can see WHY.
export async function handleDownloadCreated(item) {
    try {
        const tiers = await currentTiers();
        const activePolicies = DOWNLOAD_POLICIES.filter(p => p.isActive(tiers));
        if ( activePolicies.length === 0 ) {
            return { blocked: false, reason: DOWNLOAD_DECISION.NO_POLICY_ACTIVE, host: '' };
        }
        if ( typeof item?.byExtensionId === 'string' && item.byExtensionId !== '' ) {
            return { blocked: false, reason: DOWNLOAD_DECISION.BY_EXTENSION, host: '' };
        }
        const { host } = pickSiteHost(item);
        if ( host === '' ) {
            return { blocked: false, reason: DOWNLOAD_DECISION.NO_HOST, host };
        }
        const [ tldText, saferegionsDomains ] = await Promise.all([
            getFamiliarTlds(),
            getSaferegionsDomains(),
        ]);
        if ( isHostInSafeRegions(host, parseFamiliarTlds(tldText), saferegionsDomains) ) {
            return { blocked: false, reason: DOWNLOAD_DECISION.SAFE_REGION, host };
        }
        if ( await getFilteringMode(host) === MODE_NONE ) {
            return { blocked: false, reason: DOWNLOAD_DECISION.FILTERING_OFF, host };
        }
        let inScope = false;
        for ( const policy of activePolicies ) {
            if ( await policy.scopeApplies(item) ) { inScope = true; break; }
        }
        if ( inScope === false ) {
            return { blocked: false, reason: DOWNLOAD_DECISION.NOT_THIRD_PARTY, host };
        }
        await cancelDownload(item.id);
        await notifyBlocked(host);
        console.info(`[uBol] cancelled a download started from ${host} (outside safe regions)`);
        return { blocked: true, reason: DOWNLOAD_DECISION.BLOCKED, host };
    } catch (err) {
        // A failure must never take a download down with it: leave it alone.
        console.error('[uBol] download guard failed; download left alone:', err);
        return { blocked: false, reason: DOWNLOAD_DECISION.ERROR, host: '' };
    }
}

/******************************************************************************/
// REGISTRATION (init / release guards)
/******************************************************************************/

function onDownloadCreated(item) {
    handleDownloadCreated(item);
}

// Idempotent. Call at TOP LEVEL of the background script (an event page only
// wakes for listeners registered synchronously at load). Registers the
// downloads listener if the permission is already held, and -- always, once --
// a permissions.onAdded listener so granting it later takes effect immediately.
export function registerDownloadGuard() {
    if ( downloadListenerRegistered === false && browser.downloads?.onCreated ) {
        browser.downloads.onCreated.addListener(onDownloadCreated);
        downloadListenerRegistered = true;
    }
    if ( permissionListenerRegistered === false && browser.permissions?.onAdded ) {
        browser.permissions.onAdded.addListener(onPermissionsAdded);
        permissionListenerRegistered = true;
    }
}

function onPermissionsAdded(permissions) {
    if ( permissions?.permissions?.includes(DOWNLOAD_GUARD_PERMISSION) ) {
        registerDownloadGuard();
    }
}

// Removes both listeners and clears the flags (teardown, and for tests).
export function releaseDownloadGuard() {
    if ( downloadListenerRegistered ) {
        try { browser.downloads?.onCreated?.removeListener(onDownloadCreated); } catch { /* API gone */ }
        downloadListenerRegistered = false;
    }
    if ( permissionListenerRegistered ) {
        try { browser.permissions?.onAdded?.removeListener(onPermissionsAdded); } catch { /* API gone */ }
        permissionListenerRegistered = false;
    }
    lastNotifiedAt.clear();
}
